function [lShank,lThigh,lTrunk,mTrunk,mShank,mThigh,l] = Anatomical2SegmentLengths(Lbody,Mbody,kAnkle,KFE,g,f)

lShank      = 0.44;
lThigh      = 0.41;
lTrunk      = 0.37;
% kAnkle      = 50;
% KFE         = -5/180*pi;
% g           = 9.81;
mTrunk      = 40;
mShank      = 5;
mThigh      = 3; 
% f           = 0;
theta1_init = -25/180*pi;
l           = sqrt(lShank^2+lThigh^2-2*lShank*lThigh*cos(pi+KFE));
% theta1_init = asin(x0/l);
alpha       = asin(lShank/l*sin(pi+KFE));
HFE_init    = alpha + theta1_init*f - theta1_init;
