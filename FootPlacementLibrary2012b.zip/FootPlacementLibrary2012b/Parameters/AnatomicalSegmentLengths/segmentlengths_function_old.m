function [lthigh,lshank,hfoot,lfoot,lheel,wpelvis,r1,r2,m1,m2,l,omega_0,Xp,trunklbd,M_SM,mshank,mthigh]=segmentlengths_function(L,M,f,kankle,g,KFE)

%% Segment properties from Drillis,Contini,Bluestein, according to Harless
% 1 = head
% 2 = trunk upper
% 3 = trunk lower
% 4 = arm upper
% 5 = arm lower
% 6 = hand
% 7 = thigh
% 8 = shank
% 9 = foot
relative_lengths    = [121.35; 232.15; 92.8; 195.9; 164.8; 114.65; 256.00; 237.7; 46.35];
relative_weights    = [73.16; 358.41; 100.00; 30.70; 17.04; 8.07; 115.00; 44.41; 19.01];
relative_CoG        = [0.361; 0.497; 0.518; 0.430; 0.410; 0.359; 0.500; 0.469; 0.436];
absolute_CoG        = [43.530; 276.585; 413.000; 235.245; 403.548; 606.738; 570.363; 841.680; 974.955];

%% Kinematic parameters
lthigh  = L*relative_lengths(7)/1000;
lshank  = L*relative_lengths(8)/1000;
hfoot   = L*relative_lengths(9)/1000;
wpelvis = L*0.175/1.80;
% lfoot   = L*0.1525;
lfoot   = L*0.2/1.65;
lheel   = L*0.04/1.80;

%% Kinetic parameters
mshank  = M*relative_weights(8)/1000; 
mthigh  = M*relative_weights(7)/1000; 

%% hip height
hh_1 = sum(relative_lengths([1 2 3]));
hh_2 = absolute_CoG(3)+(1-relative_CoG(3))*relative_lengths(3);
hh_3 = absolute_CoG(7)-relative_CoG(7)*relative_lengths(7);

hh = hh_1;

%% shoulder height
sh_1 = relative_lengths(1);

sh = sh_1;

%% Arm lumped
retraction = 1;
retraction_arm =  retraction;
arm_weight = sum(relative_weights([4 5 6]));
arm_length = retraction_arm*sum(relative_lengths([4 5 6]));
arm_CoG =   ( relative_weights(4)*( relative_CoG(4)*relative_lengths(4) )...
            + relative_weights(5)*( relative_lengths(4) + relative_CoG(5)*relative_lengths(5) )...
            + relative_weights(6)*( relative_lengths(4) + relative_lengths(5) + relative_CoG(6)*relative_lengths(6) ))...
            / sum(relative_weights([4 5 6]))...
            / sum(relative_lengths([4 5 6]));
arm_gCoG = sh + arm_CoG*arm_length;
        
%% Leg lumped        
% retraction = (0.85-0.02)/0.85  % The shortening of leg, defined as 0.03 [m] clearance at leg length 0.85 [m]
swleg_weight = sum(relative_weights([7 8 9]));
swleg_length = retraction*(sum(relative_lengths([7 8 9])));
swleg_CoG  = ( relative_weights(7)*( relative_CoG(7)*relative_lengths(7) )...
            + relative_weights(8)*( relative_lengths(7) + relative_CoG(8)*relative_lengths(8) )...
            + relative_weights(9)*( relative_lengths(7) + relative_lengths(8) +  relative_CoG(9)*relative_lengths(9)))...
            / sum(relative_weights([7 8 9]))...
            / sum(relative_lengths([7 8 9]));
swleg_gCoG = hh + swleg_CoG*swleg_length;

%% Upper body & swLeg CoM
% From absolute CoG
CoM_1 = sum(absolute_CoG([1 2 3 4 4 5 5 6 6 7 8 9]).*relative_weights([1 2 3 4 4 5 5 6 6 7 8 9]))/sum(relative_weights([1 2 3 4 4 5 5 6 6 7 8 9]));

% From relative CoG, with retraction of arms and swleg
CoM_2 = ( sum(absolute_CoG([1 2 3]).*relative_weights([1 2 3]))...
        + 2*arm_weight*( sh + arm_CoG*arm_length )...
        + swleg_weight*( hh + swleg_CoG*swleg_length ) )...
        / ( sum(relative_weights([1 2 3])) + 2*arm_weight + swleg_weight );

%% Stance leg
l_stleg = sum(relative_lengths([7 8]));
m_stleg = sum(relative_weights([7 8]));

sCoG_stleg = (relative_weights(7)*(relative_CoG(7)*relative_lengths(7)) ...
    + relative_weights(8)*(relative_lengths(7) + relative_CoG(8)*relative_lengths(8)))...
    /sum(relative_weights([7 8]))...
    /sum(relative_lengths([7 8]));

%% xCoM parameters
l       = sqrt(lshank^2 + lthigh^2 - 2*lshank*lthigh*cos(pi+KFE)) + hfoot;
r1      = l*(1-sCoG_stleg);
r2      = (hh-CoM_2)/1000*L;
m1      = M*sum(relative_weights([7 8]))/1000;
m2      = M*sum(relative_weights([1 2 3 4 4 5 5 6 6 7 8 9]))/1000;

L_LIPM  = (l^2 + l*r2 + l*r2*f + r2^2*f + m1/m2*r1^2)...
          /(l + r2*f + m1/m2*r1 - kankle/(m2*g));
omega_0 = sqrt(g/L_LIPM);
C       = KFE + asin(lshank/l*sin(pi+KFE));
Xp      = 0 - kankle*C/(g*omega_0)*(l+r2*f+m1/m2*r1)...
            /(1+m1/m2)...
            /(l+r2*f+m1/m2*r1 - kankle/(m2*g));
        
%% SimMechanics trunk segment properties
CoM_SM_rel = ( sum(absolute_CoG([1 2 3]).*relative_weights([1 2 3]))...
        + 2*arm_weight*( sh + arm_CoG*arm_length ))...
        / ( sum(relative_weights([1 2 3])) + 2*arm_weight);
M_SM   = (sum(relative_weights([1 2 3])) + 2*arm_weight)/1000*M;
CoM_SM = (hh-CoM_SM_rel)/1000*L;

wtrunk = 0.1861*L;
trunklbd = [2*CoM_SM,wtrunk,M_SM/(1000*2*CoM_SM*wtrunk)];
rthighshank = sqrt(M.*relative_weights([7 8]) ./ (1000.*pi.*L.*relative_lengths([7 8])));

