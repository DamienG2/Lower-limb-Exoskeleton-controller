isLOPESemulation = 0;
isContVel = 1;

%%
name = 'SimMechanics1';
LoadSegmentLengths;
Masses          = [mThigh; mShank; mTrunk];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ankle_stiffness=0;
joint_damping=0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% lShank = 1.1*lShank;
% lThigh = 1.1*lThigh;
lShankSM = lShank;
lThighSM = lThigh;
SegmentLengths  = [hTrunk; wPelvis; HAA2HEE; HEE2HFE; lThigh; lShank; dxFoot; hFoot; lFoot];
% load(strcat('SteppingParameters_',name));
load('SteppingParametersMartijnAdapted');

if isLOPESemulation~=1
    LoadParametersSimMechanics;
%     jointsinitial = [0;20;-70;-10;0;0]/180*pi;
    jointsinitial = [RHAA_initial,RHFE_initial,RKFE_initial,LHAA_initial,LHFE_initial,LKFE_initial];
    SteppingParameters.ToeClearance = 0.03;
    dxFootSM = dxFoot;
    lFootSM = lFoot;
    kPswing             = 10*[400 200 100];
    kPstance            = 10*[400 200 100];
else
    jointsinitial       = [0;0;0;0;0;0];
    kPswing             = [750 750 750];
    kPstance            = [1 1 1];
    %% Shorten the foot. Decreases singularity problem, but needs higher too clearance.
    dxFoot = 0.02;
    lFoot = 0.04;
end

%% FPC Parameters

% Control joint limits
LB        = [-0.2;  -0.25;  -1.3;   -0.15;  -0.25;  -1.3];
UB        = [0.15;  0.65;   0;      0.2;    0.65;  0];
deltaBound = 0.01;
LB = LB + deltaBound;
UB = UB - deltaBound;

% xCoM Parameters
min_lat_foot_distance   = -0.5; % Minimum lateral foot distance to prevent foot colission
f                       = 0;
KFE                     = -5/180*pi;
kAnkle                  = ankle_stiffness;
g                       = 9.81;

[omega0_x, Xp_x] = xCoMPars(0,mShank,mThigh,50,lShank,lThigh,0.175,KFE,f,g,kAnkle);
[omega0_z, Xp_z] = xCoMPars(0,mShank,mThigh,50,lShank,lThigh,0.175,KFE,f,g,0);

