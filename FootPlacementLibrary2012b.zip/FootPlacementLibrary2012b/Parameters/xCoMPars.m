function [w0, Xp] = xCoMPars(xu,mShank,mThigh,mTrunk,lShank,lThigh,lTrunk,KFE,f,g,k)
%#codegen

l   = sqrt(lShank^2 + lThigh^2 - 2*lShank*lThigh*cos(pi+KFE));
C   = asin(lShank/l*sin(KFE+pi)) + KFE;

m1          = mShank + mThigh;

if mShank+mThigh>0
    r1          = l/(lShank+lThigh)*(mShank*lShank/2 + mThigh*(lShank+lThigh/2))/(mShank+mThigh);
else
    r1          = l/(lShank+lThigh)*(lShank/2 + lShank + lThigh/2)/2;
end

m2          = mTrunk;
r2          = lTrunk;

P1      = (m1*r1^2 + m2*l^2 + m2*l*r2 + f*m2*l*r2 + f*m2*r2^2);
P2      = g*(m1*r1 + m2*l + f*m2*r2 - k/g);
P3      = (m1*r1 + m2*l + m2*r2*f)/(m1+m2);
% coef1   = (m1*r1^2 + m2*l^2 + m2*l*r2 + f*m2*l*r2 + f*m2*r2^2);
% coef2   = g*(m1*r1 + m2*l + f*m2*r2 - k/g);
% RHS     = k*C*(m1*r1 + m2*l + m2*r2*f)/(m1+m2)/coef1;

w0_squared  = P2/P1;
% Xp          = -RHS/w0_squared;
Xp          = xu - k*C*P3/(w0_squared*P1);
w0  = sqrt(complex(w0_squared));



