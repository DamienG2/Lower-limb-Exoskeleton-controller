%% SimMechanics
dsegment    = 0.05;
rho         = 1000;

% Ground Reaction Force Model (SimMechanics)
kp_normal       = 5e4;  % [N/m]
kv_normal       = 1e4;  % [Ns/m]
kp_tangent      = 0;    % [N/m]
kv_tangent      = 1e4;  % [Ns/m]
mu              = 1000;  % Friction coefficient, limiting maximum tangential force max_F_tangent=mu*F_normal
k_grf           = [kp_normal; kv_normal; kp_tangent; kv_tangent; mu];

% Initial Conditions
% v_initial       = 0.2;              %[m/s], initial forward pelvis velocity
% RHAA_initial    = 0/180*pi;         %[rad]
% RHFE_initial    = -8/180*pi;     
% RKFE_initial    = -2/180*pi;
% LHAA_initial    = -5/180*pi;     
% LHFE_initial    = 5/180*pi;
% LKFE_initial    = -10/180*pi;
v_initial       = 0;              %[m/s], initial forward pelvis velocity
RHAA_initial    = 5/180*pi;         %[rad]
RHFE_initial    = 20/180*pi;     
RKFE_initial    = -70/180*pi;
LHAA_initial    = -5/180*pi;     
LHFE_initial    = 0/180*pi;
LKFE_initial    = 0/180*pi;
jointsinitial = [RHAA_initial;RHFE_initial;RKFE_initial;LHAA_initial;LHFE_initial;LKFE_initial];

% Joint mechanics
joint_damping   = 1;    % [Ns/rad]
ankle_stiffness = kankle;   % [N/rad]

% Physical Joint Limits (SimMechanis)
LB_jl   = pi/180*[-45 -45 -170 -45 -45 -170];   % [rad], upper joint bounds
UB_jl   = pi/180*[45 110 0 45 110 0];           % [rad], lower joint bounds
kp_jl   = 1e3;                                  % [N/rad], joint limit stiffness
kv_jl   = 1e2;                                  % [Ns/rad], joint limit damping
k_jl    = [kp_jl; kv_jl];