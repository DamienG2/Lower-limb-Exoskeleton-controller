clear all
close all


isLOPESemulation = 0;
isContVel = 1;
name = 'Martijn_new';

lbody = 1.70;
mbody = 60;
f = 0;
kankle = mbody/55*50;
% kankle = 200;
g = 9.81;
KFE = -5/180*pi;
[lThigh,lShank,hFoot,lFoot,lHeel,wPelvis,r1,r2,m1,m2,l,omega0_x,Xp_x,trunklbd,M_SM,mShank,mThigh]=segmentlengths_function(lbody,mbody,f,kankle,g,KFE,0);
[lThigh,lShank,hFoot,lFoot,lHeel,wPelvis,r1,r2,m1,m2,l,omega0_z,Xp_z,trunklbd,M_SM,mShank,mThigh]=segmentlengths_function(lbody,mbody,f,0,g,KFE,1);

omega0_z

if isLOPESemulation~=1
    dxFoot      = lFoot - lHeel;
    dxTrunk     = 0.1;
    HAA2HEE     = [0; 0; 0.001];
    HEE2HFE     = 0.5*[0.2; 0; 0];
else
    dxFoot      = 0.02;
    lFoot       = 0.04;
%     dxTrunk     = 0.1;
    HAA2HEE     = [0; 0; 0];
    HEE2HFE     = [0; 0; 0];
end
hTrunk      = trunklbd(1);
wTrunk      = trunklbd(2);
dTrunk      = trunklbd(3);
mTrunk      = M_SM;
Masses      = [mThigh; mShank; mTrunk];
lShankSM = lShank;
lThighSM = lThigh;

if isLOPESemulation~=1
    LoadParametersSimMechanics;
%     jointsinitial = [0;20;-70;-10;0;0]/180*pi;
    jointsinitial = [RHAA_initial,RHFE_initial,RKFE_initial,LHAA_initial,LHFE_initial,LKFE_initial];
    SteppingParameters.ToeClearance = 0.03;
    dxFootSM = dxFoot;
    lFootSM = lFoot;
    kPswing             = mbody/55*10*[400 200 100];
    kPstance            = mbody/55*10*[400 200 100];
else
    jointsinitial       = [0;0;0;0;0;0];
    kPswing             = [750 750 750];
    kPstance            = [1 1 1];
    %% Shorten the foot. Decreases singularity problem, but needs higher toe clearance.
    dxFoot = 0.02;
    lFoot = 0.04;
end

SegmentLengths  = [hTrunk; wPelvis; HAA2HEE; HEE2HFE; lThigh; lShank; dxFoot; hFoot; lFoot];
% load(strcat('SteppingParameters_',name));
load('SteppingParametersMartijnAdapted');

%% FPC Parameters

% Control joint limits
LB        = [-0.2;  -0.25;  -1.3;   -0.15;  -0.25;  -1.3];
UB        = [0.15;  0.65;   0;      0.2;    0.65;  0];
deltaBound = 0.01;
LB = LB + deltaBound;
UB = UB - deltaBound;

% xCoM Parameters
min_lat_foot_distance   = -0.5; % Minimum lateral foot distance to prevent foot colission
% f                       = 0;
% KFE                     = -5/180*pi;
% kAnkle                  = ankle_stiffness;
% g                       = 9.81;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ankle_stiffness=50;
% joint_damping=0;
% kPstance=5*10^4;
% jointsinitial=0;
% lFootSM=lFoot;
% k_grf=10^4;
% kPswing=0;
% dxFootSM=0.01;
% dsegment=0.05;
% RHAA_initial=0;
% LHAA_initial=0;
% RHFE_initial=0;
% LHFE_initial=0;
% RKFE_initial=0;
% LKFE_initial=0;
% LB_jl=0;
% rho=1000;
% UB_jl=0;
% k_jl=0;
% v_initial=0;
% dxTrunk=0;
%k=[5*10^4 10^4 0 10^4 0];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 
% [omega0_x, Xp_x] = xCoMPars(0,mShank,mThigh,50,lShank,lThigh,0.175,KFE,f,g,kAnkle);
% [omega0_z, Xp_z] = xCoMPars(0,mShank,mThigh,50,lShank,lThigh,0.175,KFE,f,g,0);

