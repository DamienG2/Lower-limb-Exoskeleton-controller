if strcmp(name,'Martijn') || strcmp(name,'Edwin') || strcmp(name,'Shiqian')
    %%
    lThigh      = 0.41;         
    lShank      = 0.44;
    dxFoot      = 0.23; 
    hFoot       = 0.065;
    lFoot       = 0.255;
    wPelvis     = 0.2;
    dxTrunk     = 0.1;
    HAA2HEE     = [0; 0; 0];
    HEE2HFE     = [0; 0; 0];
    mThigh      = 5;
    mShank      = 5;
    mTrunk      = 75;
    hTrunk      = 0.1;
elseif strcmp(name,'Gijs')
    %%
    lThigh      = 0.41;         
    lShank      = 0.44;
    dxFoot      = 0.23; 
    hFoot       = 0.065;
    lFoot       = 0.255;
    wPelvis     = 0.2;
    dxTrunk     = 0.1;
    HAA2HEE     = [0; 0; 0];
    HEE2HFE     = [0; 0; 0];
    mThigh      = 5;
    mShank      = 5;
    mTrunk      = 75;
    hTrunk      = 0.1;
elseif strcmp(name,'Heidi')
    %%
    lThigh      = 0.3;         
    lShank      = 0.38;
    dxFoot      = 0.175; 
    hFoot       = 0.055;
    lFoot       = 0.245;
    wPelvis     = 0.2;
    dxTrunk     = 0.1;
    HAA2HEE     = [0; 0; 0];
    HEE2HFE     = [0; 0; 0];
    mThigh      = 5;
    mShank      = 5;
    mTrunk      = 75;
    hTrunk      = 0.1;
elseif strcmp(name,'SimMechanics')
    %%
    lThigh      = 0.41;         
    lShank      = 0.44;
    dxFoot      = 0.75*0.23;
    hFoot       = 0.065;
    lFoot       = 0.75*0.255;
    wPelvis     = 0.5*0.33;
    dxTrunk     = 0.1;
    HAA2HEE     = [0; 0; 0.001];
    HEE2HFE     = 0.5*[0.2; 0; 0];
    dsegment    = 0.05;
    rho         = 1e3;
    mThigh      = 5;
    mShank      = 3;
    mTrunk      = 40;
    wTrunkFrac  = 2.5;
    dTrunkFrac  = 4;
    hTrunk      = (dTrunkFrac*wTrunkFrac*mTrunk/rho)^(1/3);
    wTrunk      = hTrunk / wTrunkFrac;
    dTrunk      = hTrunk / dTrunkFrac;
    elseif strcmp(name,'SimMechanics1')
    %%
    lThigh      = 0.461; rThigh = 0.069;
    lShank      = 0.428; rShank = 0.045;
    dxFoot      = 0.75*0.23;
    hFoot       = 0.085;
    lFoot       = 0.75*0.255;
    wPelvis     = 0.175;
    dxTrunk     = 0.1;
    HAA2HEE     = [0; 0; 0.001];
    HEE2HFE     = 0.5*[0.2; 0; 0];
    dsegment    = 0.05;
    rho         = 1e3;
    mThigh      = 6.9 ;
    mShank      = 2.6646;
    mTrunk      = 38.6;
    hTrunk      = 0.617;
    wTrunk      = 0.335;
    dTrunk      = 0.187;
else
    error('Name unknown. Put segmentlength information in "FootPlacementLibrary2012b/Parameters/LoadSegmentLengths"')
end