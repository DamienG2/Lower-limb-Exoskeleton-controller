function R = Ry(q)
%#codegen
s = sin(q);
c = cos(q);

R = [  c,  0, -s; ... 
         0,  1,  0; ... 
       s,  0,  c];