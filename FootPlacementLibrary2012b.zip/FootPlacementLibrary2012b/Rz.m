function R = Rz(q)
%#codegen
s = sin(q);
c = cos(q);

R = [  c,  s,  0; ... 
       -s,  c,  0; ... 
         0,   0,  1];