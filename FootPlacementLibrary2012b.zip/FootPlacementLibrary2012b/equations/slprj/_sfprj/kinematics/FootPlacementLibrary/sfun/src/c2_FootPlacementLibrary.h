#ifndef __c2_FootPlacementLibrary_h__
#define __c2_FootPlacementLibrary_h__

/* Include files */
#include "sf_runtime/sfc_sf.h"
#include "sf_runtime/sfc_mex.h"
#include "rtwtypes.h"
#include "multiword_types.h"

/* Type Definitions */
#ifndef typedef_SFc2_FootPlacementLibraryInstanceStruct
#define typedef_SFc2_FootPlacementLibraryInstanceStruct

typedef struct {
  SimStruct *S;
  ChartInfoStruct chartInfo;
  uint32_T chartNumber;
  uint32_T instanceNumber;
  int32_T c2_sfEvent;
  boolean_T c2_isStable;
  boolean_T c2_doneDoubleBufferReInit;
  uint8_T c2_is_active_c2_FootPlacementLibrary;
  const mxArray *c2_vidObj;
  boolean_T c2_vidObj_not_empty;
  const mxArray *c2_fig;
  boolean_T c2_fig_not_empty;
  real_T c2_seArray[3000];
  boolean_T c2_seArray_not_empty;
  const mxArray *c2_setraject;
  boolean_T c2_setraject_not_empty;
  real_T c2_tprev;
  boolean_T c2_tprev_not_empty;
  real_T c2_Tframe;
  boolean_T c2_Tframe_not_empty;
  real_T c2_fromto[30];
  boolean_T c2_fromto_not_empty;
  real_T c2_toeArray[3000];
  boolean_T c2_toeArray_not_empty;
  real_T c2_toeArrayref[3000];
  boolean_T c2_toeArrayref_not_empty;
  real_T c2_itoeArray;
  boolean_T c2_itoeArray_not_empty;
  const mxArray *c2_toetraject;
  boolean_T c2_toetraject_not_empty;
  const mxArray *c2_toetrajectref;
  boolean_T c2_toetrajectref_not_empty;
  const mxArray *c2_link16;
  boolean_T c2_link16_not_empty;
  const mxArray *c2_link17;
  boolean_T c2_link17_not_empty;
  const mxArray *c2_link18;
  boolean_T c2_link18_not_empty;
  const mxArray *c2_link19;
  boolean_T c2_link19_not_empty;
  const mxArray *c2_link20;
  boolean_T c2_link20_not_empty;
  const mxArray *c2_link21;
  boolean_T c2_link21_not_empty;
  const mxArray *c2_link22;
  boolean_T c2_link22_not_empty;
  const mxArray *c2_link23;
  boolean_T c2_link23_not_empty;
  const mxArray *c2_link24;
  boolean_T c2_link24_not_empty;
  const mxArray *c2_link25;
  boolean_T c2_link25_not_empty;
  const mxArray *c2_link26;
  boolean_T c2_link26_not_empty;
  const mxArray *c2_link27;
  boolean_T c2_link27_not_empty;
  const mxArray *c2_link28;
  boolean_T c2_link28_not_empty;
  const mxArray *c2_link29;
  boolean_T c2_link29_not_empty;
  const mxArray *c2_link30;
  boolean_T c2_link30_not_empty;
} SFc2_FootPlacementLibraryInstanceStruct;

#endif                                 /*typedef_SFc2_FootPlacementLibraryInstanceStruct*/

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern const mxArray *sf_c2_FootPlacementLibrary_get_eml_resolved_functions_info
  (void);

/* Function Definitions */
extern void sf_c2_FootPlacementLibrary_get_check_sum(mxArray *plhs[]);
extern void c2_FootPlacementLibrary_method_dispatcher(SimStruct *S, int_T method,
  void *data);

#endif
