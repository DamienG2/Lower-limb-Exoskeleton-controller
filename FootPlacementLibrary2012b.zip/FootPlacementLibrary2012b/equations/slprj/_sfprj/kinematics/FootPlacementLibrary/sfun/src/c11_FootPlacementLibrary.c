/* Include files */

#include <stddef.h>
#include "blas.h"
#include "FootPlacementLibrary_sfun.h"
#include "c11_FootPlacementLibrary.h"
#include "mwmathutil.h"
#define CHARTINSTANCE_CHARTNUMBER      (chartInstance->chartNumber)
#define CHARTINSTANCE_INSTANCENUMBER   (chartInstance->instanceNumber)
#include "FootPlacementLibrary_sfun_debug_macros.h"
#define _SF_MEX_LISTEN_FOR_CTRL_C(S)   sf_mex_listen_for_ctrl_c(sfGlobalDebugInstanceStruct,S);

/* Type Definitions */

/* Named Constants */
#define CALL_EVENT                     (-1)

/* Variable Declarations */

/* Variable Definitions */
static real_T _sfTime_;
static const char * c11_debug_family_names[16] = { "J", "dx", "dq", "nargin",
  "nargout", "xze", "KFE", "jointangles", "Rtrunk", "SegmentLengths", "LB", "UB",
  "Rswjointangles", "i", "xz", "q" };

static const char * c11_b_debug_family_names[6] = { "s", "c", "nargin",
  "nargout", "q", "R" };

static const char * c11_c_debug_family_names[6] = { "s", "c", "nargin",
  "nargout", "q", "R" };

static const char * c11_d_debug_family_names[6] = { "s", "c", "nargin",
  "nargout", "q", "R" };

static const char * c11_e_debug_family_names[103] = { "RHAA", "RHFE", "RKFE",
  "R_trunk_0_1_1", "R_trunk_0_1_2", "R_trunk_0_1_3", "R_trunk_0_2_1",
  "R_trunk_0_2_2", "R_trunk_0_2_3", "R_trunk_0_3_1", "R_trunk_0_3_2",
  "R_trunk_0_3_3", "wPelvis", "dxHAA2HEE", "dyHAA2HEE", "dzHAA2HEE", "dxHEE2HFE",
  "dyHEE2HFE", "dzHEE2HFE", "lThigh", "lShank", "dxFoot", "hFoot", "lFoot", "t2",
  "t3", "t4", "t9", "t5", "t6", "t7", "t8", "t10", "t11", "t12", "t13", "t14",
  "t15", "t16", "t17", "t18", "t19", "t20", "t21", "t22", "t24", "t23", "t25",
  "t26", "t27", "t28", "t29", "t34", "t30", "t31", "t32", "t33", "t35", "t36",
  "t37", "t38", "t39", "t40", "t41", "t42", "t43", "t45", "t44", "t46", "t47",
  "t48", "t49", "s_6", "s_5_6_5", "s_4_5_4", "s_3_4_3", "s_2_3_2", "s_1_2_1",
  "s_1t_1_1", "s_1h_1t_1", "R_5_0", "R_1_2", "R_2_3", "R_3_4", "R_4_5", "R_4_0",
  "R_3_0", "R_2_0", "R_1_0", "s_5", "s_4", "s_3", "s_2", "s_1", "s_1t", "s_1h",
  "J", "nargin", "nargout", "swjointangles", "Rtrunk", "SegmentLengths", "xz" };

static const char * c11_f_debug_family_names[103] = { "RHAA", "RHFE", "RKFE",
  "R_trunk_0_1_1", "R_trunk_0_1_2", "R_trunk_0_1_3", "R_trunk_0_2_1",
  "R_trunk_0_2_2", "R_trunk_0_2_3", "R_trunk_0_3_1", "R_trunk_0_3_2",
  "R_trunk_0_3_3", "wPelvis", "dxHAA2HEE", "dyHAA2HEE", "dzHAA2HEE", "dxHEE2HFE",
  "dyHEE2HFE", "dzHEE2HFE", "lThigh", "lShank", "dxFoot", "hFoot", "lFoot", "t2",
  "t3", "t4", "t9", "t5", "t6", "t7", "t8", "t10", "t11", "t12", "t13", "t14",
  "t15", "t16", "t17", "t18", "t19", "t20", "t21", "t22", "t24", "t23", "t25",
  "t26", "t27", "t28", "t29", "t34", "t30", "t31", "t32", "t33", "t35", "t36",
  "t37", "t38", "t39", "t40", "t41", "t42", "t43", "t45", "t44", "t46", "t47",
  "t48", "t49", "s_6", "s_5_6_5", "s_4_5_4", "s_3_4_3", "s_2_3_2", "s_1_2_1",
  "s_1t_1_1", "s_1h_1t_1", "R_5_0", "R_1_2", "R_2_3", "R_3_4", "R_4_5", "R_4_0",
  "R_3_0", "R_2_0", "R_1_0", "s_5", "s_4", "s_3", "s_2", "s_1", "s_1t", "s_1h",
  "nargin", "nargout", "swjointangles", "Rtrunk", "SegmentLengths", "xz", "J" };

/* Function Declarations */
static void initialize_c11_FootPlacementLibrary
  (SFc11_FootPlacementLibraryInstanceStruct *chartInstance);
static void initialize_params_c11_FootPlacementLibrary
  (SFc11_FootPlacementLibraryInstanceStruct *chartInstance);
static void enable_c11_FootPlacementLibrary
  (SFc11_FootPlacementLibraryInstanceStruct *chartInstance);
static void disable_c11_FootPlacementLibrary
  (SFc11_FootPlacementLibraryInstanceStruct *chartInstance);
static void c11_update_debugger_state_c11_FootPlacementLibrary
  (SFc11_FootPlacementLibraryInstanceStruct *chartInstance);
static const mxArray *get_sim_state_c11_FootPlacementLibrary
  (SFc11_FootPlacementLibraryInstanceStruct *chartInstance);
static void set_sim_state_c11_FootPlacementLibrary
  (SFc11_FootPlacementLibraryInstanceStruct *chartInstance, const mxArray
   *c11_st);
static void finalize_c11_FootPlacementLibrary
  (SFc11_FootPlacementLibraryInstanceStruct *chartInstance);
static void sf_gateway_c11_FootPlacementLibrary
  (SFc11_FootPlacementLibraryInstanceStruct *chartInstance);
static void c11_chartstep_c11_FootPlacementLibrary
  (SFc11_FootPlacementLibraryInstanceStruct *chartInstance);
static void initSimStructsc11_FootPlacementLibrary
  (SFc11_FootPlacementLibraryInstanceStruct *chartInstance);
static void c11_Rz(SFc11_FootPlacementLibraryInstanceStruct *chartInstance,
                   real_T c11_b_q, real_T c11_R[9]);
static void c11_Rx(SFc11_FootPlacementLibraryInstanceStruct *chartInstance,
                   real_T c11_b_q, real_T c11_R[9]);
static void init_script_number_translation(uint32_T c11_machineNumber, uint32_T
  c11_chartNumber, uint32_T c11_instanceNumber);
static const mxArray *c11_sf_marshallOut(void *chartInstanceVoid, void
  *c11_inData);
static void c11_emlrt_marshallIn(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance, const mxArray *c11_b_q, const char_T *c11_identifier, real_T
  c11_y[3]);
static void c11_b_emlrt_marshallIn(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance, const mxArray *c11_u, const emlrtMsgIdentifier *c11_parentId,
  real_T c11_y[3]);
static void c11_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c11_mxArrayInData, const char_T *c11_varName, void *c11_outData);
static const mxArray *c11_b_sf_marshallOut(void *chartInstanceVoid, void
  *c11_inData);
static void c11_c_emlrt_marshallIn(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance, const mxArray *c11_xz, const char_T *c11_identifier, real_T
  c11_y[2]);
static void c11_d_emlrt_marshallIn(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance, const mxArray *c11_u, const emlrtMsgIdentifier *c11_parentId,
  real_T c11_y[2]);
static void c11_b_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c11_mxArrayInData, const char_T *c11_varName, void *c11_outData);
static const mxArray *c11_c_sf_marshallOut(void *chartInstanceVoid, void
  *c11_inData);
static real_T c11_e_emlrt_marshallIn(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance, const mxArray *c11_i, const char_T *c11_identifier);
static real_T c11_f_emlrt_marshallIn(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance, const mxArray *c11_u, const emlrtMsgIdentifier *c11_parentId);
static void c11_c_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c11_mxArrayInData, const char_T *c11_varName, void *c11_outData);
static const mxArray *c11_d_sf_marshallOut(void *chartInstanceVoid, void
  *c11_inData);
static void c11_g_emlrt_marshallIn(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance, const mxArray *c11_Rswjointangles, const char_T
  *c11_identifier, real_T c11_y[3]);
static void c11_h_emlrt_marshallIn(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance, const mxArray *c11_u, const emlrtMsgIdentifier *c11_parentId,
  real_T c11_y[3]);
static void c11_d_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c11_mxArrayInData, const char_T *c11_varName, void *c11_outData);
static const mxArray *c11_e_sf_marshallOut(void *chartInstanceVoid, void
  *c11_inData);
static const mxArray *c11_f_sf_marshallOut(void *chartInstanceVoid, void
  *c11_inData);
static const mxArray *c11_g_sf_marshallOut(void *chartInstanceVoid, void
  *c11_inData);
static const mxArray *c11_h_sf_marshallOut(void *chartInstanceVoid, void
  *c11_inData);
static void c11_i_emlrt_marshallIn(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance, const mxArray *c11_u, const emlrtMsgIdentifier *c11_parentId,
  real_T c11_y[4]);
static void c11_e_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c11_mxArrayInData, const char_T *c11_varName, void *c11_outData);
static void c11_j_emlrt_marshallIn(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance, const mxArray *c11_u, const emlrtMsgIdentifier *c11_parentId,
  real_T c11_y[9]);
static void c11_f_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c11_mxArrayInData, const char_T *c11_varName, void *c11_outData);
static void c11_k_emlrt_marshallIn(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance, const mxArray *c11_u, const emlrtMsgIdentifier *c11_parentId,
  real_T c11_y[13]);
static void c11_g_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c11_mxArrayInData, const char_T *c11_varName, void *c11_outData);
static void c11_info_helper(const mxArray **c11_info);
static const mxArray *c11_emlrt_marshallOut(const char * c11_u);
static const mxArray *c11_b_emlrt_marshallOut(const uint32_T c11_u);
static void c11_fk_KFE_jacobian(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance, real_T c11_swjointangles[3], real_T c11_Rtrunk[9], real_T
  c11_SegmentLengths[13], real_T c11_xz[2]);
static void c11_eml_scalar_eg(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance);
static void c11_threshold(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance);
static void c11_b_eml_scalar_eg(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance);
static void c11_b_fk_KFE_jacobian(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance, real_T c11_swjointangles[3], real_T c11_Rtrunk[9], real_T
  c11_SegmentLengths[13], real_T c11_xz[2], real_T c11_J[4]);
static void c11_eml_warning(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance);
static const mxArray *c11_i_sf_marshallOut(void *chartInstanceVoid, void
  *c11_inData);
static int32_T c11_l_emlrt_marshallIn(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance, const mxArray *c11_u, const emlrtMsgIdentifier *c11_parentId);
static void c11_h_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c11_mxArrayInData, const char_T *c11_varName, void *c11_outData);
static uint8_T c11_m_emlrt_marshallIn(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance, const mxArray *c11_b_is_active_c11_FootPlacementLibrary, const
  char_T *c11_identifier);
static uint8_T c11_n_emlrt_marshallIn(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance, const mxArray *c11_u, const emlrtMsgIdentifier *c11_parentId);
static void init_dsm_address_info(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance);

/* Function Definitions */
static void initialize_c11_FootPlacementLibrary
  (SFc11_FootPlacementLibraryInstanceStruct *chartInstance)
{
  chartInstance->c11_sfEvent = CALL_EVENT;
  _sfTime_ = sf_get_time(chartInstance->S);
  chartInstance->c11_q_not_empty = false;
  chartInstance->c11_is_active_c11_FootPlacementLibrary = 0U;
}

static void initialize_params_c11_FootPlacementLibrary
  (SFc11_FootPlacementLibraryInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void enable_c11_FootPlacementLibrary
  (SFc11_FootPlacementLibraryInstanceStruct *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void disable_c11_FootPlacementLibrary
  (SFc11_FootPlacementLibraryInstanceStruct *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void c11_update_debugger_state_c11_FootPlacementLibrary
  (SFc11_FootPlacementLibraryInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static const mxArray *get_sim_state_c11_FootPlacementLibrary
  (SFc11_FootPlacementLibraryInstanceStruct *chartInstance)
{
  const mxArray *c11_st;
  const mxArray *c11_y = NULL;
  int32_T c11_i0;
  real_T c11_u[3];
  const mxArray *c11_b_y = NULL;
  real_T c11_hoistedGlobal;
  real_T c11_b_u;
  const mxArray *c11_c_y = NULL;
  int32_T c11_i1;
  real_T c11_c_u[2];
  const mxArray *c11_d_y = NULL;
  int32_T c11_i2;
  real_T c11_d_u[3];
  const mxArray *c11_e_y = NULL;
  uint8_T c11_b_hoistedGlobal;
  uint8_T c11_e_u;
  const mxArray *c11_f_y = NULL;
  real_T *c11_i;
  real_T (*c11_xz)[2];
  real_T (*c11_Rswjointangles)[3];
  c11_xz = (real_T (*)[2])ssGetOutputPortSignal(chartInstance->S, 3);
  c11_i = (real_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c11_Rswjointangles = (real_T (*)[3])ssGetOutputPortSignal(chartInstance->S, 1);
  c11_st = NULL;
  c11_st = NULL;
  c11_y = NULL;
  sf_mex_assign(&c11_y, sf_mex_createcellmatrix(5, 1), false);
  for (c11_i0 = 0; c11_i0 < 3; c11_i0++) {
    c11_u[c11_i0] = (*c11_Rswjointangles)[c11_i0];
  }

  c11_b_y = NULL;
  sf_mex_assign(&c11_b_y, sf_mex_create("y", c11_u, 0, 0U, 1U, 0U, 1, 3), false);
  sf_mex_setcell(c11_y, 0, c11_b_y);
  c11_hoistedGlobal = *c11_i;
  c11_b_u = c11_hoistedGlobal;
  c11_c_y = NULL;
  sf_mex_assign(&c11_c_y, sf_mex_create("y", &c11_b_u, 0, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c11_y, 1, c11_c_y);
  for (c11_i1 = 0; c11_i1 < 2; c11_i1++) {
    c11_c_u[c11_i1] = (*c11_xz)[c11_i1];
  }

  c11_d_y = NULL;
  sf_mex_assign(&c11_d_y, sf_mex_create("y", c11_c_u, 0, 0U, 1U, 0U, 1, 2),
                false);
  sf_mex_setcell(c11_y, 2, c11_d_y);
  for (c11_i2 = 0; c11_i2 < 3; c11_i2++) {
    c11_d_u[c11_i2] = chartInstance->c11_q[c11_i2];
  }

  c11_e_y = NULL;
  if (!chartInstance->c11_q_not_empty) {
    sf_mex_assign(&c11_e_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0),
                  false);
  } else {
    sf_mex_assign(&c11_e_y, sf_mex_create("y", c11_d_u, 0, 0U, 1U, 0U, 1, 3),
                  false);
  }

  sf_mex_setcell(c11_y, 3, c11_e_y);
  c11_b_hoistedGlobal = chartInstance->c11_is_active_c11_FootPlacementLibrary;
  c11_e_u = c11_b_hoistedGlobal;
  c11_f_y = NULL;
  sf_mex_assign(&c11_f_y, sf_mex_create("y", &c11_e_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c11_y, 4, c11_f_y);
  sf_mex_assign(&c11_st, c11_y, false);
  return c11_st;
}

static void set_sim_state_c11_FootPlacementLibrary
  (SFc11_FootPlacementLibraryInstanceStruct *chartInstance, const mxArray
   *c11_st)
{
  const mxArray *c11_u;
  real_T c11_dv0[3];
  int32_T c11_i3;
  real_T c11_dv1[2];
  int32_T c11_i4;
  real_T c11_dv2[3];
  int32_T c11_i5;
  real_T *c11_i;
  real_T (*c11_Rswjointangles)[3];
  real_T (*c11_xz)[2];
  c11_xz = (real_T (*)[2])ssGetOutputPortSignal(chartInstance->S, 3);
  c11_i = (real_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c11_Rswjointangles = (real_T (*)[3])ssGetOutputPortSignal(chartInstance->S, 1);
  chartInstance->c11_doneDoubleBufferReInit = true;
  c11_u = sf_mex_dup(c11_st);
  c11_g_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c11_u, 0)),
    "Rswjointangles", c11_dv0);
  for (c11_i3 = 0; c11_i3 < 3; c11_i3++) {
    (*c11_Rswjointangles)[c11_i3] = c11_dv0[c11_i3];
  }

  *c11_i = c11_e_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c11_u,
    1)), "i");
  c11_c_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c11_u, 2)),
    "xz", c11_dv1);
  for (c11_i4 = 0; c11_i4 < 2; c11_i4++) {
    (*c11_xz)[c11_i4] = c11_dv1[c11_i4];
  }

  c11_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c11_u, 3)), "q",
                       c11_dv2);
  for (c11_i5 = 0; c11_i5 < 3; c11_i5++) {
    chartInstance->c11_q[c11_i5] = c11_dv2[c11_i5];
  }

  chartInstance->c11_is_active_c11_FootPlacementLibrary = c11_m_emlrt_marshallIn
    (chartInstance, sf_mex_dup(sf_mex_getcell(c11_u, 4)),
     "is_active_c11_FootPlacementLibrary");
  sf_mex_destroy(&c11_u);
  c11_update_debugger_state_c11_FootPlacementLibrary(chartInstance);
  sf_mex_destroy(&c11_st);
}

static void finalize_c11_FootPlacementLibrary
  (SFc11_FootPlacementLibraryInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void sf_gateway_c11_FootPlacementLibrary
  (SFc11_FootPlacementLibraryInstanceStruct *chartInstance)
{
  int32_T c11_i6;
  int32_T c11_i7;
  int32_T c11_i8;
  int32_T c11_i9;
  int32_T c11_i10;
  int32_T c11_i11;
  int32_T c11_i12;
  int32_T c11_i13;
  real_T *c11_KFE;
  real_T *c11_i;
  real_T (*c11_UB)[3];
  real_T (*c11_LB)[3];
  real_T (*c11_xz)[2];
  real_T (*c11_SegmentLengths)[13];
  real_T (*c11_Rtrunk)[9];
  real_T (*c11_Rswjointangles)[3];
  real_T (*c11_jointangles)[12];
  real_T (*c11_xze)[2];
  c11_UB = (real_T (*)[3])ssGetInputPortSignal(chartInstance->S, 6);
  c11_LB = (real_T (*)[3])ssGetInputPortSignal(chartInstance->S, 5);
  c11_xz = (real_T (*)[2])ssGetOutputPortSignal(chartInstance->S, 3);
  c11_i = (real_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c11_SegmentLengths = (real_T (*)[13])ssGetInputPortSignal(chartInstance->S, 4);
  c11_Rtrunk = (real_T (*)[9])ssGetInputPortSignal(chartInstance->S, 3);
  c11_Rswjointangles = (real_T (*)[3])ssGetOutputPortSignal(chartInstance->S, 1);
  c11_jointangles = (real_T (*)[12])ssGetInputPortSignal(chartInstance->S, 2);
  c11_KFE = (real_T *)ssGetInputPortSignal(chartInstance->S, 1);
  c11_xze = (real_T (*)[2])ssGetInputPortSignal(chartInstance->S, 0);
  _SFD_SYMBOL_SCOPE_PUSH(0U, 0U);
  _sfTime_ = sf_get_time(chartInstance->S);
  _SFD_CC_CALL(CHART_ENTER_SFUNCTION_TAG, 6U, chartInstance->c11_sfEvent);
  for (c11_i6 = 0; c11_i6 < 2; c11_i6++) {
    _SFD_DATA_RANGE_CHECK((*c11_xze)[c11_i6], 0U);
  }

  _SFD_DATA_RANGE_CHECK(*c11_KFE, 1U);
  for (c11_i7 = 0; c11_i7 < 12; c11_i7++) {
    _SFD_DATA_RANGE_CHECK((*c11_jointangles)[c11_i7], 2U);
  }

  chartInstance->c11_sfEvent = CALL_EVENT;
  c11_chartstep_c11_FootPlacementLibrary(chartInstance);
  _SFD_SYMBOL_SCOPE_POP();
  _SFD_CHECK_FOR_STATE_INCONSISTENCY(_FootPlacementLibraryMachineNumber_,
    chartInstance->chartNumber, chartInstance->instanceNumber);
  for (c11_i8 = 0; c11_i8 < 3; c11_i8++) {
    _SFD_DATA_RANGE_CHECK((*c11_Rswjointangles)[c11_i8], 3U);
  }

  for (c11_i9 = 0; c11_i9 < 9; c11_i9++) {
    _SFD_DATA_RANGE_CHECK((*c11_Rtrunk)[c11_i9], 4U);
  }

  for (c11_i10 = 0; c11_i10 < 13; c11_i10++) {
    _SFD_DATA_RANGE_CHECK((*c11_SegmentLengths)[c11_i10], 5U);
  }

  _SFD_DATA_RANGE_CHECK(*c11_i, 6U);
  for (c11_i11 = 0; c11_i11 < 2; c11_i11++) {
    _SFD_DATA_RANGE_CHECK((*c11_xz)[c11_i11], 7U);
  }

  for (c11_i12 = 0; c11_i12 < 3; c11_i12++) {
    _SFD_DATA_RANGE_CHECK((*c11_LB)[c11_i12], 8U);
  }

  for (c11_i13 = 0; c11_i13 < 3; c11_i13++) {
    _SFD_DATA_RANGE_CHECK((*c11_UB)[c11_i13], 9U);
  }
}

static void c11_chartstep_c11_FootPlacementLibrary
  (SFc11_FootPlacementLibraryInstanceStruct *chartInstance)
{
  real_T c11_hoistedGlobal;
  int32_T c11_i14;
  real_T c11_xze[2];
  real_T c11_KFE;
  int32_T c11_i15;
  real_T c11_jointangles[12];
  int32_T c11_i16;
  real_T c11_Rtrunk[9];
  int32_T c11_i17;
  real_T c11_SegmentLengths[13];
  int32_T c11_i18;
  real_T c11_LB[3];
  int32_T c11_i19;
  real_T c11_UB[3];
  uint32_T c11_debug_family_var_map[16];
  real_T c11_J[4];
  real_T c11_dx[2];
  real_T c11_dq[2];
  real_T c11_nargin = 7.0;
  real_T c11_nargout = 3.0;
  real_T c11_Rswjointangles[3];
  real_T c11_i;
  real_T c11_xz[2];
  int32_T c11_i20;
  real_T c11_dv3[3];
  int32_T c11_i21;
  real_T c11_b_Rtrunk[9];
  int32_T c11_i22;
  real_T c11_b_SegmentLengths[13];
  real_T c11_dv4[2];
  int32_T c11_i23;
  int32_T c11_i24;
  real_T c11_dv5[3];
  int32_T c11_i25;
  real_T c11_c_Rtrunk[9];
  int32_T c11_i26;
  real_T c11_c_SegmentLengths[13];
  real_T c11_b_J[4];
  real_T c11_b_xz[2];
  int32_T c11_i27;
  int32_T c11_i28;
  int32_T c11_i29;
  int32_T c11_i30;
  int32_T c11_i31;
  real_T c11_x;
  real_T c11_b_x;
  real_T c11_c_x;
  real_T c11_d_x;
  real_T c11_y;
  real_T c11_e_x;
  real_T c11_f_x;
  real_T c11_b_y;
  real_T c11_d;
  real_T c11_g_x;
  real_T c11_h_x;
  real_T c11_i_x;
  real_T c11_j_x;
  real_T c11_c_y;
  real_T c11_k_x;
  real_T c11_l_x;
  real_T c11_d_y;
  real_T c11_b_d;
  int32_T c11_r1;
  int32_T c11_r2;
  real_T c11_m_x;
  real_T c11_e_y;
  real_T c11_n_x;
  real_T c11_f_y;
  real_T c11_o_x;
  real_T c11_g_y;
  real_T c11_a21;
  real_T c11_a22;
  real_T c11_p_x;
  real_T c11_h_y;
  real_T c11_q_x;
  real_T c11_i_y;
  real_T c11_r_x;
  real_T c11_j_y;
  real_T c11_z;
  real_T c11_s_x;
  real_T c11_k_y;
  real_T c11_t_x;
  real_T c11_l_y;
  real_T c11_u_x;
  real_T c11_m_y;
  real_T c11_b_z;
  int32_T c11_i32;
  int32_T c11_b_i;
  int32_T c11_i33;
  int32_T c11_i34;
  int32_T c11_i35;
  real_T (*c11_c_xz)[2];
  real_T (*c11_b_Rswjointangles)[3];
  real_T *c11_b_KFE;
  real_T *c11_c_i;
  real_T (*c11_b_UB)[3];
  real_T (*c11_b_LB)[3];
  real_T (*c11_d_SegmentLengths)[13];
  real_T (*c11_d_Rtrunk)[9];
  real_T (*c11_b_jointangles)[12];
  real_T (*c11_b_xze)[2];
  boolean_T guard1 = false;
  c11_b_UB = (real_T (*)[3])ssGetInputPortSignal(chartInstance->S, 6);
  c11_b_LB = (real_T (*)[3])ssGetInputPortSignal(chartInstance->S, 5);
  c11_c_xz = (real_T (*)[2])ssGetOutputPortSignal(chartInstance->S, 3);
  c11_c_i = (real_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c11_d_SegmentLengths = (real_T (*)[13])ssGetInputPortSignal(chartInstance->S,
    4);
  c11_d_Rtrunk = (real_T (*)[9])ssGetInputPortSignal(chartInstance->S, 3);
  c11_b_Rswjointangles = (real_T (*)[3])ssGetOutputPortSignal(chartInstance->S,
    1);
  c11_b_jointangles = (real_T (*)[12])ssGetInputPortSignal(chartInstance->S, 2);
  c11_b_KFE = (real_T *)ssGetInputPortSignal(chartInstance->S, 1);
  c11_b_xze = (real_T (*)[2])ssGetInputPortSignal(chartInstance->S, 0);
  _SFD_CC_CALL(CHART_ENTER_DURING_FUNCTION_TAG, 6U, chartInstance->c11_sfEvent);
  c11_hoistedGlobal = *c11_b_KFE;
  for (c11_i14 = 0; c11_i14 < 2; c11_i14++) {
    c11_xze[c11_i14] = (*c11_b_xze)[c11_i14];
  }

  c11_KFE = c11_hoistedGlobal;
  for (c11_i15 = 0; c11_i15 < 12; c11_i15++) {
    c11_jointangles[c11_i15] = (*c11_b_jointangles)[c11_i15];
  }

  for (c11_i16 = 0; c11_i16 < 9; c11_i16++) {
    c11_Rtrunk[c11_i16] = (*c11_d_Rtrunk)[c11_i16];
  }

  for (c11_i17 = 0; c11_i17 < 13; c11_i17++) {
    c11_SegmentLengths[c11_i17] = (*c11_d_SegmentLengths)[c11_i17];
  }

  for (c11_i18 = 0; c11_i18 < 3; c11_i18++) {
    c11_LB[c11_i18] = (*c11_b_LB)[c11_i18];
  }

  for (c11_i19 = 0; c11_i19 < 3; c11_i19++) {
    c11_UB[c11_i19] = (*c11_b_UB)[c11_i19];
  }

  _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 16U, 16U, c11_debug_family_names,
    c11_debug_family_var_map);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_J, 0U, c11_h_sf_marshallOut,
    c11_e_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_dx, 1U, c11_b_sf_marshallOut,
    c11_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_dq, 2U, c11_b_sf_marshallOut,
    c11_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_nargin, 3U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_nargout, 4U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML(c11_xze, 5U, c11_b_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c11_KFE, 6U, c11_c_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(c11_jointangles, 7U, c11_g_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(c11_Rtrunk, 8U, c11_f_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(c11_SegmentLengths, 9U, c11_e_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(c11_LB, 10U, c11_d_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(c11_UB, 11U, c11_d_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_Rswjointangles, 12U,
    c11_d_sf_marshallOut, c11_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_i, 13U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_xz, 14U, c11_b_sf_marshallOut,
    c11_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(chartInstance->c11_q, 15U,
    c11_sf_marshallOut, c11_sf_marshallIn);
  CV_EML_FCN(0, 0);
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 3);
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 4);
  if (CV_EML_IF(0, 1, 0, !chartInstance->c11_q_not_empty)) {
    _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 5);
    chartInstance->c11_q[0] = c11_jointangles[0];
    chartInstance->c11_q[1] = c11_jointangles[1];
    chartInstance->c11_q[2] = c11_KFE;
    chartInstance->c11_q_not_empty = true;
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 9);
  c11_i = 1.0;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 10);
  chartInstance->c11_q[2] = c11_KFE;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 11);
  for (c11_i20 = 0; c11_i20 < 3; c11_i20++) {
    c11_dv3[c11_i20] = chartInstance->c11_q[c11_i20];
  }

  for (c11_i21 = 0; c11_i21 < 9; c11_i21++) {
    c11_b_Rtrunk[c11_i21] = c11_Rtrunk[c11_i21];
  }

  for (c11_i22 = 0; c11_i22 < 13; c11_i22++) {
    c11_b_SegmentLengths[c11_i22] = c11_SegmentLengths[c11_i22];
  }

  c11_fk_KFE_jacobian(chartInstance, c11_dv3, c11_b_Rtrunk, c11_b_SegmentLengths,
                      c11_dv4);
  for (c11_i23 = 0; c11_i23 < 2; c11_i23++) {
    c11_xz[c11_i23] = c11_dv4[c11_i23];
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 12);
  while (CV_EML_WHILE(0, 1, 0, c11_i < 5.0)) {
    _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 13);
    for (c11_i24 = 0; c11_i24 < 3; c11_i24++) {
      c11_dv5[c11_i24] = chartInstance->c11_q[c11_i24];
    }

    for (c11_i25 = 0; c11_i25 < 9; c11_i25++) {
      c11_c_Rtrunk[c11_i25] = c11_Rtrunk[c11_i25];
    }

    for (c11_i26 = 0; c11_i26 < 13; c11_i26++) {
      c11_c_SegmentLengths[c11_i26] = c11_SegmentLengths[c11_i26];
    }

    c11_b_fk_KFE_jacobian(chartInstance, c11_dv5, c11_c_Rtrunk,
                          c11_c_SegmentLengths, c11_b_xz, c11_b_J);
    for (c11_i27 = 0; c11_i27 < 2; c11_i27++) {
      c11_xz[c11_i27] = c11_b_xz[c11_i27];
    }

    for (c11_i28 = 0; c11_i28 < 4; c11_i28++) {
      c11_J[c11_i28] = c11_b_J[c11_i28];
    }

    _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 14);
    for (c11_i29 = 0; c11_i29 < 2; c11_i29++) {
      c11_dx[c11_i29] = c11_xze[c11_i29] - c11_xz[c11_i29];
    }

    _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 15);
    for (c11_i30 = 0; c11_i30 < 4; c11_i30++) {
      c11_b_J[c11_i30] = c11_J[c11_i30];
    }

    for (c11_i31 = 0; c11_i31 < 2; c11_i31++) {
      c11_b_xz[c11_i31] = c11_dx[c11_i31];
    }

    c11_x = c11_b_J[1];
    c11_b_x = c11_x;
    c11_c_x = c11_b_x;
    c11_d_x = c11_c_x;
    c11_y = muDoubleScalarAbs(c11_d_x);
    c11_e_x = 0.0;
    c11_f_x = c11_e_x;
    c11_b_y = muDoubleScalarAbs(c11_f_x);
    c11_d = c11_y + c11_b_y;
    c11_g_x = c11_b_J[0];
    c11_h_x = c11_g_x;
    c11_i_x = c11_h_x;
    c11_j_x = c11_i_x;
    c11_c_y = muDoubleScalarAbs(c11_j_x);
    c11_k_x = 0.0;
    c11_l_x = c11_k_x;
    c11_d_y = muDoubleScalarAbs(c11_l_x);
    c11_b_d = c11_c_y + c11_d_y;
    if (c11_d > c11_b_d) {
      c11_r1 = 2;
      c11_r2 = 1;
    } else {
      c11_r1 = 1;
      c11_r2 = 2;
    }

    c11_m_x = c11_b_J[_SFD_EML_ARRAY_BOUNDS_CHECK("", (int32_T)
      _SFD_INTEGER_CHECK("", (real_T)c11_r2), 1, 2, 1, 0) - 1];
    c11_e_y = c11_b_J[_SFD_EML_ARRAY_BOUNDS_CHECK("", (int32_T)
      _SFD_INTEGER_CHECK("", (real_T)c11_r1), 1, 2, 1, 0) - 1];
    c11_n_x = c11_m_x;
    c11_f_y = c11_e_y;
    c11_o_x = c11_n_x;
    c11_g_y = c11_f_y;
    c11_a21 = c11_o_x / c11_g_y;
    c11_a22 = c11_b_J[_SFD_EML_ARRAY_BOUNDS_CHECK("", (int32_T)
      _SFD_INTEGER_CHECK("", (real_T)c11_r2), 1, 2, 1, 0) + 1] - c11_a21 *
      c11_b_J[_SFD_EML_ARRAY_BOUNDS_CHECK("", (int32_T)_SFD_INTEGER_CHECK("",
      (real_T)c11_r1), 1, 2, 1, 0) + 1];
    guard1 = false;
    if (c11_a22 == 0.0) {
      guard1 = true;
    } else {
      if (c11_b_J[_SFD_EML_ARRAY_BOUNDS_CHECK("", (int32_T)_SFD_INTEGER_CHECK("",
            (real_T)c11_r1), 1, 2, 1, 0) - 1] == 0.0) {
        guard1 = true;
      }
    }

    if (guard1 == true) {
      c11_eml_warning(chartInstance);
    }

    c11_p_x = c11_b_xz[_SFD_EML_ARRAY_BOUNDS_CHECK("", (int32_T)
      _SFD_INTEGER_CHECK("", (real_T)c11_r2), 1, 2, 1, 0) - 1] -
      c11_b_xz[_SFD_EML_ARRAY_BOUNDS_CHECK("", (int32_T)_SFD_INTEGER_CHECK("",
      (real_T)c11_r1), 1, 2, 1, 0) - 1] * c11_a21;
    c11_h_y = c11_a22;
    c11_q_x = c11_p_x;
    c11_i_y = c11_h_y;
    c11_r_x = c11_q_x;
    c11_j_y = c11_i_y;
    c11_z = c11_r_x / c11_j_y;
    c11_dq[1] = c11_z;
    c11_s_x = c11_b_xz[_SFD_EML_ARRAY_BOUNDS_CHECK("", (int32_T)
      _SFD_INTEGER_CHECK("", (real_T)c11_r1), 1, 2, 1, 0) - 1] - c11_dq[1] *
      c11_b_J[_SFD_EML_ARRAY_BOUNDS_CHECK("", (int32_T)_SFD_INTEGER_CHECK("",
      (real_T)c11_r1), 1, 2, 1, 0) + 1];
    c11_k_y = c11_b_J[_SFD_EML_ARRAY_BOUNDS_CHECK("", (int32_T)
      _SFD_INTEGER_CHECK("", (real_T)c11_r1), 1, 2, 1, 0) - 1];
    c11_t_x = c11_s_x;
    c11_l_y = c11_k_y;
    c11_u_x = c11_t_x;
    c11_m_y = c11_l_y;
    c11_b_z = c11_u_x / c11_m_y;
    c11_dq[0] = c11_b_z;
    _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 16);
    for (c11_i32 = 0; c11_i32 < 2; c11_i32++) {
      chartInstance->c11_q[c11_i32] += c11_dq[c11_i32];
    }

    _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 17);
    c11_i++;
    _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 12);
    _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 19);
  c11_i = 1.0;
  c11_b_i = 0;
  while (c11_b_i < 3) {
    c11_i = 1.0 + (real_T)c11_b_i;
    CV_EML_FOR(0, 1, 0, 1);
    _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 20);
    if (CV_EML_IF(0, 1, 1, chartInstance->c11_q[_SFD_EML_ARRAY_BOUNDS_CHECK("q",
          (int32_T)_SFD_INTEGER_CHECK("i", c11_i), 1, 3, 1, 0) - 1] <
                  c11_LB[_SFD_EML_ARRAY_BOUNDS_CHECK("LB", (int32_T)
          _SFD_INTEGER_CHECK("i", c11_i), 1, 3, 1, 0) - 1])) {
      _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 21);
      chartInstance->c11_q[_SFD_EML_ARRAY_BOUNDS_CHECK("q", (int32_T)
        _SFD_INTEGER_CHECK("i", c11_i), 1, 3, 1, 0) - 1] =
        c11_LB[_SFD_EML_ARRAY_BOUNDS_CHECK("LB", (int32_T)_SFD_INTEGER_CHECK("i",
        c11_i), 1, 3, 1, 0) - 1];
    } else {
      _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 22);
      if (CV_EML_IF(0, 1, 2, chartInstance->c11_q[_SFD_EML_ARRAY_BOUNDS_CHECK(
            "q", (int32_T)_SFD_INTEGER_CHECK("i", c11_i), 1, 3, 1, 0) - 1] >
                    c11_UB[_SFD_EML_ARRAY_BOUNDS_CHECK("UB", (int32_T)
            _SFD_INTEGER_CHECK("i", c11_i), 1, 3, 1, 0) - 1])) {
        _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 23);
        chartInstance->c11_q[_SFD_EML_ARRAY_BOUNDS_CHECK("q", (int32_T)
          _SFD_INTEGER_CHECK("i", c11_i), 1, 3, 1, 0) - 1] =
          c11_UB[_SFD_EML_ARRAY_BOUNDS_CHECK("UB", (int32_T)_SFD_INTEGER_CHECK(
          "i", c11_i), 1, 3, 1, 0) - 1];
      }
    }

    c11_b_i++;
    _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
  }

  CV_EML_FOR(0, 1, 0, 0);
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 26);
  for (c11_i33 = 0; c11_i33 < 3; c11_i33++) {
    c11_Rswjointangles[c11_i33] = chartInstance->c11_q[c11_i33];
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, -26);
  _SFD_SYMBOL_SCOPE_POP();
  for (c11_i34 = 0; c11_i34 < 3; c11_i34++) {
    (*c11_b_Rswjointangles)[c11_i34] = c11_Rswjointangles[c11_i34];
  }

  *c11_c_i = c11_i;
  for (c11_i35 = 0; c11_i35 < 2; c11_i35++) {
    (*c11_c_xz)[c11_i35] = c11_xz[c11_i35];
  }

  _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG, 6U, chartInstance->c11_sfEvent);
}

static void initSimStructsc11_FootPlacementLibrary
  (SFc11_FootPlacementLibraryInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void c11_Rz(SFc11_FootPlacementLibraryInstanceStruct *chartInstance,
                   real_T c11_b_q, real_T c11_R[9])
{
  uint32_T c11_debug_family_var_map[6];
  real_T c11_s;
  real_T c11_c;
  real_T c11_nargin = 1.0;
  real_T c11_nargout = 1.0;
  real_T c11_x;
  real_T c11_b_x;
  real_T c11_c_x;
  real_T c11_d_x;
  int32_T c11_i36;
  int32_T c11_i37;
  static real_T c11_dv6[3] = { 0.0, 0.0, 1.0 };

  _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 6U, 6U, c11_b_debug_family_names,
    c11_debug_family_var_map);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_s, 0U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_c, 1U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_nargin, 2U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_nargout, 3U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_b_q, 4U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_R, 5U, c11_f_sf_marshallOut,
    c11_f_sf_marshallIn);
  CV_SCRIPT_FCN(0, 0);
  _SFD_SCRIPT_CALL(0U, chartInstance->c11_sfEvent, 3);
  c11_x = c11_b_q;
  c11_s = c11_x;
  c11_b_x = c11_s;
  c11_s = c11_b_x;
  c11_s = muDoubleScalarSin(c11_s);
  _SFD_SCRIPT_CALL(0U, chartInstance->c11_sfEvent, 4);
  c11_c_x = c11_b_q;
  c11_c = c11_c_x;
  c11_d_x = c11_c;
  c11_c = c11_d_x;
  c11_c = muDoubleScalarCos(c11_c);
  _SFD_SCRIPT_CALL(0U, chartInstance->c11_sfEvent, 6);
  c11_R[0] = c11_c;
  c11_R[3] = c11_s;
  c11_R[6] = 0.0;
  c11_R[1] = -c11_s;
  c11_R[4] = c11_c;
  c11_R[7] = 0.0;
  c11_i36 = 0;
  for (c11_i37 = 0; c11_i37 < 3; c11_i37++) {
    c11_R[c11_i36 + 2] = c11_dv6[c11_i37];
    c11_i36 += 3;
  }

  _SFD_SCRIPT_CALL(0U, chartInstance->c11_sfEvent, -6);
  _SFD_SYMBOL_SCOPE_POP();
}

static void c11_Rx(SFc11_FootPlacementLibraryInstanceStruct *chartInstance,
                   real_T c11_b_q, real_T c11_R[9])
{
  uint32_T c11_debug_family_var_map[6];
  real_T c11_s;
  real_T c11_c;
  real_T c11_nargin = 1.0;
  real_T c11_nargout = 1.0;
  real_T c11_x;
  real_T c11_b_x;
  real_T c11_c_x;
  real_T c11_d_x;
  int32_T c11_i38;
  int32_T c11_i39;
  static real_T c11_dv7[3] = { 1.0, 0.0, 0.0 };

  _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 6U, 6U, c11_d_debug_family_names,
    c11_debug_family_var_map);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_s, 0U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_c, 1U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_nargin, 2U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_nargout, 3U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_b_q, 4U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_R, 5U, c11_f_sf_marshallOut,
    c11_f_sf_marshallIn);
  CV_SCRIPT_FCN(2, 0);
  _SFD_SCRIPT_CALL(2U, chartInstance->c11_sfEvent, 3);
  c11_x = c11_b_q;
  c11_s = c11_x;
  c11_b_x = c11_s;
  c11_s = c11_b_x;
  c11_s = muDoubleScalarSin(c11_s);
  _SFD_SCRIPT_CALL(2U, chartInstance->c11_sfEvent, 4);
  c11_c_x = c11_b_q;
  c11_c = c11_c_x;
  c11_d_x = c11_c;
  c11_c = c11_d_x;
  c11_c = muDoubleScalarCos(c11_c);
  _SFD_SCRIPT_CALL(2U, chartInstance->c11_sfEvent, 6);
  c11_i38 = 0;
  for (c11_i39 = 0; c11_i39 < 3; c11_i39++) {
    c11_R[c11_i38] = c11_dv7[c11_i39];
    c11_i38 += 3;
  }

  c11_R[1] = 0.0;
  c11_R[4] = c11_c;
  c11_R[7] = c11_s;
  c11_R[2] = 0.0;
  c11_R[5] = -c11_s;
  c11_R[8] = c11_c;
  _SFD_SCRIPT_CALL(2U, chartInstance->c11_sfEvent, -6);
  _SFD_SYMBOL_SCOPE_POP();
}

static void init_script_number_translation(uint32_T c11_machineNumber, uint32_T
  c11_chartNumber, uint32_T c11_instanceNumber)
{
  (void)c11_machineNumber;
  _SFD_SCRIPT_TRANSLATION(c11_chartNumber, c11_instanceNumber, 0U,
    sf_debug_get_script_id(
    "/Users/martijndekker/Dropbox/Mechanical Engineering/Mindwalker Controllers/Mindwalker Matlab/FootPlacementLibrary/Rz.m"));
  _SFD_SCRIPT_TRANSLATION(c11_chartNumber, c11_instanceNumber, 1U,
    sf_debug_get_script_id(
    "/Users/martijndekker/Dropbox/Mechanical Engineering/Mindwalker Controllers/Mindwalker Matlab/FootPlacementLibrary/Ry.m"));
  _SFD_SCRIPT_TRANSLATION(c11_chartNumber, c11_instanceNumber, 2U,
    sf_debug_get_script_id(
    "/Users/martijndekker/Dropbox/Mechanical Engineering/Mindwalker Controllers/Mindwalker Matlab/FootPlacementLibrary/Rx.m"));
}

static const mxArray *c11_sf_marshallOut(void *chartInstanceVoid, void
  *c11_inData)
{
  const mxArray *c11_mxArrayOutData = NULL;
  int32_T c11_i40;
  real_T c11_b_inData[3];
  int32_T c11_i41;
  real_T c11_u[3];
  const mxArray *c11_y = NULL;
  SFc11_FootPlacementLibraryInstanceStruct *chartInstance;
  chartInstance = (SFc11_FootPlacementLibraryInstanceStruct *)chartInstanceVoid;
  c11_mxArrayOutData = NULL;
  for (c11_i40 = 0; c11_i40 < 3; c11_i40++) {
    c11_b_inData[c11_i40] = (*(real_T (*)[3])c11_inData)[c11_i40];
  }

  for (c11_i41 = 0; c11_i41 < 3; c11_i41++) {
    c11_u[c11_i41] = c11_b_inData[c11_i41];
  }

  c11_y = NULL;
  if (!chartInstance->c11_q_not_empty) {
    sf_mex_assign(&c11_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0),
                  false);
  } else {
    sf_mex_assign(&c11_y, sf_mex_create("y", c11_u, 0, 0U, 1U, 0U, 1, 3), false);
  }

  sf_mex_assign(&c11_mxArrayOutData, c11_y, false);
  return c11_mxArrayOutData;
}

static void c11_emlrt_marshallIn(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance, const mxArray *c11_b_q, const char_T *c11_identifier, real_T
  c11_y[3])
{
  emlrtMsgIdentifier c11_thisId;
  c11_thisId.fIdentifier = c11_identifier;
  c11_thisId.fParent = NULL;
  c11_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c11_b_q), &c11_thisId, c11_y);
  sf_mex_destroy(&c11_b_q);
}

static void c11_b_emlrt_marshallIn(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance, const mxArray *c11_u, const emlrtMsgIdentifier *c11_parentId,
  real_T c11_y[3])
{
  real_T c11_dv8[3];
  int32_T c11_i42;
  if (mxIsEmpty(c11_u)) {
    chartInstance->c11_q_not_empty = false;
  } else {
    chartInstance->c11_q_not_empty = true;
    sf_mex_import(c11_parentId, sf_mex_dup(c11_u), c11_dv8, 1, 0, 0U, 1, 0U, 1,
                  3);
    for (c11_i42 = 0; c11_i42 < 3; c11_i42++) {
      c11_y[c11_i42] = c11_dv8[c11_i42];
    }
  }

  sf_mex_destroy(&c11_u);
}

static void c11_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c11_mxArrayInData, const char_T *c11_varName, void *c11_outData)
{
  const mxArray *c11_b_q;
  const char_T *c11_identifier;
  emlrtMsgIdentifier c11_thisId;
  real_T c11_y[3];
  int32_T c11_i43;
  SFc11_FootPlacementLibraryInstanceStruct *chartInstance;
  chartInstance = (SFc11_FootPlacementLibraryInstanceStruct *)chartInstanceVoid;
  c11_b_q = sf_mex_dup(c11_mxArrayInData);
  c11_identifier = c11_varName;
  c11_thisId.fIdentifier = c11_identifier;
  c11_thisId.fParent = NULL;
  c11_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c11_b_q), &c11_thisId, c11_y);
  sf_mex_destroy(&c11_b_q);
  for (c11_i43 = 0; c11_i43 < 3; c11_i43++) {
    (*(real_T (*)[3])c11_outData)[c11_i43] = c11_y[c11_i43];
  }

  sf_mex_destroy(&c11_mxArrayInData);
}

static const mxArray *c11_b_sf_marshallOut(void *chartInstanceVoid, void
  *c11_inData)
{
  const mxArray *c11_mxArrayOutData = NULL;
  int32_T c11_i44;
  real_T c11_b_inData[2];
  int32_T c11_i45;
  real_T c11_u[2];
  const mxArray *c11_y = NULL;
  SFc11_FootPlacementLibraryInstanceStruct *chartInstance;
  chartInstance = (SFc11_FootPlacementLibraryInstanceStruct *)chartInstanceVoid;
  c11_mxArrayOutData = NULL;
  for (c11_i44 = 0; c11_i44 < 2; c11_i44++) {
    c11_b_inData[c11_i44] = (*(real_T (*)[2])c11_inData)[c11_i44];
  }

  for (c11_i45 = 0; c11_i45 < 2; c11_i45++) {
    c11_u[c11_i45] = c11_b_inData[c11_i45];
  }

  c11_y = NULL;
  sf_mex_assign(&c11_y, sf_mex_create("y", c11_u, 0, 0U, 1U, 0U, 1, 2), false);
  sf_mex_assign(&c11_mxArrayOutData, c11_y, false);
  return c11_mxArrayOutData;
}

static void c11_c_emlrt_marshallIn(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance, const mxArray *c11_xz, const char_T *c11_identifier, real_T
  c11_y[2])
{
  emlrtMsgIdentifier c11_thisId;
  c11_thisId.fIdentifier = c11_identifier;
  c11_thisId.fParent = NULL;
  c11_d_emlrt_marshallIn(chartInstance, sf_mex_dup(c11_xz), &c11_thisId, c11_y);
  sf_mex_destroy(&c11_xz);
}

static void c11_d_emlrt_marshallIn(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance, const mxArray *c11_u, const emlrtMsgIdentifier *c11_parentId,
  real_T c11_y[2])
{
  real_T c11_dv9[2];
  int32_T c11_i46;
  (void)chartInstance;
  sf_mex_import(c11_parentId, sf_mex_dup(c11_u), c11_dv9, 1, 0, 0U, 1, 0U, 1, 2);
  for (c11_i46 = 0; c11_i46 < 2; c11_i46++) {
    c11_y[c11_i46] = c11_dv9[c11_i46];
  }

  sf_mex_destroy(&c11_u);
}

static void c11_b_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c11_mxArrayInData, const char_T *c11_varName, void *c11_outData)
{
  const mxArray *c11_xz;
  const char_T *c11_identifier;
  emlrtMsgIdentifier c11_thisId;
  real_T c11_y[2];
  int32_T c11_i47;
  SFc11_FootPlacementLibraryInstanceStruct *chartInstance;
  chartInstance = (SFc11_FootPlacementLibraryInstanceStruct *)chartInstanceVoid;
  c11_xz = sf_mex_dup(c11_mxArrayInData);
  c11_identifier = c11_varName;
  c11_thisId.fIdentifier = c11_identifier;
  c11_thisId.fParent = NULL;
  c11_d_emlrt_marshallIn(chartInstance, sf_mex_dup(c11_xz), &c11_thisId, c11_y);
  sf_mex_destroy(&c11_xz);
  for (c11_i47 = 0; c11_i47 < 2; c11_i47++) {
    (*(real_T (*)[2])c11_outData)[c11_i47] = c11_y[c11_i47];
  }

  sf_mex_destroy(&c11_mxArrayInData);
}

static const mxArray *c11_c_sf_marshallOut(void *chartInstanceVoid, void
  *c11_inData)
{
  const mxArray *c11_mxArrayOutData = NULL;
  real_T c11_u;
  const mxArray *c11_y = NULL;
  SFc11_FootPlacementLibraryInstanceStruct *chartInstance;
  chartInstance = (SFc11_FootPlacementLibraryInstanceStruct *)chartInstanceVoid;
  c11_mxArrayOutData = NULL;
  c11_u = *(real_T *)c11_inData;
  c11_y = NULL;
  sf_mex_assign(&c11_y, sf_mex_create("y", &c11_u, 0, 0U, 0U, 0U, 0), false);
  sf_mex_assign(&c11_mxArrayOutData, c11_y, false);
  return c11_mxArrayOutData;
}

static real_T c11_e_emlrt_marshallIn(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance, const mxArray *c11_i, const char_T *c11_identifier)
{
  real_T c11_y;
  emlrtMsgIdentifier c11_thisId;
  c11_thisId.fIdentifier = c11_identifier;
  c11_thisId.fParent = NULL;
  c11_y = c11_f_emlrt_marshallIn(chartInstance, sf_mex_dup(c11_i), &c11_thisId);
  sf_mex_destroy(&c11_i);
  return c11_y;
}

static real_T c11_f_emlrt_marshallIn(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance, const mxArray *c11_u, const emlrtMsgIdentifier *c11_parentId)
{
  real_T c11_y;
  real_T c11_d0;
  (void)chartInstance;
  sf_mex_import(c11_parentId, sf_mex_dup(c11_u), &c11_d0, 1, 0, 0U, 0, 0U, 0);
  c11_y = c11_d0;
  sf_mex_destroy(&c11_u);
  return c11_y;
}

static void c11_c_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c11_mxArrayInData, const char_T *c11_varName, void *c11_outData)
{
  const mxArray *c11_i;
  const char_T *c11_identifier;
  emlrtMsgIdentifier c11_thisId;
  real_T c11_y;
  SFc11_FootPlacementLibraryInstanceStruct *chartInstance;
  chartInstance = (SFc11_FootPlacementLibraryInstanceStruct *)chartInstanceVoid;
  c11_i = sf_mex_dup(c11_mxArrayInData);
  c11_identifier = c11_varName;
  c11_thisId.fIdentifier = c11_identifier;
  c11_thisId.fParent = NULL;
  c11_y = c11_f_emlrt_marshallIn(chartInstance, sf_mex_dup(c11_i), &c11_thisId);
  sf_mex_destroy(&c11_i);
  *(real_T *)c11_outData = c11_y;
  sf_mex_destroy(&c11_mxArrayInData);
}

static const mxArray *c11_d_sf_marshallOut(void *chartInstanceVoid, void
  *c11_inData)
{
  const mxArray *c11_mxArrayOutData = NULL;
  int32_T c11_i48;
  real_T c11_b_inData[3];
  int32_T c11_i49;
  real_T c11_u[3];
  const mxArray *c11_y = NULL;
  SFc11_FootPlacementLibraryInstanceStruct *chartInstance;
  chartInstance = (SFc11_FootPlacementLibraryInstanceStruct *)chartInstanceVoid;
  c11_mxArrayOutData = NULL;
  for (c11_i48 = 0; c11_i48 < 3; c11_i48++) {
    c11_b_inData[c11_i48] = (*(real_T (*)[3])c11_inData)[c11_i48];
  }

  for (c11_i49 = 0; c11_i49 < 3; c11_i49++) {
    c11_u[c11_i49] = c11_b_inData[c11_i49];
  }

  c11_y = NULL;
  sf_mex_assign(&c11_y, sf_mex_create("y", c11_u, 0, 0U, 1U, 0U, 1, 3), false);
  sf_mex_assign(&c11_mxArrayOutData, c11_y, false);
  return c11_mxArrayOutData;
}

static void c11_g_emlrt_marshallIn(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance, const mxArray *c11_Rswjointangles, const char_T
  *c11_identifier, real_T c11_y[3])
{
  emlrtMsgIdentifier c11_thisId;
  c11_thisId.fIdentifier = c11_identifier;
  c11_thisId.fParent = NULL;
  c11_h_emlrt_marshallIn(chartInstance, sf_mex_dup(c11_Rswjointangles),
    &c11_thisId, c11_y);
  sf_mex_destroy(&c11_Rswjointangles);
}

static void c11_h_emlrt_marshallIn(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance, const mxArray *c11_u, const emlrtMsgIdentifier *c11_parentId,
  real_T c11_y[3])
{
  real_T c11_dv10[3];
  int32_T c11_i50;
  (void)chartInstance;
  sf_mex_import(c11_parentId, sf_mex_dup(c11_u), c11_dv10, 1, 0, 0U, 1, 0U, 1, 3);
  for (c11_i50 = 0; c11_i50 < 3; c11_i50++) {
    c11_y[c11_i50] = c11_dv10[c11_i50];
  }

  sf_mex_destroy(&c11_u);
}

static void c11_d_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c11_mxArrayInData, const char_T *c11_varName, void *c11_outData)
{
  const mxArray *c11_Rswjointangles;
  const char_T *c11_identifier;
  emlrtMsgIdentifier c11_thisId;
  real_T c11_y[3];
  int32_T c11_i51;
  SFc11_FootPlacementLibraryInstanceStruct *chartInstance;
  chartInstance = (SFc11_FootPlacementLibraryInstanceStruct *)chartInstanceVoid;
  c11_Rswjointangles = sf_mex_dup(c11_mxArrayInData);
  c11_identifier = c11_varName;
  c11_thisId.fIdentifier = c11_identifier;
  c11_thisId.fParent = NULL;
  c11_h_emlrt_marshallIn(chartInstance, sf_mex_dup(c11_Rswjointangles),
    &c11_thisId, c11_y);
  sf_mex_destroy(&c11_Rswjointangles);
  for (c11_i51 = 0; c11_i51 < 3; c11_i51++) {
    (*(real_T (*)[3])c11_outData)[c11_i51] = c11_y[c11_i51];
  }

  sf_mex_destroy(&c11_mxArrayInData);
}

static const mxArray *c11_e_sf_marshallOut(void *chartInstanceVoid, void
  *c11_inData)
{
  const mxArray *c11_mxArrayOutData = NULL;
  int32_T c11_i52;
  real_T c11_b_inData[13];
  int32_T c11_i53;
  real_T c11_u[13];
  const mxArray *c11_y = NULL;
  SFc11_FootPlacementLibraryInstanceStruct *chartInstance;
  chartInstance = (SFc11_FootPlacementLibraryInstanceStruct *)chartInstanceVoid;
  c11_mxArrayOutData = NULL;
  for (c11_i52 = 0; c11_i52 < 13; c11_i52++) {
    c11_b_inData[c11_i52] = (*(real_T (*)[13])c11_inData)[c11_i52];
  }

  for (c11_i53 = 0; c11_i53 < 13; c11_i53++) {
    c11_u[c11_i53] = c11_b_inData[c11_i53];
  }

  c11_y = NULL;
  sf_mex_assign(&c11_y, sf_mex_create("y", c11_u, 0, 0U, 1U, 0U, 1, 13), false);
  sf_mex_assign(&c11_mxArrayOutData, c11_y, false);
  return c11_mxArrayOutData;
}

static const mxArray *c11_f_sf_marshallOut(void *chartInstanceVoid, void
  *c11_inData)
{
  const mxArray *c11_mxArrayOutData = NULL;
  int32_T c11_i54;
  int32_T c11_i55;
  int32_T c11_i56;
  real_T c11_b_inData[9];
  int32_T c11_i57;
  int32_T c11_i58;
  int32_T c11_i59;
  real_T c11_u[9];
  const mxArray *c11_y = NULL;
  SFc11_FootPlacementLibraryInstanceStruct *chartInstance;
  chartInstance = (SFc11_FootPlacementLibraryInstanceStruct *)chartInstanceVoid;
  c11_mxArrayOutData = NULL;
  c11_i54 = 0;
  for (c11_i55 = 0; c11_i55 < 3; c11_i55++) {
    for (c11_i56 = 0; c11_i56 < 3; c11_i56++) {
      c11_b_inData[c11_i56 + c11_i54] = (*(real_T (*)[9])c11_inData)[c11_i56 +
        c11_i54];
    }

    c11_i54 += 3;
  }

  c11_i57 = 0;
  for (c11_i58 = 0; c11_i58 < 3; c11_i58++) {
    for (c11_i59 = 0; c11_i59 < 3; c11_i59++) {
      c11_u[c11_i59 + c11_i57] = c11_b_inData[c11_i59 + c11_i57];
    }

    c11_i57 += 3;
  }

  c11_y = NULL;
  sf_mex_assign(&c11_y, sf_mex_create("y", c11_u, 0, 0U, 1U, 0U, 2, 3, 3), false);
  sf_mex_assign(&c11_mxArrayOutData, c11_y, false);
  return c11_mxArrayOutData;
}

static const mxArray *c11_g_sf_marshallOut(void *chartInstanceVoid, void
  *c11_inData)
{
  const mxArray *c11_mxArrayOutData = NULL;
  int32_T c11_i60;
  real_T c11_b_inData[12];
  int32_T c11_i61;
  real_T c11_u[12];
  const mxArray *c11_y = NULL;
  SFc11_FootPlacementLibraryInstanceStruct *chartInstance;
  chartInstance = (SFc11_FootPlacementLibraryInstanceStruct *)chartInstanceVoid;
  c11_mxArrayOutData = NULL;
  for (c11_i60 = 0; c11_i60 < 12; c11_i60++) {
    c11_b_inData[c11_i60] = (*(real_T (*)[12])c11_inData)[c11_i60];
  }

  for (c11_i61 = 0; c11_i61 < 12; c11_i61++) {
    c11_u[c11_i61] = c11_b_inData[c11_i61];
  }

  c11_y = NULL;
  sf_mex_assign(&c11_y, sf_mex_create("y", c11_u, 0, 0U, 1U, 0U, 1, 12), false);
  sf_mex_assign(&c11_mxArrayOutData, c11_y, false);
  return c11_mxArrayOutData;
}

static const mxArray *c11_h_sf_marshallOut(void *chartInstanceVoid, void
  *c11_inData)
{
  const mxArray *c11_mxArrayOutData = NULL;
  int32_T c11_i62;
  int32_T c11_i63;
  int32_T c11_i64;
  real_T c11_b_inData[4];
  int32_T c11_i65;
  int32_T c11_i66;
  int32_T c11_i67;
  real_T c11_u[4];
  const mxArray *c11_y = NULL;
  SFc11_FootPlacementLibraryInstanceStruct *chartInstance;
  chartInstance = (SFc11_FootPlacementLibraryInstanceStruct *)chartInstanceVoid;
  c11_mxArrayOutData = NULL;
  c11_i62 = 0;
  for (c11_i63 = 0; c11_i63 < 2; c11_i63++) {
    for (c11_i64 = 0; c11_i64 < 2; c11_i64++) {
      c11_b_inData[c11_i64 + c11_i62] = (*(real_T (*)[4])c11_inData)[c11_i64 +
        c11_i62];
    }

    c11_i62 += 2;
  }

  c11_i65 = 0;
  for (c11_i66 = 0; c11_i66 < 2; c11_i66++) {
    for (c11_i67 = 0; c11_i67 < 2; c11_i67++) {
      c11_u[c11_i67 + c11_i65] = c11_b_inData[c11_i67 + c11_i65];
    }

    c11_i65 += 2;
  }

  c11_y = NULL;
  sf_mex_assign(&c11_y, sf_mex_create("y", c11_u, 0, 0U, 1U, 0U, 2, 2, 2), false);
  sf_mex_assign(&c11_mxArrayOutData, c11_y, false);
  return c11_mxArrayOutData;
}

static void c11_i_emlrt_marshallIn(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance, const mxArray *c11_u, const emlrtMsgIdentifier *c11_parentId,
  real_T c11_y[4])
{
  real_T c11_dv11[4];
  int32_T c11_i68;
  (void)chartInstance;
  sf_mex_import(c11_parentId, sf_mex_dup(c11_u), c11_dv11, 1, 0, 0U, 1, 0U, 2, 2,
                2);
  for (c11_i68 = 0; c11_i68 < 4; c11_i68++) {
    c11_y[c11_i68] = c11_dv11[c11_i68];
  }

  sf_mex_destroy(&c11_u);
}

static void c11_e_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c11_mxArrayInData, const char_T *c11_varName, void *c11_outData)
{
  const mxArray *c11_J;
  const char_T *c11_identifier;
  emlrtMsgIdentifier c11_thisId;
  real_T c11_y[4];
  int32_T c11_i69;
  int32_T c11_i70;
  int32_T c11_i71;
  SFc11_FootPlacementLibraryInstanceStruct *chartInstance;
  chartInstance = (SFc11_FootPlacementLibraryInstanceStruct *)chartInstanceVoid;
  c11_J = sf_mex_dup(c11_mxArrayInData);
  c11_identifier = c11_varName;
  c11_thisId.fIdentifier = c11_identifier;
  c11_thisId.fParent = NULL;
  c11_i_emlrt_marshallIn(chartInstance, sf_mex_dup(c11_J), &c11_thisId, c11_y);
  sf_mex_destroy(&c11_J);
  c11_i69 = 0;
  for (c11_i70 = 0; c11_i70 < 2; c11_i70++) {
    for (c11_i71 = 0; c11_i71 < 2; c11_i71++) {
      (*(real_T (*)[4])c11_outData)[c11_i71 + c11_i69] = c11_y[c11_i71 + c11_i69];
    }

    c11_i69 += 2;
  }

  sf_mex_destroy(&c11_mxArrayInData);
}

static void c11_j_emlrt_marshallIn(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance, const mxArray *c11_u, const emlrtMsgIdentifier *c11_parentId,
  real_T c11_y[9])
{
  real_T c11_dv12[9];
  int32_T c11_i72;
  (void)chartInstance;
  sf_mex_import(c11_parentId, sf_mex_dup(c11_u), c11_dv12, 1, 0, 0U, 1, 0U, 2, 3,
                3);
  for (c11_i72 = 0; c11_i72 < 9; c11_i72++) {
    c11_y[c11_i72] = c11_dv12[c11_i72];
  }

  sf_mex_destroy(&c11_u);
}

static void c11_f_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c11_mxArrayInData, const char_T *c11_varName, void *c11_outData)
{
  const mxArray *c11_R;
  const char_T *c11_identifier;
  emlrtMsgIdentifier c11_thisId;
  real_T c11_y[9];
  int32_T c11_i73;
  int32_T c11_i74;
  int32_T c11_i75;
  SFc11_FootPlacementLibraryInstanceStruct *chartInstance;
  chartInstance = (SFc11_FootPlacementLibraryInstanceStruct *)chartInstanceVoid;
  c11_R = sf_mex_dup(c11_mxArrayInData);
  c11_identifier = c11_varName;
  c11_thisId.fIdentifier = c11_identifier;
  c11_thisId.fParent = NULL;
  c11_j_emlrt_marshallIn(chartInstance, sf_mex_dup(c11_R), &c11_thisId, c11_y);
  sf_mex_destroy(&c11_R);
  c11_i73 = 0;
  for (c11_i74 = 0; c11_i74 < 3; c11_i74++) {
    for (c11_i75 = 0; c11_i75 < 3; c11_i75++) {
      (*(real_T (*)[9])c11_outData)[c11_i75 + c11_i73] = c11_y[c11_i75 + c11_i73];
    }

    c11_i73 += 3;
  }

  sf_mex_destroy(&c11_mxArrayInData);
}

static void c11_k_emlrt_marshallIn(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance, const mxArray *c11_u, const emlrtMsgIdentifier *c11_parentId,
  real_T c11_y[13])
{
  real_T c11_dv13[13];
  int32_T c11_i76;
  (void)chartInstance;
  sf_mex_import(c11_parentId, sf_mex_dup(c11_u), c11_dv13, 1, 0, 0U, 1, 0U, 1,
                13);
  for (c11_i76 = 0; c11_i76 < 13; c11_i76++) {
    c11_y[c11_i76] = c11_dv13[c11_i76];
  }

  sf_mex_destroy(&c11_u);
}

static void c11_g_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c11_mxArrayInData, const char_T *c11_varName, void *c11_outData)
{
  const mxArray *c11_SegmentLengths;
  const char_T *c11_identifier;
  emlrtMsgIdentifier c11_thisId;
  real_T c11_y[13];
  int32_T c11_i77;
  SFc11_FootPlacementLibraryInstanceStruct *chartInstance;
  chartInstance = (SFc11_FootPlacementLibraryInstanceStruct *)chartInstanceVoid;
  c11_SegmentLengths = sf_mex_dup(c11_mxArrayInData);
  c11_identifier = c11_varName;
  c11_thisId.fIdentifier = c11_identifier;
  c11_thisId.fParent = NULL;
  c11_k_emlrt_marshallIn(chartInstance, sf_mex_dup(c11_SegmentLengths),
    &c11_thisId, c11_y);
  sf_mex_destroy(&c11_SegmentLengths);
  for (c11_i77 = 0; c11_i77 < 13; c11_i77++) {
    (*(real_T (*)[13])c11_outData)[c11_i77] = c11_y[c11_i77];
  }

  sf_mex_destroy(&c11_mxArrayInData);
}

const mxArray *sf_c11_FootPlacementLibrary_get_eml_resolved_functions_info(void)
{
  const mxArray *c11_nameCaptureInfo = NULL;
  c11_nameCaptureInfo = NULL;
  sf_mex_assign(&c11_nameCaptureInfo, sf_mex_createstruct("structure", 2, 64, 1),
                false);
  c11_info_helper(&c11_nameCaptureInfo);
  sf_mex_emlrtNameCapturePostProcessR2012a(&c11_nameCaptureInfo);
  return c11_nameCaptureInfo;
}

static void c11_info_helper(const mxArray **c11_info)
{
  const mxArray *c11_rhs0 = NULL;
  const mxArray *c11_lhs0 = NULL;
  const mxArray *c11_rhs1 = NULL;
  const mxArray *c11_lhs1 = NULL;
  const mxArray *c11_rhs2 = NULL;
  const mxArray *c11_lhs2 = NULL;
  const mxArray *c11_rhs3 = NULL;
  const mxArray *c11_lhs3 = NULL;
  const mxArray *c11_rhs4 = NULL;
  const mxArray *c11_lhs4 = NULL;
  const mxArray *c11_rhs5 = NULL;
  const mxArray *c11_lhs5 = NULL;
  const mxArray *c11_rhs6 = NULL;
  const mxArray *c11_lhs6 = NULL;
  const mxArray *c11_rhs7 = NULL;
  const mxArray *c11_lhs7 = NULL;
  const mxArray *c11_rhs8 = NULL;
  const mxArray *c11_lhs8 = NULL;
  const mxArray *c11_rhs9 = NULL;
  const mxArray *c11_lhs9 = NULL;
  const mxArray *c11_rhs10 = NULL;
  const mxArray *c11_lhs10 = NULL;
  const mxArray *c11_rhs11 = NULL;
  const mxArray *c11_lhs11 = NULL;
  const mxArray *c11_rhs12 = NULL;
  const mxArray *c11_lhs12 = NULL;
  const mxArray *c11_rhs13 = NULL;
  const mxArray *c11_lhs13 = NULL;
  const mxArray *c11_rhs14 = NULL;
  const mxArray *c11_lhs14 = NULL;
  const mxArray *c11_rhs15 = NULL;
  const mxArray *c11_lhs15 = NULL;
  const mxArray *c11_rhs16 = NULL;
  const mxArray *c11_lhs16 = NULL;
  const mxArray *c11_rhs17 = NULL;
  const mxArray *c11_lhs17 = NULL;
  const mxArray *c11_rhs18 = NULL;
  const mxArray *c11_lhs18 = NULL;
  const mxArray *c11_rhs19 = NULL;
  const mxArray *c11_lhs19 = NULL;
  const mxArray *c11_rhs20 = NULL;
  const mxArray *c11_lhs20 = NULL;
  const mxArray *c11_rhs21 = NULL;
  const mxArray *c11_lhs21 = NULL;
  const mxArray *c11_rhs22 = NULL;
  const mxArray *c11_lhs22 = NULL;
  const mxArray *c11_rhs23 = NULL;
  const mxArray *c11_lhs23 = NULL;
  const mxArray *c11_rhs24 = NULL;
  const mxArray *c11_lhs24 = NULL;
  const mxArray *c11_rhs25 = NULL;
  const mxArray *c11_lhs25 = NULL;
  const mxArray *c11_rhs26 = NULL;
  const mxArray *c11_lhs26 = NULL;
  const mxArray *c11_rhs27 = NULL;
  const mxArray *c11_lhs27 = NULL;
  const mxArray *c11_rhs28 = NULL;
  const mxArray *c11_lhs28 = NULL;
  const mxArray *c11_rhs29 = NULL;
  const mxArray *c11_lhs29 = NULL;
  const mxArray *c11_rhs30 = NULL;
  const mxArray *c11_lhs30 = NULL;
  const mxArray *c11_rhs31 = NULL;
  const mxArray *c11_lhs31 = NULL;
  const mxArray *c11_rhs32 = NULL;
  const mxArray *c11_lhs32 = NULL;
  const mxArray *c11_rhs33 = NULL;
  const mxArray *c11_lhs33 = NULL;
  const mxArray *c11_rhs34 = NULL;
  const mxArray *c11_lhs34 = NULL;
  const mxArray *c11_rhs35 = NULL;
  const mxArray *c11_lhs35 = NULL;
  const mxArray *c11_rhs36 = NULL;
  const mxArray *c11_lhs36 = NULL;
  const mxArray *c11_rhs37 = NULL;
  const mxArray *c11_lhs37 = NULL;
  const mxArray *c11_rhs38 = NULL;
  const mxArray *c11_lhs38 = NULL;
  const mxArray *c11_rhs39 = NULL;
  const mxArray *c11_lhs39 = NULL;
  const mxArray *c11_rhs40 = NULL;
  const mxArray *c11_lhs40 = NULL;
  const mxArray *c11_rhs41 = NULL;
  const mxArray *c11_lhs41 = NULL;
  const mxArray *c11_rhs42 = NULL;
  const mxArray *c11_lhs42 = NULL;
  const mxArray *c11_rhs43 = NULL;
  const mxArray *c11_lhs43 = NULL;
  const mxArray *c11_rhs44 = NULL;
  const mxArray *c11_lhs44 = NULL;
  const mxArray *c11_rhs45 = NULL;
  const mxArray *c11_lhs45 = NULL;
  const mxArray *c11_rhs46 = NULL;
  const mxArray *c11_lhs46 = NULL;
  const mxArray *c11_rhs47 = NULL;
  const mxArray *c11_lhs47 = NULL;
  const mxArray *c11_rhs48 = NULL;
  const mxArray *c11_lhs48 = NULL;
  const mxArray *c11_rhs49 = NULL;
  const mxArray *c11_lhs49 = NULL;
  const mxArray *c11_rhs50 = NULL;
  const mxArray *c11_lhs50 = NULL;
  const mxArray *c11_rhs51 = NULL;
  const mxArray *c11_lhs51 = NULL;
  const mxArray *c11_rhs52 = NULL;
  const mxArray *c11_lhs52 = NULL;
  const mxArray *c11_rhs53 = NULL;
  const mxArray *c11_lhs53 = NULL;
  const mxArray *c11_rhs54 = NULL;
  const mxArray *c11_lhs54 = NULL;
  const mxArray *c11_rhs55 = NULL;
  const mxArray *c11_lhs55 = NULL;
  const mxArray *c11_rhs56 = NULL;
  const mxArray *c11_lhs56 = NULL;
  const mxArray *c11_rhs57 = NULL;
  const mxArray *c11_lhs57 = NULL;
  const mxArray *c11_rhs58 = NULL;
  const mxArray *c11_lhs58 = NULL;
  const mxArray *c11_rhs59 = NULL;
  const mxArray *c11_lhs59 = NULL;
  const mxArray *c11_rhs60 = NULL;
  const mxArray *c11_lhs60 = NULL;
  const mxArray *c11_rhs61 = NULL;
  const mxArray *c11_lhs61 = NULL;
  const mxArray *c11_rhs62 = NULL;
  const mxArray *c11_lhs62 = NULL;
  const mxArray *c11_rhs63 = NULL;
  const mxArray *c11_lhs63 = NULL;
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(""), "context", "context", 0);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("cos"), "name", "name", 0);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 0);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/cos.m"), "resolved",
                  "resolved", 0);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1343830372U), "fileTimeLo",
                  "fileTimeLo", 0);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 0);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 0);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 0);
  sf_mex_assign(&c11_rhs0, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs0, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs0), "rhs", "rhs",
                  0);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs0), "lhs", "lhs",
                  0);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/cos.m"), "context",
                  "context", 1);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("eml_scalar_cos"), "name",
                  "name", 1);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 1);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_cos.m"),
                  "resolved", "resolved", 1);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1286818722U), "fileTimeLo",
                  "fileTimeLo", 1);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 1);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 1);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 1);
  sf_mex_assign(&c11_rhs1, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs1, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs1), "rhs", "rhs",
                  1);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs1), "lhs", "lhs",
                  1);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(""), "context", "context", 2);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("sin"), "name", "name", 2);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 2);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sin.m"), "resolved",
                  "resolved", 2);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1343830386U), "fileTimeLo",
                  "fileTimeLo", 2);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 2);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 2);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 2);
  sf_mex_assign(&c11_rhs2, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs2, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs2), "rhs", "rhs",
                  2);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs2), "lhs", "lhs",
                  2);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sin.m"), "context",
                  "context", 3);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("eml_scalar_sin"), "name",
                  "name", 3);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 3);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_sin.m"),
                  "resolved", "resolved", 3);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1286818736U), "fileTimeLo",
                  "fileTimeLo", 3);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 3);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 3);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 3);
  sf_mex_assign(&c11_rhs3, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs3, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs3), "rhs", "rhs",
                  3);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs3), "lhs", "lhs",
                  3);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(""), "context", "context", 4);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("reshape"), "name", "name", 4);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 4);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/reshape.m"), "resolved",
                  "resolved", 4);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1378295982U), "fileTimeLo",
                  "fileTimeLo", 4);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 4);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 4);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 4);
  sf_mex_assign(&c11_rhs4, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs4, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs4), "rhs", "rhs",
                  4);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs4), "lhs", "lhs",
                  4);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/reshape.m"), "context",
                  "context", 5);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("eml_index_class"), "name",
                  "name", 5);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(""), "dominantType",
                  "dominantType", 5);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_class.m"),
                  "resolved", "resolved", 5);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1323170578U), "fileTimeLo",
                  "fileTimeLo", 5);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 5);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 5);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 5);
  sf_mex_assign(&c11_rhs5, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs5, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs5), "rhs", "rhs",
                  5);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs5), "lhs", "lhs",
                  5);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/reshape.m!reshape_varargin_to_size"),
                  "context", "context", 6);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("eml_index_class"), "name",
                  "name", 6);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(""), "dominantType",
                  "dominantType", 6);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_class.m"),
                  "resolved", "resolved", 6);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1323170578U), "fileTimeLo",
                  "fileTimeLo", 6);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 6);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 6);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 6);
  sf_mex_assign(&c11_rhs6, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs6, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs6), "rhs", "rhs",
                  6);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs6), "lhs", "lhs",
                  6);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/reshape.m!reshape_varargin_to_size"),
                  "context", "context", 7);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("eml_assert_valid_size_arg"),
                  "name", "name", 7);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 7);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_assert_valid_size_arg.m"),
                  "resolved", "resolved", 7);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1368183030U), "fileTimeLo",
                  "fileTimeLo", 7);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 7);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 7);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 7);
  sf_mex_assign(&c11_rhs7, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs7, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs7), "rhs", "rhs",
                  7);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs7), "lhs", "lhs",
                  7);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_assert_valid_size_arg.m"),
                  "context", "context", 8);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "coder.internal.isBuiltInNumeric"), "name", "name", 8);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 8);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[IXE]$matlabroot$/toolbox/shared/coder/coder/+coder/+internal/isBuiltInNumeric.m"),
                  "resolved", "resolved", 8);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1363714556U), "fileTimeLo",
                  "fileTimeLo", 8);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 8);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 8);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 8);
  sf_mex_assign(&c11_rhs8, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs8, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs8), "rhs", "rhs",
                  8);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs8), "lhs", "lhs",
                  8);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_assert_valid_size_arg.m!isintegral"),
                  "context", "context", 9);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("isinf"), "name", "name", 9);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 9);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/isinf.m"), "resolved",
                  "resolved", 9);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1363713856U), "fileTimeLo",
                  "fileTimeLo", 9);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 9);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 9);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 9);
  sf_mex_assign(&c11_rhs9, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs9, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs9), "rhs", "rhs",
                  9);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs9), "lhs", "lhs",
                  9);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/isinf.m"), "context",
                  "context", 10);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "coder.internal.isBuiltInNumeric"), "name", "name", 10);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 10);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[IXE]$matlabroot$/toolbox/shared/coder/coder/+coder/+internal/isBuiltInNumeric.m"),
                  "resolved", "resolved", 10);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1363714556U), "fileTimeLo",
                  "fileTimeLo", 10);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 10);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 10);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 10);
  sf_mex_assign(&c11_rhs10, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs10, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs10), "rhs", "rhs",
                  10);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs10), "lhs", "lhs",
                  10);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_assert_valid_size_arg.m!isinbounds"),
                  "context", "context", 11);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("eml_is_integer_class"),
                  "name", "name", 11);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("char"), "dominantType",
                  "dominantType", 11);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_is_integer_class.m"),
                  "resolved", "resolved", 11);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1286818782U), "fileTimeLo",
                  "fileTimeLo", 11);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 11);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 11);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 11);
  sf_mex_assign(&c11_rhs11, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs11, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs11), "rhs", "rhs",
                  11);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs11), "lhs", "lhs",
                  11);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_assert_valid_size_arg.m!isinbounds"),
                  "context", "context", 12);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("intmax"), "name", "name", 12);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("char"), "dominantType",
                  "dominantType", 12);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/intmax.m"), "resolved",
                  "resolved", 12);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1362261882U), "fileTimeLo",
                  "fileTimeLo", 12);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 12);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 12);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 12);
  sf_mex_assign(&c11_rhs12, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs12, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs12), "rhs", "rhs",
                  12);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs12), "lhs", "lhs",
                  12);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/intmax.m"), "context",
                  "context", 13);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("eml_switch_helper"), "name",
                  "name", 13);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(""), "dominantType",
                  "dominantType", 13);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_switch_helper.m"),
                  "resolved", "resolved", 13);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1381850300U), "fileTimeLo",
                  "fileTimeLo", 13);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 13);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 13);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 13);
  sf_mex_assign(&c11_rhs13, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs13, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs13), "rhs", "rhs",
                  13);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs13), "lhs", "lhs",
                  13);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_assert_valid_size_arg.m!isinbounds"),
                  "context", "context", 14);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("intmin"), "name", "name", 14);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("char"), "dominantType",
                  "dominantType", 14);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/intmin.m"), "resolved",
                  "resolved", 14);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1362261882U), "fileTimeLo",
                  "fileTimeLo", 14);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 14);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 14);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 14);
  sf_mex_assign(&c11_rhs14, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs14, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs14), "rhs", "rhs",
                  14);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs14), "lhs", "lhs",
                  14);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/intmin.m"), "context",
                  "context", 15);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("eml_switch_helper"), "name",
                  "name", 15);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(""), "dominantType",
                  "dominantType", 15);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_switch_helper.m"),
                  "resolved", "resolved", 15);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1381850300U), "fileTimeLo",
                  "fileTimeLo", 15);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 15);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 15);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 15);
  sf_mex_assign(&c11_rhs15, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs15, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs15), "rhs", "rhs",
                  15);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs15), "lhs", "lhs",
                  15);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_assert_valid_size_arg.m!isinbounds"),
                  "context", "context", 16);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "coder.internal.indexIntRelop"), "name", "name", 16);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(""), "dominantType",
                  "dominantType", 16);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[IXE]$matlabroot$/toolbox/shared/coder/coder/+coder/+internal/indexIntRelop.m"),
                  "resolved", "resolved", 16);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1326728322U), "fileTimeLo",
                  "fileTimeLo", 16);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 16);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 16);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 16);
  sf_mex_assign(&c11_rhs16, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs16, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs16), "rhs", "rhs",
                  16);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs16), "lhs", "lhs",
                  16);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[IXE]$matlabroot$/toolbox/shared/coder/coder/+coder/+internal/indexIntRelop.m!apply_float_relop"),
                  "context", "context", 17);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("eml_switch_helper"), "name",
                  "name", 17);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(""), "dominantType",
                  "dominantType", 17);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_switch_helper.m"),
                  "resolved", "resolved", 17);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1381850300U), "fileTimeLo",
                  "fileTimeLo", 17);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 17);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 17);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 17);
  sf_mex_assign(&c11_rhs17, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs17, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs17), "rhs", "rhs",
                  17);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs17), "lhs", "lhs",
                  17);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[IXE]$matlabroot$/toolbox/shared/coder/coder/+coder/+internal/indexIntRelop.m!float_class_contains_indexIntClass"),
                  "context", "context", 18);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("eml_float_model"), "name",
                  "name", 18);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("char"), "dominantType",
                  "dominantType", 18);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_float_model.m"),
                  "resolved", "resolved", 18);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1326727996U), "fileTimeLo",
                  "fileTimeLo", 18);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 18);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 18);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 18);
  sf_mex_assign(&c11_rhs18, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs18, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs18), "rhs", "rhs",
                  18);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs18), "lhs", "lhs",
                  18);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[IXE]$matlabroot$/toolbox/shared/coder/coder/+coder/+internal/indexIntRelop.m!is_signed_indexIntClass"),
                  "context", "context", 19);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("intmin"), "name", "name", 19);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("char"), "dominantType",
                  "dominantType", 19);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/intmin.m"), "resolved",
                  "resolved", 19);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1362261882U), "fileTimeLo",
                  "fileTimeLo", 19);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 19);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 19);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 19);
  sf_mex_assign(&c11_rhs19, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs19, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs19), "rhs", "rhs",
                  19);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs19), "lhs", "lhs",
                  19);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_assert_valid_size_arg.m"),
                  "context", "context", 20);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("eml_index_class"), "name",
                  "name", 20);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(""), "dominantType",
                  "dominantType", 20);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_class.m"),
                  "resolved", "resolved", 20);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1323170578U), "fileTimeLo",
                  "fileTimeLo", 20);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 20);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 20);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 20);
  sf_mex_assign(&c11_rhs20, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs20, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs20), "rhs", "rhs",
                  20);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs20), "lhs", "lhs",
                  20);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_assert_valid_size_arg.m"),
                  "context", "context", 21);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("intmax"), "name", "name", 21);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("char"), "dominantType",
                  "dominantType", 21);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/intmax.m"), "resolved",
                  "resolved", 21);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1362261882U), "fileTimeLo",
                  "fileTimeLo", 21);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 21);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 21);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 21);
  sf_mex_assign(&c11_rhs21, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs21, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs21), "rhs", "rhs",
                  21);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs21), "lhs", "lhs",
                  21);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/reshape.m"), "context",
                  "context", 22);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("eml_scalar_eg"), "name",
                  "name", 22);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 22);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalar_eg.m"), "resolved",
                  "resolved", 22);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1375980688U), "fileTimeLo",
                  "fileTimeLo", 22);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 22);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 22);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 22);
  sf_mex_assign(&c11_rhs22, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs22, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs22), "rhs", "rhs",
                  22);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs22), "lhs", "lhs",
                  22);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalar_eg.m"), "context",
                  "context", 23);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("coder.internal.scalarEg"),
                  "name", "name", 23);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 23);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[IXE]$matlabroot$/toolbox/coder/coder/+coder/+internal/scalarEg.p"),
                  "resolved", "resolved", 23);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1389307920U), "fileTimeLo",
                  "fileTimeLo", 23);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 23);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 23);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 23);
  sf_mex_assign(&c11_rhs23, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs23, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs23), "rhs", "rhs",
                  23);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs23), "lhs", "lhs",
                  23);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/reshape.m"), "context",
                  "context", 24);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "eml_int_forloop_overflow_check"), "name", "name", 24);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(""), "dominantType",
                  "dominantType", 24);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_int_forloop_overflow_check.m"),
                  "resolved", "resolved", 24);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1375980688U), "fileTimeLo",
                  "fileTimeLo", 24);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 24);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 24);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 24);
  sf_mex_assign(&c11_rhs24, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs24, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs24), "rhs", "rhs",
                  24);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs24), "lhs", "lhs",
                  24);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_int_forloop_overflow_check.m!eml_int_forloop_overflow_check_helper"),
                  "context", "context", 25);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("intmax"), "name", "name", 25);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("char"), "dominantType",
                  "dominantType", 25);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/intmax.m"), "resolved",
                  "resolved", 25);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1362261882U), "fileTimeLo",
                  "fileTimeLo", 25);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 25);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 25);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 25);
  sf_mex_assign(&c11_rhs25, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs25, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs25), "rhs", "rhs",
                  25);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs25), "lhs", "lhs",
                  25);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(""), "context", "context", 26);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("mrdivide"), "name", "name",
                  26);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 26);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.p"), "resolved",
                  "resolved", 26);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1388460096U), "fileTimeLo",
                  "fileTimeLo", 26);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 26);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1370009886U), "mFileTimeLo",
                  "mFileTimeLo", 26);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 26);
  sf_mex_assign(&c11_rhs26, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs26, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs26), "rhs", "rhs",
                  26);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs26), "lhs", "lhs",
                  26);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.p"), "context",
                  "context", 27);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("coder.internal.assert"),
                  "name", "name", 27);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("char"), "dominantType",
                  "dominantType", 27);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[IXE]$matlabroot$/toolbox/shared/coder/coder/+coder/+internal/assert.m"),
                  "resolved", "resolved", 27);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1363714556U), "fileTimeLo",
                  "fileTimeLo", 27);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 27);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 27);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 27);
  sf_mex_assign(&c11_rhs27, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs27, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs27), "rhs", "rhs",
                  27);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs27), "lhs", "lhs",
                  27);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.p"), "context",
                  "context", 28);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("rdivide"), "name", "name",
                  28);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 28);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m"), "resolved",
                  "resolved", 28);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1363713880U), "fileTimeLo",
                  "fileTimeLo", 28);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 28);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 28);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 28);
  sf_mex_assign(&c11_rhs28, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs28, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs28), "rhs", "rhs",
                  28);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs28), "lhs", "lhs",
                  28);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m"), "context",
                  "context", 29);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "coder.internal.isBuiltInNumeric"), "name", "name", 29);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 29);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[IXE]$matlabroot$/toolbox/shared/coder/coder/+coder/+internal/isBuiltInNumeric.m"),
                  "resolved", "resolved", 29);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1363714556U), "fileTimeLo",
                  "fileTimeLo", 29);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 29);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 29);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 29);
  sf_mex_assign(&c11_rhs29, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs29, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs29), "rhs", "rhs",
                  29);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs29), "lhs", "lhs",
                  29);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m"), "context",
                  "context", 30);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("eml_scalexp_compatible"),
                  "name", "name", 30);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 30);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalexp_compatible.m"),
                  "resolved", "resolved", 30);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1286818796U), "fileTimeLo",
                  "fileTimeLo", 30);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 30);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 30);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 30);
  sf_mex_assign(&c11_rhs30, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs30, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs30), "rhs", "rhs",
                  30);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs30), "lhs", "lhs",
                  30);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m"), "context",
                  "context", 31);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("eml_div"), "name", "name",
                  31);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 31);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_div.m"), "resolved",
                  "resolved", 31);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1375980688U), "fileTimeLo",
                  "fileTimeLo", 31);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 31);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 31);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 31);
  sf_mex_assign(&c11_rhs31, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs31, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs31), "rhs", "rhs",
                  31);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs31), "lhs", "lhs",
                  31);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_div.m"), "context",
                  "context", 32);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("coder.internal.div"), "name",
                  "name", 32);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 32);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[IXE]$matlabroot$/toolbox/coder/coder/+coder/+internal/div.p"), "resolved",
                  "resolved", 32);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1389307920U), "fileTimeLo",
                  "fileTimeLo", 32);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 32);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 32);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 32);
  sf_mex_assign(&c11_rhs32, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs32, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs32), "rhs", "rhs",
                  32);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs32), "lhs", "lhs",
                  32);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(""), "context", "context", 33);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("Rz"), "name", "name", 33);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 33);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[E]/Users/martijndekker/Dropbox/Mechanical Engineering/Mindwalker Controllers/Mindwalker Matlab/FootPlacementLibrary/Rz.m"),
                  "resolved", "resolved", 33);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1401713323U), "fileTimeLo",
                  "fileTimeLo", 33);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 33);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 33);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 33);
  sf_mex_assign(&c11_rhs33, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs33, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs33), "rhs", "rhs",
                  33);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs33), "lhs", "lhs",
                  33);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[E]/Users/martijndekker/Dropbox/Mechanical Engineering/Mindwalker Controllers/Mindwalker Matlab/FootPlacementLibrary/Rz.m"),
                  "context", "context", 34);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("sin"), "name", "name", 34);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 34);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sin.m"), "resolved",
                  "resolved", 34);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1343830386U), "fileTimeLo",
                  "fileTimeLo", 34);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 34);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 34);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 34);
  sf_mex_assign(&c11_rhs34, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs34, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs34), "rhs", "rhs",
                  34);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs34), "lhs", "lhs",
                  34);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[E]/Users/martijndekker/Dropbox/Mechanical Engineering/Mindwalker Controllers/Mindwalker Matlab/FootPlacementLibrary/Rz.m"),
                  "context", "context", 35);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("cos"), "name", "name", 35);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 35);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/cos.m"), "resolved",
                  "resolved", 35);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1343830372U), "fileTimeLo",
                  "fileTimeLo", 35);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 35);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 35);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 35);
  sf_mex_assign(&c11_rhs35, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs35, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs35), "rhs", "rhs",
                  35);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs35), "lhs", "lhs",
                  35);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(""), "context", "context", 36);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("Ry"), "name", "name", 36);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 36);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[E]/Users/martijndekker/Dropbox/Mechanical Engineering/Mindwalker Controllers/Mindwalker Matlab/FootPlacementLibrary/Ry.m"),
                  "resolved", "resolved", 36);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1401713324U), "fileTimeLo",
                  "fileTimeLo", 36);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 36);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 36);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 36);
  sf_mex_assign(&c11_rhs36, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs36, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs36), "rhs", "rhs",
                  36);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs36), "lhs", "lhs",
                  36);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[E]/Users/martijndekker/Dropbox/Mechanical Engineering/Mindwalker Controllers/Mindwalker Matlab/FootPlacementLibrary/Ry.m"),
                  "context", "context", 37);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("sin"), "name", "name", 37);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 37);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sin.m"), "resolved",
                  "resolved", 37);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1343830386U), "fileTimeLo",
                  "fileTimeLo", 37);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 37);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 37);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 37);
  sf_mex_assign(&c11_rhs37, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs37, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs37), "rhs", "rhs",
                  37);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs37), "lhs", "lhs",
                  37);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[E]/Users/martijndekker/Dropbox/Mechanical Engineering/Mindwalker Controllers/Mindwalker Matlab/FootPlacementLibrary/Ry.m"),
                  "context", "context", 38);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("cos"), "name", "name", 38);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 38);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/cos.m"), "resolved",
                  "resolved", 38);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1343830372U), "fileTimeLo",
                  "fileTimeLo", 38);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 38);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 38);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 38);
  sf_mex_assign(&c11_rhs38, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs38, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs38), "rhs", "rhs",
                  38);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs38), "lhs", "lhs",
                  38);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(""), "context", "context", 39);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("Rx"), "name", "name", 39);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 39);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[E]/Users/martijndekker/Dropbox/Mechanical Engineering/Mindwalker Controllers/Mindwalker Matlab/FootPlacementLibrary/Rx.m"),
                  "resolved", "resolved", 39);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1401713325U), "fileTimeLo",
                  "fileTimeLo", 39);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 39);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 39);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 39);
  sf_mex_assign(&c11_rhs39, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs39, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs39), "rhs", "rhs",
                  39);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs39), "lhs", "lhs",
                  39);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[E]/Users/martijndekker/Dropbox/Mechanical Engineering/Mindwalker Controllers/Mindwalker Matlab/FootPlacementLibrary/Rx.m"),
                  "context", "context", 40);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("sin"), "name", "name", 40);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 40);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sin.m"), "resolved",
                  "resolved", 40);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1343830386U), "fileTimeLo",
                  "fileTimeLo", 40);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 40);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 40);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 40);
  sf_mex_assign(&c11_rhs40, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs40, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs40), "rhs", "rhs",
                  40);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs40), "lhs", "lhs",
                  40);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[E]/Users/martijndekker/Dropbox/Mechanical Engineering/Mindwalker Controllers/Mindwalker Matlab/FootPlacementLibrary/Rx.m"),
                  "context", "context", 41);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("cos"), "name", "name", 41);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 41);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/cos.m"), "resolved",
                  "resolved", 41);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1343830372U), "fileTimeLo",
                  "fileTimeLo", 41);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 41);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 41);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 41);
  sf_mex_assign(&c11_rhs41, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs41, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs41), "rhs", "rhs",
                  41);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs41), "lhs", "lhs",
                  41);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(""), "context", "context", 42);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("eml_mtimes_helper"), "name",
                  "name", 42);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(""), "dominantType",
                  "dominantType", 42);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/eml_mtimes_helper.m"),
                  "resolved", "resolved", 42);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1383877294U), "fileTimeLo",
                  "fileTimeLo", 42);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 42);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 42);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 42);
  sf_mex_assign(&c11_rhs42, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs42, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs42), "rhs", "rhs",
                  42);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs42), "lhs", "lhs",
                  42);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/eml_mtimes_helper.m!common_checks"),
                  "context", "context", 43);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "coder.internal.isBuiltInNumeric"), "name", "name", 43);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 43);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[IXE]$matlabroot$/toolbox/shared/coder/coder/+coder/+internal/isBuiltInNumeric.m"),
                  "resolved", "resolved", 43);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1363714556U), "fileTimeLo",
                  "fileTimeLo", 43);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 43);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 43);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 43);
  sf_mex_assign(&c11_rhs43, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs43, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs43), "rhs", "rhs",
                  43);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs43), "lhs", "lhs",
                  43);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/eml_mtimes_helper.m"),
                  "context", "context", 44);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("eml_index_class"), "name",
                  "name", 44);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(""), "dominantType",
                  "dominantType", 44);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_index_class.m"),
                  "resolved", "resolved", 44);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1323170578U), "fileTimeLo",
                  "fileTimeLo", 44);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 44);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 44);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 44);
  sf_mex_assign(&c11_rhs44, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs44, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs44), "rhs", "rhs",
                  44);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs44), "lhs", "lhs",
                  44);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/eml_mtimes_helper.m"),
                  "context", "context", 45);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("eml_scalar_eg"), "name",
                  "name", 45);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 45);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalar_eg.m"), "resolved",
                  "resolved", 45);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1375980688U), "fileTimeLo",
                  "fileTimeLo", 45);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 45);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 45);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 45);
  sf_mex_assign(&c11_rhs45, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs45, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs45), "rhs", "rhs",
                  45);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs45), "lhs", "lhs",
                  45);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/eml_mtimes_helper.m"),
                  "context", "context", 46);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("eml_xgemm"), "name", "name",
                  46);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("char"), "dominantType",
                  "dominantType", 46);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/eml_xgemm.m"),
                  "resolved", "resolved", 46);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1375980690U), "fileTimeLo",
                  "fileTimeLo", 46);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 46);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 46);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 46);
  sf_mex_assign(&c11_rhs46, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs46, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs46), "rhs", "rhs",
                  46);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs46), "lhs", "lhs",
                  46);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/eml_xgemm.m"), "context",
                  "context", 47);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("coder.internal.blas.inline"),
                  "name", "name", 47);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(""), "dominantType",
                  "dominantType", 47);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[IXE]$matlabroot$/toolbox/coder/coder/+coder/+internal/+blas/inline.p"),
                  "resolved", "resolved", 47);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1389307922U), "fileTimeLo",
                  "fileTimeLo", 47);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 47);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 47);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 47);
  sf_mex_assign(&c11_rhs47, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs47, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs47), "rhs", "rhs",
                  47);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs47), "lhs", "lhs",
                  47);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/eml_xgemm.m"), "context",
                  "context", 48);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("coder.internal.blas.xgemm"),
                  "name", "name", 48);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("char"), "dominantType",
                  "dominantType", 48);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[IXE]$matlabroot$/toolbox/coder/coder/+coder/+internal/+blas/xgemm.p"),
                  "resolved", "resolved", 48);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1389307922U), "fileTimeLo",
                  "fileTimeLo", 48);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 48);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 48);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 48);
  sf_mex_assign(&c11_rhs48, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs48, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs48), "rhs", "rhs",
                  48);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs48), "lhs", "lhs",
                  48);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[IXE]$matlabroot$/toolbox/coder/coder/+coder/+internal/+blas/xgemm.p"),
                  "context", "context", 49);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "coder.internal.blas.use_refblas"), "name", "name", 49);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(""), "dominantType",
                  "dominantType", 49);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[IXE]$matlabroot$/toolbox/coder/coder/+coder/+internal/+blas/use_refblas.p"),
                  "resolved", "resolved", 49);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1389307922U), "fileTimeLo",
                  "fileTimeLo", 49);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 49);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 49);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 49);
  sf_mex_assign(&c11_rhs49, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs49, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs49), "rhs", "rhs",
                  49);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs49), "lhs", "lhs",
                  49);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[IXE]$matlabroot$/toolbox/coder/coder/+coder/+internal/+blas/xgemm.p!below_threshold"),
                  "context", "context", 50);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "coder.internal.blas.threshold"), "name", "name", 50);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("char"), "dominantType",
                  "dominantType", 50);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[IXE]$matlabroot$/toolbox/coder/coder/+coder/+internal/+blas/threshold.p"),
                  "resolved", "resolved", 50);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1389307922U), "fileTimeLo",
                  "fileTimeLo", 50);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 50);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 50);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 50);
  sf_mex_assign(&c11_rhs50, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs50, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs50), "rhs", "rhs",
                  50);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs50), "lhs", "lhs",
                  50);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[IXE]$matlabroot$/toolbox/coder/coder/+coder/+internal/+blas/threshold.p"),
                  "context", "context", 51);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("eml_switch_helper"), "name",
                  "name", 51);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(""), "dominantType",
                  "dominantType", 51);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_switch_helper.m"),
                  "resolved", "resolved", 51);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1381850300U), "fileTimeLo",
                  "fileTimeLo", 51);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 51);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 51);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 51);
  sf_mex_assign(&c11_rhs51, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs51, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs51), "rhs", "rhs",
                  51);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs51), "lhs", "lhs",
                  51);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[IXE]$matlabroot$/toolbox/coder/coder/+coder/+internal/+blas/xgemm.p"),
                  "context", "context", 52);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("coder.internal.scalarEg"),
                  "name", "name", 52);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 52);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[IXE]$matlabroot$/toolbox/coder/coder/+coder/+internal/scalarEg.p"),
                  "resolved", "resolved", 52);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1389307920U), "fileTimeLo",
                  "fileTimeLo", 52);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 52);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 52);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 52);
  sf_mex_assign(&c11_rhs52, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs52, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs52), "rhs", "rhs",
                  52);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs52), "lhs", "lhs",
                  52);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[IXE]$matlabroot$/toolbox/coder/coder/+coder/+internal/+blas/xgemm.p"),
                  "context", "context", 53);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "coder.internal.refblas.xgemm"), "name", "name", 53);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("char"), "dominantType",
                  "dominantType", 53);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[IXE]$matlabroot$/toolbox/coder/coder/+coder/+internal/+refblas/xgemm.p"),
                  "resolved", "resolved", 53);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1389307922U), "fileTimeLo",
                  "fileTimeLo", 53);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 53);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 53);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 53);
  sf_mex_assign(&c11_rhs53, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs53, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs53), "rhs", "rhs",
                  53);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs53), "lhs", "lhs",
                  53);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(""), "context", "context", 54);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("mldivide"), "name", "name",
                  54);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 54);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mldivide.p"), "resolved",
                  "resolved", 54);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1388460096U), "fileTimeLo",
                  "fileTimeLo", 54);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 54);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1319729966U), "mFileTimeLo",
                  "mFileTimeLo", 54);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 54);
  sf_mex_assign(&c11_rhs54, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs54, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs54), "rhs", "rhs",
                  54);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs54), "lhs", "lhs",
                  54);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mldivide.p"), "context",
                  "context", 55);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("eml_lusolve"), "name",
                  "name", 55);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 55);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_lusolve.m"), "resolved",
                  "resolved", 55);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1370009886U), "fileTimeLo",
                  "fileTimeLo", 55);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 55);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 55);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 55);
  sf_mex_assign(&c11_rhs55, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs55, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs55), "rhs", "rhs",
                  55);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs55), "lhs", "lhs",
                  55);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_lusolve.m!lusolve2x2"),
                  "context", "context", 56);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("eml_xcabs1"), "name", "name",
                  56);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 56);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/eml_xcabs1.m"),
                  "resolved", "resolved", 56);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1375980688U), "fileTimeLo",
                  "fileTimeLo", 56);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 56);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 56);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 56);
  sf_mex_assign(&c11_rhs56, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs56, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs56), "rhs", "rhs",
                  56);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs56), "lhs", "lhs",
                  56);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/blas/eml_xcabs1.m"),
                  "context", "context", 57);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "coder.internal.refblas.xcabs1"), "name", "name", 57);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 57);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[IXE]$matlabroot$/toolbox/coder/coder/+coder/+internal/+refblas/xcabs1.p"),
                  "resolved", "resolved", 57);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1389307922U), "fileTimeLo",
                  "fileTimeLo", 57);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 57);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 57);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 57);
  sf_mex_assign(&c11_rhs57, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs57, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs57), "rhs", "rhs",
                  57);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs57), "lhs", "lhs",
                  57);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[IXE]$matlabroot$/toolbox/coder/coder/+coder/+internal/+refblas/xcabs1.p"),
                  "context", "context", 58);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("abs"), "name", "name", 58);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 58);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/abs.m"), "resolved",
                  "resolved", 58);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1363713852U), "fileTimeLo",
                  "fileTimeLo", 58);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 58);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 58);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 58);
  sf_mex_assign(&c11_rhs58, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs58, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs58), "rhs", "rhs",
                  58);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs58), "lhs", "lhs",
                  58);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/abs.m"), "context",
                  "context", 59);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "coder.internal.isBuiltInNumeric"), "name", "name", 59);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 59);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[IXE]$matlabroot$/toolbox/shared/coder/coder/+coder/+internal/isBuiltInNumeric.m"),
                  "resolved", "resolved", 59);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1363714556U), "fileTimeLo",
                  "fileTimeLo", 59);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 59);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 59);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 59);
  sf_mex_assign(&c11_rhs59, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs59, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs59), "rhs", "rhs",
                  59);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs59), "lhs", "lhs",
                  59);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/abs.m"), "context",
                  "context", 60);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("eml_scalar_abs"), "name",
                  "name", 60);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 60);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_abs.m"),
                  "resolved", "resolved", 60);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1286818712U), "fileTimeLo",
                  "fileTimeLo", 60);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 60);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 60);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 60);
  sf_mex_assign(&c11_rhs60, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs60, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs60), "rhs", "rhs",
                  60);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs60), "lhs", "lhs",
                  60);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_lusolve.m!lusolve2x2"),
                  "context", "context", 61);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("rdivide"), "name", "name",
                  61);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 61);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m"), "resolved",
                  "resolved", 61);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1363713880U), "fileTimeLo",
                  "fileTimeLo", 61);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 61);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 61);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 61);
  sf_mex_assign(&c11_rhs61, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs61, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs61), "rhs", "rhs",
                  61);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs61), "lhs", "lhs",
                  61);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_lusolve.m!warn_singular"),
                  "context", "context", 62);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("eml_warning"), "name",
                  "name", 62);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("char"), "dominantType",
                  "dominantType", 62);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_warning.m"), "resolved",
                  "resolved", 62);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1286818802U), "fileTimeLo",
                  "fileTimeLo", 62);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 62);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 62);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 62);
  sf_mex_assign(&c11_rhs62, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs62, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs62), "rhs", "rhs",
                  62);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs62), "lhs", "lhs",
                  62);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_lusolve.m!lusolve2x2"),
                  "context", "context", 63);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("eml_scalar_eg"), "name",
                  "name", 63);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 63);
  sf_mex_addfield(*c11_info, c11_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalar_eg.m"), "resolved",
                  "resolved", 63);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(1375980688U), "fileTimeLo",
                  "fileTimeLo", 63);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 63);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 63);
  sf_mex_addfield(*c11_info, c11_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 63);
  sf_mex_assign(&c11_rhs63, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c11_lhs63, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_rhs63), "rhs", "rhs",
                  63);
  sf_mex_addfield(*c11_info, sf_mex_duplicatearraysafe(&c11_lhs63), "lhs", "lhs",
                  63);
  sf_mex_destroy(&c11_rhs0);
  sf_mex_destroy(&c11_lhs0);
  sf_mex_destroy(&c11_rhs1);
  sf_mex_destroy(&c11_lhs1);
  sf_mex_destroy(&c11_rhs2);
  sf_mex_destroy(&c11_lhs2);
  sf_mex_destroy(&c11_rhs3);
  sf_mex_destroy(&c11_lhs3);
  sf_mex_destroy(&c11_rhs4);
  sf_mex_destroy(&c11_lhs4);
  sf_mex_destroy(&c11_rhs5);
  sf_mex_destroy(&c11_lhs5);
  sf_mex_destroy(&c11_rhs6);
  sf_mex_destroy(&c11_lhs6);
  sf_mex_destroy(&c11_rhs7);
  sf_mex_destroy(&c11_lhs7);
  sf_mex_destroy(&c11_rhs8);
  sf_mex_destroy(&c11_lhs8);
  sf_mex_destroy(&c11_rhs9);
  sf_mex_destroy(&c11_lhs9);
  sf_mex_destroy(&c11_rhs10);
  sf_mex_destroy(&c11_lhs10);
  sf_mex_destroy(&c11_rhs11);
  sf_mex_destroy(&c11_lhs11);
  sf_mex_destroy(&c11_rhs12);
  sf_mex_destroy(&c11_lhs12);
  sf_mex_destroy(&c11_rhs13);
  sf_mex_destroy(&c11_lhs13);
  sf_mex_destroy(&c11_rhs14);
  sf_mex_destroy(&c11_lhs14);
  sf_mex_destroy(&c11_rhs15);
  sf_mex_destroy(&c11_lhs15);
  sf_mex_destroy(&c11_rhs16);
  sf_mex_destroy(&c11_lhs16);
  sf_mex_destroy(&c11_rhs17);
  sf_mex_destroy(&c11_lhs17);
  sf_mex_destroy(&c11_rhs18);
  sf_mex_destroy(&c11_lhs18);
  sf_mex_destroy(&c11_rhs19);
  sf_mex_destroy(&c11_lhs19);
  sf_mex_destroy(&c11_rhs20);
  sf_mex_destroy(&c11_lhs20);
  sf_mex_destroy(&c11_rhs21);
  sf_mex_destroy(&c11_lhs21);
  sf_mex_destroy(&c11_rhs22);
  sf_mex_destroy(&c11_lhs22);
  sf_mex_destroy(&c11_rhs23);
  sf_mex_destroy(&c11_lhs23);
  sf_mex_destroy(&c11_rhs24);
  sf_mex_destroy(&c11_lhs24);
  sf_mex_destroy(&c11_rhs25);
  sf_mex_destroy(&c11_lhs25);
  sf_mex_destroy(&c11_rhs26);
  sf_mex_destroy(&c11_lhs26);
  sf_mex_destroy(&c11_rhs27);
  sf_mex_destroy(&c11_lhs27);
  sf_mex_destroy(&c11_rhs28);
  sf_mex_destroy(&c11_lhs28);
  sf_mex_destroy(&c11_rhs29);
  sf_mex_destroy(&c11_lhs29);
  sf_mex_destroy(&c11_rhs30);
  sf_mex_destroy(&c11_lhs30);
  sf_mex_destroy(&c11_rhs31);
  sf_mex_destroy(&c11_lhs31);
  sf_mex_destroy(&c11_rhs32);
  sf_mex_destroy(&c11_lhs32);
  sf_mex_destroy(&c11_rhs33);
  sf_mex_destroy(&c11_lhs33);
  sf_mex_destroy(&c11_rhs34);
  sf_mex_destroy(&c11_lhs34);
  sf_mex_destroy(&c11_rhs35);
  sf_mex_destroy(&c11_lhs35);
  sf_mex_destroy(&c11_rhs36);
  sf_mex_destroy(&c11_lhs36);
  sf_mex_destroy(&c11_rhs37);
  sf_mex_destroy(&c11_lhs37);
  sf_mex_destroy(&c11_rhs38);
  sf_mex_destroy(&c11_lhs38);
  sf_mex_destroy(&c11_rhs39);
  sf_mex_destroy(&c11_lhs39);
  sf_mex_destroy(&c11_rhs40);
  sf_mex_destroy(&c11_lhs40);
  sf_mex_destroy(&c11_rhs41);
  sf_mex_destroy(&c11_lhs41);
  sf_mex_destroy(&c11_rhs42);
  sf_mex_destroy(&c11_lhs42);
  sf_mex_destroy(&c11_rhs43);
  sf_mex_destroy(&c11_lhs43);
  sf_mex_destroy(&c11_rhs44);
  sf_mex_destroy(&c11_lhs44);
  sf_mex_destroy(&c11_rhs45);
  sf_mex_destroy(&c11_lhs45);
  sf_mex_destroy(&c11_rhs46);
  sf_mex_destroy(&c11_lhs46);
  sf_mex_destroy(&c11_rhs47);
  sf_mex_destroy(&c11_lhs47);
  sf_mex_destroy(&c11_rhs48);
  sf_mex_destroy(&c11_lhs48);
  sf_mex_destroy(&c11_rhs49);
  sf_mex_destroy(&c11_lhs49);
  sf_mex_destroy(&c11_rhs50);
  sf_mex_destroy(&c11_lhs50);
  sf_mex_destroy(&c11_rhs51);
  sf_mex_destroy(&c11_lhs51);
  sf_mex_destroy(&c11_rhs52);
  sf_mex_destroy(&c11_lhs52);
  sf_mex_destroy(&c11_rhs53);
  sf_mex_destroy(&c11_lhs53);
  sf_mex_destroy(&c11_rhs54);
  sf_mex_destroy(&c11_lhs54);
  sf_mex_destroy(&c11_rhs55);
  sf_mex_destroy(&c11_lhs55);
  sf_mex_destroy(&c11_rhs56);
  sf_mex_destroy(&c11_lhs56);
  sf_mex_destroy(&c11_rhs57);
  sf_mex_destroy(&c11_lhs57);
  sf_mex_destroy(&c11_rhs58);
  sf_mex_destroy(&c11_lhs58);
  sf_mex_destroy(&c11_rhs59);
  sf_mex_destroy(&c11_lhs59);
  sf_mex_destroy(&c11_rhs60);
  sf_mex_destroy(&c11_lhs60);
  sf_mex_destroy(&c11_rhs61);
  sf_mex_destroy(&c11_lhs61);
  sf_mex_destroy(&c11_rhs62);
  sf_mex_destroy(&c11_lhs62);
  sf_mex_destroy(&c11_rhs63);
  sf_mex_destroy(&c11_lhs63);
}

static const mxArray *c11_emlrt_marshallOut(const char * c11_u)
{
  const mxArray *c11_y = NULL;
  c11_y = NULL;
  sf_mex_assign(&c11_y, sf_mex_create("y", c11_u, 15, 0U, 0U, 0U, 2, 1, strlen
    (c11_u)), false);
  return c11_y;
}

static const mxArray *c11_b_emlrt_marshallOut(const uint32_T c11_u)
{
  const mxArray *c11_y = NULL;
  c11_y = NULL;
  sf_mex_assign(&c11_y, sf_mex_create("y", &c11_u, 7, 0U, 0U, 0U, 0), false);
  return c11_y;
}

static void c11_fk_KFE_jacobian(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance, real_T c11_swjointangles[3], real_T c11_Rtrunk[9], real_T
  c11_SegmentLengths[13], real_T c11_xz[2])
{
  uint32_T c11_debug_family_var_map[103];
  real_T c11_RHAA;
  real_T c11_RHFE;
  real_T c11_RKFE;
  real_T c11_R_trunk_0_1_1;
  real_T c11_R_trunk_0_1_2;
  real_T c11_R_trunk_0_1_3;
  real_T c11_R_trunk_0_2_1;
  real_T c11_R_trunk_0_2_2;
  real_T c11_R_trunk_0_2_3;
  real_T c11_R_trunk_0_3_1;
  real_T c11_R_trunk_0_3_2;
  real_T c11_R_trunk_0_3_3;
  real_T c11_wPelvis;
  real_T c11_dxHAA2HEE;
  real_T c11_dyHAA2HEE;
  real_T c11_dzHAA2HEE;
  real_T c11_dxHEE2HFE;
  real_T c11_dyHEE2HFE;
  real_T c11_dzHEE2HFE;
  real_T c11_lThigh;
  real_T c11_lShank;
  real_T c11_dxFoot;
  real_T c11_hFoot;
  real_T c11_lFoot;
  real_T c11_t2;
  real_T c11_t3;
  real_T c11_t4;
  real_T c11_t9;
  real_T c11_t5;
  real_T c11_t6;
  real_T c11_t7;
  real_T c11_t8;
  real_T c11_t10;
  real_T c11_t11;
  real_T c11_t12;
  real_T c11_t13;
  real_T c11_t14;
  real_T c11_t15;
  real_T c11_t16;
  real_T c11_t17;
  real_T c11_t18;
  real_T c11_t19;
  real_T c11_t20;
  real_T c11_t21;
  real_T c11_t22;
  real_T c11_t24;
  real_T c11_t23;
  real_T c11_t25;
  real_T c11_t26;
  real_T c11_t27;
  real_T c11_t28;
  real_T c11_t29;
  real_T c11_t34;
  real_T c11_t30;
  real_T c11_t31;
  real_T c11_t32;
  real_T c11_t33;
  real_T c11_t35;
  real_T c11_t36;
  real_T c11_t37;
  real_T c11_t38;
  real_T c11_t39;
  real_T c11_t40;
  real_T c11_t41;
  real_T c11_t42;
  real_T c11_t43;
  real_T c11_t45;
  real_T c11_t44;
  real_T c11_t46;
  real_T c11_t47;
  real_T c11_t48;
  real_T c11_t49;
  real_T c11_s_6[3];
  real_T c11_s_5_6_5[3];
  real_T c11_s_4_5_4[3];
  real_T c11_s_3_4_3[3];
  real_T c11_s_2_3_2[3];
  real_T c11_s_1_2_1[3];
  real_T c11_s_1t_1_1[3];
  real_T c11_s_1h_1t_1[3];
  real_T c11_R_5_0[9];
  real_T c11_R_1_2[9];
  real_T c11_R_2_3[9];
  real_T c11_R_3_4[9];
  real_T c11_R_4_5[9];
  real_T c11_R_4_0[9];
  real_T c11_R_3_0[9];
  real_T c11_R_2_0[9];
  real_T c11_R_1_0[9];
  real_T c11_s_5[3];
  real_T c11_s_4[3];
  real_T c11_s_3[3];
  real_T c11_s_2[3];
  real_T c11_s_1[3];
  real_T c11_s_1t[3];
  real_T c11_s_1h[3];
  real_T c11_J[4];
  real_T c11_nargin = 3.0;
  real_T c11_nargout = 1.0;
  real_T c11_x;
  real_T c11_b_x;
  real_T c11_c_x;
  real_T c11_d_x;
  real_T c11_e_x;
  real_T c11_f_x;
  real_T c11_g_x;
  real_T c11_h_x;
  real_T c11_i_x;
  real_T c11_j_x;
  real_T c11_k_x;
  real_T c11_l_x;
  real_T c11_m_x[4];
  int32_T c11_k;
  int32_T c11_b_k;
  int32_T c11_i78;
  real_T c11_A;
  real_T c11_n_x;
  real_T c11_o_x;
  real_T c11_p_x;
  real_T c11_y;
  int32_T c11_i79;
  real_T c11_dv14[9];
  int32_T c11_i80;
  real_T c11_dv15[9];
  int32_T c11_i81;
  int32_T c11_i82;
  static real_T c11_b[9] = { 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, -0.0, 0.0, 1.0 };

  real_T c11_dv16[9];
  int32_T c11_i83;
  int32_T c11_i84;
  real_T c11_a[9];
  int32_T c11_i85;
  real_T c11_b_b[9];
  int32_T c11_i86;
  int32_T c11_i87;
  int32_T c11_i88;
  real_T c11_C[9];
  int32_T c11_i89;
  int32_T c11_i90;
  int32_T c11_i91;
  int32_T c11_i92;
  int32_T c11_i93;
  int32_T c11_i94;
  int32_T c11_i95;
  int32_T c11_i96;
  int32_T c11_i97;
  int32_T c11_i98;
  int32_T c11_i99;
  int32_T c11_i100;
  int32_T c11_i101;
  int32_T c11_i102;
  int32_T c11_i103;
  int32_T c11_i104;
  int32_T c11_i105;
  int32_T c11_i106;
  int32_T c11_i107;
  int32_T c11_i108;
  int32_T c11_i109;
  int32_T c11_i110;
  int32_T c11_i111;
  int32_T c11_i112;
  int32_T c11_i113;
  int32_T c11_i114;
  int32_T c11_i115;
  int32_T c11_i116;
  int32_T c11_i117;
  int32_T c11_i118;
  int32_T c11_i119;
  int32_T c11_i120;
  int32_T c11_i121;
  int32_T c11_i122;
  int32_T c11_i123;
  int32_T c11_i124;
  int32_T c11_i125;
  int32_T c11_i126;
  int32_T c11_i127;
  int32_T c11_i128;
  int32_T c11_i129;
  int32_T c11_i130;
  int32_T c11_i131;
  int32_T c11_i132;
  int32_T c11_i133;
  int32_T c11_i134;
  int32_T c11_i135;
  int32_T c11_i136;
  real_T c11_c_b[3];
  int32_T c11_i137;
  real_T c11_b_y[3];
  int32_T c11_i138;
  int32_T c11_i139;
  int32_T c11_i140;
  int32_T c11_i141;
  int32_T c11_i142;
  int32_T c11_i143;
  int32_T c11_i144;
  int32_T c11_i145;
  int32_T c11_i146;
  int32_T c11_i147;
  int32_T c11_i148;
  int32_T c11_i149;
  int32_T c11_i150;
  int32_T c11_i151;
  int32_T c11_i152;
  int32_T c11_i153;
  int32_T c11_i154;
  int32_T c11_i155;
  int32_T c11_i156;
  int32_T c11_i157;
  int32_T c11_i158;
  int32_T c11_i159;
  int32_T c11_i160;
  int32_T c11_i161;
  int32_T c11_i162;
  int32_T c11_i163;
  int32_T c11_i164;
  int32_T c11_i165;
  int32_T c11_i166;
  int32_T c11_i167;
  int32_T c11_i168;
  int32_T c11_i169;
  int32_T c11_i170;
  int32_T c11_i171;
  int32_T c11_i172;
  int32_T c11_i173;
  int32_T c11_i174;
  int32_T c11_i175;
  int32_T c11_i176;
  int32_T c11_i177;
  int32_T c11_i178;
  _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 103U, 103U, c11_e_debug_family_names,
    c11_debug_family_var_map);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_RHAA, 0U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_RHFE, 1U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_RKFE, 2U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_R_trunk_0_1_1, 3U,
    c11_c_sf_marshallOut, c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_R_trunk_0_1_2, 4U,
    c11_c_sf_marshallOut, c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_R_trunk_0_1_3, 5U,
    c11_c_sf_marshallOut, c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_R_trunk_0_2_1, 6U,
    c11_c_sf_marshallOut, c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_R_trunk_0_2_2, 7U,
    c11_c_sf_marshallOut, c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_R_trunk_0_2_3, 8U,
    c11_c_sf_marshallOut, c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_R_trunk_0_3_1, 9U,
    c11_c_sf_marshallOut, c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_R_trunk_0_3_2, 10U,
    c11_c_sf_marshallOut, c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_R_trunk_0_3_3, 11U,
    c11_c_sf_marshallOut, c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_wPelvis, 12U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_dxHAA2HEE, 13U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_dyHAA2HEE, 14U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_dzHAA2HEE, 15U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_dxHEE2HFE, 16U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_dyHEE2HFE, 17U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_dzHEE2HFE, 18U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_lThigh, 19U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_lShank, 20U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_dxFoot, 21U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_hFoot, 22U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_lFoot, 23U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t2, 24U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t3, 25U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t4, 26U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t9, 27U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t5, 28U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t6, 29U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t7, 30U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t8, 31U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t10, 32U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t11, 33U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t12, 34U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t13, 35U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t14, 36U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t15, 37U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t16, 38U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t17, 39U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t18, 40U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t19, 41U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t20, 42U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t21, 43U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t22, 44U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t24, 45U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t23, 46U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t25, 47U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t26, 48U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t27, 49U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t28, 50U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t29, 51U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t34, 52U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t30, 53U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t31, 54U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t32, 55U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t33, 56U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t35, 57U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t36, 58U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t37, 59U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t38, 60U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t39, 61U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t40, 62U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t41, 63U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t42, 64U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t43, 65U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t45, 66U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t44, 67U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t46, 68U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t47, 69U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t48, 70U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t49, 71U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_s_6, 72U, c11_d_sf_marshallOut,
    c11_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_s_5_6_5, 73U, c11_d_sf_marshallOut,
    c11_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_s_4_5_4, 74U, c11_d_sf_marshallOut,
    c11_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_s_3_4_3, 75U, c11_d_sf_marshallOut,
    c11_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_s_2_3_2, 76U, c11_d_sf_marshallOut,
    c11_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_s_1_2_1, 77U, c11_d_sf_marshallOut,
    c11_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_s_1t_1_1, 78U, c11_d_sf_marshallOut,
    c11_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_s_1h_1t_1, 79U, c11_d_sf_marshallOut,
    c11_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_R_5_0, 80U, c11_f_sf_marshallOut,
    c11_f_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_R_1_2, 81U, c11_f_sf_marshallOut,
    c11_f_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_R_2_3, 82U, c11_f_sf_marshallOut,
    c11_f_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML(c11_R_3_4, 83U, c11_f_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_R_4_5, 84U, c11_f_sf_marshallOut,
    c11_f_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_R_4_0, 85U, c11_f_sf_marshallOut,
    c11_f_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_R_3_0, 86U, c11_f_sf_marshallOut,
    c11_f_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_R_2_0, 87U, c11_f_sf_marshallOut,
    c11_f_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_R_1_0, 88U, c11_f_sf_marshallOut,
    c11_f_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_s_5, 89U, c11_d_sf_marshallOut,
    c11_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_s_4, 90U, c11_d_sf_marshallOut,
    c11_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_s_3, 91U, c11_d_sf_marshallOut,
    c11_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_s_2, 92U, c11_d_sf_marshallOut,
    c11_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_s_1, 93U, c11_d_sf_marshallOut,
    c11_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_s_1t, 94U, c11_d_sf_marshallOut,
    c11_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_s_1h, 95U, c11_d_sf_marshallOut,
    c11_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_J, 96U, c11_h_sf_marshallOut,
    c11_e_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_nargin, 97U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_nargout, 98U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_swjointangles, 99U,
    c11_d_sf_marshallOut, c11_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_Rtrunk, 100U, c11_f_sf_marshallOut,
    c11_f_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_SegmentLengths, 101U,
    c11_e_sf_marshallOut, c11_g_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_xz, 102U, c11_b_sf_marshallOut,
    c11_b_sf_marshallIn);
  CV_EML_FCN(0, 1);
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 30);
  c11_RHAA = c11_swjointangles[0];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 31);
  c11_RHFE = c11_swjointangles[1];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 32);
  c11_RKFE = c11_swjointangles[2];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 34);
  c11_R_trunk_0_1_1 = c11_Rtrunk[0];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 35);
  c11_R_trunk_0_1_2 = c11_Rtrunk[3];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 36);
  c11_R_trunk_0_1_3 = c11_Rtrunk[3];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 37);
  c11_R_trunk_0_2_1 = c11_Rtrunk[1];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 38);
  c11_R_trunk_0_2_2 = c11_Rtrunk[4];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 39);
  c11_R_trunk_0_2_3 = c11_Rtrunk[7];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 40);
  c11_R_trunk_0_3_1 = c11_Rtrunk[2];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 41);
  c11_R_trunk_0_3_2 = c11_Rtrunk[5];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 42);
  c11_R_trunk_0_3_3 = c11_Rtrunk[8];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 45);
  c11_wPelvis = c11_SegmentLengths[1];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 46);
  c11_dxHAA2HEE = c11_SegmentLengths[2];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 47);
  c11_dyHAA2HEE = c11_SegmentLengths[3];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 48);
  c11_dzHAA2HEE = c11_SegmentLengths[4];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 49);
  c11_dxHEE2HFE = c11_SegmentLengths[5];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 50);
  c11_dyHEE2HFE = c11_SegmentLengths[6];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 51);
  c11_dzHEE2HFE = c11_SegmentLengths[7];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 52);
  c11_lThigh = c11_SegmentLengths[8];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 53);
  c11_lShank = c11_SegmentLengths[9];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 54);
  c11_dxFoot = c11_SegmentLengths[10];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 55);
  c11_hFoot = c11_SegmentLengths[11];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 56);
  c11_lFoot = c11_SegmentLengths[12];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 59);
  c11_x = c11_RHAA;
  c11_t2 = c11_x;
  c11_b_x = c11_t2;
  c11_t2 = c11_b_x;
  c11_t2 = muDoubleScalarCos(c11_t2);
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 60);
  c11_t3 = c11_R_trunk_0_1_3 * c11_t2;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 61);
  c11_c_x = c11_RHAA;
  c11_t4 = c11_c_x;
  c11_d_x = c11_t4;
  c11_t4 = c11_d_x;
  c11_t4 = muDoubleScalarSin(c11_t4);
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 62);
  c11_t9 = c11_R_trunk_0_1_2 * c11_t4;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 63);
  c11_t5 = c11_t3 - c11_t9;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 64);
  c11_t6 = c11_R_trunk_0_1_2 * c11_t2;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 65);
  c11_t7 = c11_R_trunk_0_1_3 * c11_t4;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 66);
  c11_t8 = c11_t6 + c11_t7;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 67);
  c11_e_x = c11_RHFE;
  c11_t10 = c11_e_x;
  c11_f_x = c11_t10;
  c11_t10 = c11_f_x;
  c11_t10 = muDoubleScalarCos(c11_t10);
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 68);
  c11_g_x = c11_RKFE;
  c11_t11 = c11_g_x;
  c11_h_x = c11_t11;
  c11_t11 = c11_h_x;
  c11_t11 = muDoubleScalarCos(c11_t11);
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 69);
  c11_i_x = c11_RHFE;
  c11_t12 = c11_i_x;
  c11_j_x = c11_t12;
  c11_t12 = c11_j_x;
  c11_t12 = muDoubleScalarSin(c11_t12);
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 70);
  c11_k_x = c11_RKFE;
  c11_t13 = c11_k_x;
  c11_l_x = c11_t13;
  c11_t13 = c11_l_x;
  c11_t13 = muDoubleScalarSin(c11_t13);
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 71);
  c11_t14 = c11_t5 * c11_t10 * c11_t13;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 72);
  c11_t15 = c11_t5 * c11_t11 * c11_t12;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 73);
  c11_t16 = c11_t14 + c11_t15;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 74);
  c11_t17 = c11_t5 * c11_t10 * c11_t11;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 75);
  c11_t18 = c11_t17 - c11_t5 * c11_t12 * c11_t13;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 76);
  c11_t19 = c11_t8 * c11_t12;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 77);
  c11_t20 = c11_R_trunk_0_1_1 * c11_t10;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 78);
  c11_t21 = c11_t19 + c11_t20;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 79);
  c11_t22 = c11_R_trunk_0_1_1 * c11_t12;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 80);
  c11_t24 = c11_t8 * c11_t10;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 81);
  c11_t23 = c11_t22 - c11_t24;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 82);
  c11_t25 = c11_t11 * c11_t23;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 83);
  c11_t26 = c11_t13 * c11_t21;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 84);
  c11_t27 = c11_t11 * c11_t21;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 85);
  c11_t28 = c11_t27 - c11_t13 * c11_t23;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 86);
  c11_t29 = c11_R_trunk_0_3_3 * c11_t2;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 87);
  c11_t34 = c11_R_trunk_0_3_2 * c11_t4;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 88);
  c11_t30 = c11_t29 - c11_t34;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 89);
  c11_t31 = c11_R_trunk_0_3_2 * c11_t2;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 90);
  c11_t32 = c11_R_trunk_0_3_3 * c11_t4;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 91);
  c11_t33 = c11_t31 + c11_t32;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 92);
  c11_t35 = c11_t10 * c11_t13 * c11_t30;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 93);
  c11_t36 = c11_t11 * c11_t12 * c11_t30;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 94);
  c11_t37 = c11_t35 + c11_t36;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 95);
  c11_t38 = c11_t10 * c11_t11 * c11_t30;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 96);
  c11_t39 = c11_t38 - c11_t12 * c11_t13 * c11_t30;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 97);
  c11_t40 = c11_t12 * c11_t33;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 98);
  c11_t41 = c11_R_trunk_0_3_1 * c11_t10;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 99);
  c11_t42 = c11_t40 + c11_t41;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 100);
  c11_t43 = c11_R_trunk_0_3_1 * c11_t12;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 101);
  c11_t45 = c11_t10 * c11_t33;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 102);
  c11_t44 = c11_t43 - c11_t45;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 103);
  c11_t46 = c11_t11 * c11_t44;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 104);
  c11_t47 = c11_t13 * c11_t42;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 105);
  c11_t48 = c11_t11 * c11_t42;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 106);
  c11_t49 = c11_t48 - c11_t13 * c11_t44;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 107);
  c11_m_x[0] = (((((((c11_dxFoot * c11_t16 + c11_dyHAA2HEE * c11_t5) +
                     c11_dyHEE2HFE * c11_t5) - c11_dzHAA2HEE * c11_t8) -
                   c11_dzHEE2HFE * c11_t8) - c11_hFoot * c11_t18) - c11_lFoot *
                 c11_t16) - c11_lShank * c11_t18) - c11_lThigh * c11_t5 *
    c11_t10;
  c11_m_x[1] = (((((((c11_dxFoot * c11_t37 + c11_dyHAA2HEE * c11_t30) +
                     c11_dyHEE2HFE * c11_t30) - c11_dzHAA2HEE * c11_t33) -
                   c11_dzHEE2HFE * c11_t33) - c11_hFoot * c11_t39) - c11_lFoot *
                 c11_t37) - c11_lShank * c11_t39) - c11_lThigh * c11_t10 *
    c11_t30;
  c11_m_x[2] = (((-c11_dxFoot * (c11_t25 + c11_t26) + c11_lFoot * (c11_t25 +
    c11_t26)) + c11_hFoot * c11_t28) + c11_lShank * c11_t28) + c11_lThigh *
    c11_t21;
  c11_m_x[3] = (((-c11_dxFoot * (c11_t46 + c11_t47) + c11_lFoot * (c11_t46 +
    c11_t47)) + c11_hFoot * c11_t49) + c11_lShank * c11_t49) + c11_lThigh *
    c11_t42;
  for (c11_k = 1; c11_k < 5; c11_k++) {
    c11_b_k = c11_k;
    c11_J[_SFD_EML_ARRAY_BOUNDS_CHECK("", (int32_T)_SFD_INTEGER_CHECK("",
      (real_T)c11_b_k), 1, 4, 1, 0) - 1] = c11_m_x[_SFD_EML_ARRAY_BOUNDS_CHECK(
      "", (int32_T)_SFD_INTEGER_CHECK("", (real_T)c11_b_k), 1, 4, 1, 0) - 1];
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 109);
  for (c11_i78 = 0; c11_i78 < 3; c11_i78++) {
    c11_s_6[c11_i78] = 0.0;
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 110);
  c11_A = c11_wPelvis;
  c11_n_x = c11_A;
  c11_o_x = c11_n_x;
  c11_p_x = c11_o_x;
  c11_y = c11_p_x / 2.0;
  c11_s_5_6_5[0] = 0.0;
  c11_s_5_6_5[1] = 0.0;
  c11_s_5_6_5[2] = c11_y;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 111);
  c11_s_4_5_4[0] = c11_dxHAA2HEE;
  c11_s_4_5_4[1] = c11_dyHAA2HEE;
  c11_s_4_5_4[2] = c11_dzHAA2HEE;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 112);
  c11_s_3_4_3[0] = c11_dxHEE2HFE;
  c11_s_3_4_3[1] = c11_dyHEE2HFE;
  c11_s_3_4_3[2] = c11_dzHEE2HFE;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 113);
  c11_s_2_3_2[0] = 0.0;
  c11_s_2_3_2[1] = -c11_lThigh;
  c11_s_2_3_2[2] = 0.0;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 114);
  c11_s_1_2_1[0] = 0.0;
  c11_s_1_2_1[1] = -c11_lShank;
  c11_s_1_2_1[2] = 0.0;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 115);
  c11_s_1t_1_1[0] = c11_dxFoot;
  c11_s_1t_1_1[1] = -c11_hFoot;
  c11_s_1t_1_1[2] = 0.0;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 116);
  c11_s_1h_1t_1[0] = -c11_lFoot;
  c11_s_1h_1t_1[1] = 0.0;
  c11_s_1h_1t_1[2] = 0.0;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 118);
  for (c11_i79 = 0; c11_i79 < 9; c11_i79++) {
    c11_R_5_0[c11_i79] = c11_Rtrunk[c11_i79];
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 120);
  c11_Rz(chartInstance, -c11_RKFE, c11_dv14);
  for (c11_i80 = 0; c11_i80 < 9; c11_i80++) {
    c11_R_1_2[c11_i80] = c11_dv14[c11_i80];
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 121);
  c11_Rz(chartInstance, -c11_RHFE, c11_dv15);
  for (c11_i81 = 0; c11_i81 < 9; c11_i81++) {
    c11_R_2_3[c11_i81] = c11_dv15[c11_i81];
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 122);
  for (c11_i82 = 0; c11_i82 < 9; c11_i82++) {
    c11_R_3_4[c11_i82] = c11_b[c11_i82];
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 123);
  c11_Rx(chartInstance, -c11_RHAA, c11_dv16);
  for (c11_i83 = 0; c11_i83 < 9; c11_i83++) {
    c11_R_4_5[c11_i83] = c11_dv16[c11_i83];
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 125);
  for (c11_i84 = 0; c11_i84 < 9; c11_i84++) {
    c11_a[c11_i84] = c11_R_5_0[c11_i84];
  }

  for (c11_i85 = 0; c11_i85 < 9; c11_i85++) {
    c11_b_b[c11_i85] = c11_R_4_5[c11_i85];
  }

  c11_eml_scalar_eg(chartInstance);
  c11_eml_scalar_eg(chartInstance);
  for (c11_i86 = 0; c11_i86 < 9; c11_i86++) {
    c11_R_4_0[c11_i86] = 0.0;
  }

  for (c11_i87 = 0; c11_i87 < 9; c11_i87++) {
    c11_R_4_0[c11_i87] = 0.0;
  }

  for (c11_i88 = 0; c11_i88 < 9; c11_i88++) {
    c11_C[c11_i88] = c11_R_4_0[c11_i88];
  }

  for (c11_i89 = 0; c11_i89 < 9; c11_i89++) {
    c11_R_4_0[c11_i89] = c11_C[c11_i89];
  }

  c11_threshold(chartInstance);
  for (c11_i90 = 0; c11_i90 < 9; c11_i90++) {
    c11_C[c11_i90] = c11_R_4_0[c11_i90];
  }

  for (c11_i91 = 0; c11_i91 < 9; c11_i91++) {
    c11_R_4_0[c11_i91] = c11_C[c11_i91];
  }

  for (c11_i92 = 0; c11_i92 < 3; c11_i92++) {
    c11_i93 = 0;
    for (c11_i94 = 0; c11_i94 < 3; c11_i94++) {
      c11_R_4_0[c11_i93 + c11_i92] = 0.0;
      c11_i95 = 0;
      for (c11_i96 = 0; c11_i96 < 3; c11_i96++) {
        c11_R_4_0[c11_i93 + c11_i92] += c11_a[c11_i95 + c11_i92] *
          c11_b_b[c11_i96 + c11_i93];
        c11_i95 += 3;
      }

      c11_i93 += 3;
    }
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 126);
  for (c11_i97 = 0; c11_i97 < 9; c11_i97++) {
    c11_a[c11_i97] = c11_R_4_0[c11_i97];
  }

  c11_eml_scalar_eg(chartInstance);
  c11_eml_scalar_eg(chartInstance);
  for (c11_i98 = 0; c11_i98 < 9; c11_i98++) {
    c11_R_3_0[c11_i98] = 0.0;
  }

  for (c11_i99 = 0; c11_i99 < 9; c11_i99++) {
    c11_R_3_0[c11_i99] = 0.0;
  }

  for (c11_i100 = 0; c11_i100 < 9; c11_i100++) {
    c11_C[c11_i100] = c11_R_3_0[c11_i100];
  }

  for (c11_i101 = 0; c11_i101 < 9; c11_i101++) {
    c11_R_3_0[c11_i101] = c11_C[c11_i101];
  }

  c11_threshold(chartInstance);
  for (c11_i102 = 0; c11_i102 < 9; c11_i102++) {
    c11_C[c11_i102] = c11_R_3_0[c11_i102];
  }

  for (c11_i103 = 0; c11_i103 < 9; c11_i103++) {
    c11_R_3_0[c11_i103] = c11_C[c11_i103];
  }

  for (c11_i104 = 0; c11_i104 < 3; c11_i104++) {
    c11_i105 = 0;
    for (c11_i106 = 0; c11_i106 < 3; c11_i106++) {
      c11_R_3_0[c11_i105 + c11_i104] = 0.0;
      c11_i107 = 0;
      for (c11_i108 = 0; c11_i108 < 3; c11_i108++) {
        c11_R_3_0[c11_i105 + c11_i104] += c11_a[c11_i107 + c11_i104] *
          c11_b[c11_i108 + c11_i105];
        c11_i107 += 3;
      }

      c11_i105 += 3;
    }
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, MAX_int8_T);
  for (c11_i109 = 0; c11_i109 < 9; c11_i109++) {
    c11_a[c11_i109] = c11_R_3_0[c11_i109];
  }

  for (c11_i110 = 0; c11_i110 < 9; c11_i110++) {
    c11_b_b[c11_i110] = c11_R_2_3[c11_i110];
  }

  c11_eml_scalar_eg(chartInstance);
  c11_eml_scalar_eg(chartInstance);
  for (c11_i111 = 0; c11_i111 < 9; c11_i111++) {
    c11_R_2_0[c11_i111] = 0.0;
  }

  for (c11_i112 = 0; c11_i112 < 9; c11_i112++) {
    c11_R_2_0[c11_i112] = 0.0;
  }

  for (c11_i113 = 0; c11_i113 < 9; c11_i113++) {
    c11_C[c11_i113] = c11_R_2_0[c11_i113];
  }

  for (c11_i114 = 0; c11_i114 < 9; c11_i114++) {
    c11_R_2_0[c11_i114] = c11_C[c11_i114];
  }

  c11_threshold(chartInstance);
  for (c11_i115 = 0; c11_i115 < 9; c11_i115++) {
    c11_C[c11_i115] = c11_R_2_0[c11_i115];
  }

  for (c11_i116 = 0; c11_i116 < 9; c11_i116++) {
    c11_R_2_0[c11_i116] = c11_C[c11_i116];
  }

  for (c11_i117 = 0; c11_i117 < 3; c11_i117++) {
    c11_i118 = 0;
    for (c11_i119 = 0; c11_i119 < 3; c11_i119++) {
      c11_R_2_0[c11_i118 + c11_i117] = 0.0;
      c11_i120 = 0;
      for (c11_i121 = 0; c11_i121 < 3; c11_i121++) {
        c11_R_2_0[c11_i118 + c11_i117] += c11_a[c11_i120 + c11_i117] *
          c11_b_b[c11_i121 + c11_i118];
        c11_i120 += 3;
      }

      c11_i118 += 3;
    }
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 128U);
  for (c11_i122 = 0; c11_i122 < 9; c11_i122++) {
    c11_a[c11_i122] = c11_R_2_0[c11_i122];
  }

  for (c11_i123 = 0; c11_i123 < 9; c11_i123++) {
    c11_b_b[c11_i123] = c11_R_1_2[c11_i123];
  }

  c11_eml_scalar_eg(chartInstance);
  c11_eml_scalar_eg(chartInstance);
  for (c11_i124 = 0; c11_i124 < 9; c11_i124++) {
    c11_R_1_0[c11_i124] = 0.0;
  }

  for (c11_i125 = 0; c11_i125 < 9; c11_i125++) {
    c11_R_1_0[c11_i125] = 0.0;
  }

  for (c11_i126 = 0; c11_i126 < 9; c11_i126++) {
    c11_C[c11_i126] = c11_R_1_0[c11_i126];
  }

  for (c11_i127 = 0; c11_i127 < 9; c11_i127++) {
    c11_R_1_0[c11_i127] = c11_C[c11_i127];
  }

  c11_threshold(chartInstance);
  for (c11_i128 = 0; c11_i128 < 9; c11_i128++) {
    c11_C[c11_i128] = c11_R_1_0[c11_i128];
  }

  for (c11_i129 = 0; c11_i129 < 9; c11_i129++) {
    c11_R_1_0[c11_i129] = c11_C[c11_i129];
  }

  for (c11_i130 = 0; c11_i130 < 3; c11_i130++) {
    c11_i131 = 0;
    for (c11_i132 = 0; c11_i132 < 3; c11_i132++) {
      c11_R_1_0[c11_i131 + c11_i130] = 0.0;
      c11_i133 = 0;
      for (c11_i134 = 0; c11_i134 < 3; c11_i134++) {
        c11_R_1_0[c11_i131 + c11_i130] += c11_a[c11_i133 + c11_i130] *
          c11_b_b[c11_i134 + c11_i131];
        c11_i133 += 3;
      }

      c11_i131 += 3;
    }
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 130U);
  for (c11_i135 = 0; c11_i135 < 9; c11_i135++) {
    c11_a[c11_i135] = c11_R_5_0[c11_i135];
  }

  for (c11_i136 = 0; c11_i136 < 3; c11_i136++) {
    c11_c_b[c11_i136] = c11_s_5_6_5[c11_i136];
  }

  c11_b_eml_scalar_eg(chartInstance);
  c11_b_eml_scalar_eg(chartInstance);
  c11_threshold(chartInstance);
  for (c11_i137 = 0; c11_i137 < 3; c11_i137++) {
    c11_b_y[c11_i137] = 0.0;
    c11_i138 = 0;
    for (c11_i139 = 0; c11_i139 < 3; c11_i139++) {
      c11_b_y[c11_i137] += c11_a[c11_i138 + c11_i137] * c11_c_b[c11_i139];
      c11_i138 += 3;
    }
  }

  for (c11_i140 = 0; c11_i140 < 3; c11_i140++) {
    c11_s_5[c11_i140] = c11_s_6[c11_i140] + c11_b_y[c11_i140];
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 131U);
  for (c11_i141 = 0; c11_i141 < 9; c11_i141++) {
    c11_a[c11_i141] = c11_R_4_0[c11_i141];
  }

  for (c11_i142 = 0; c11_i142 < 3; c11_i142++) {
    c11_c_b[c11_i142] = c11_s_4_5_4[c11_i142];
  }

  c11_b_eml_scalar_eg(chartInstance);
  c11_b_eml_scalar_eg(chartInstance);
  c11_threshold(chartInstance);
  for (c11_i143 = 0; c11_i143 < 3; c11_i143++) {
    c11_b_y[c11_i143] = 0.0;
    c11_i144 = 0;
    for (c11_i145 = 0; c11_i145 < 3; c11_i145++) {
      c11_b_y[c11_i143] += c11_a[c11_i144 + c11_i143] * c11_c_b[c11_i145];
      c11_i144 += 3;
    }
  }

  for (c11_i146 = 0; c11_i146 < 3; c11_i146++) {
    c11_s_4[c11_i146] = c11_s_5[c11_i146] + c11_b_y[c11_i146];
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 132U);
  for (c11_i147 = 0; c11_i147 < 9; c11_i147++) {
    c11_a[c11_i147] = c11_R_3_0[c11_i147];
  }

  for (c11_i148 = 0; c11_i148 < 3; c11_i148++) {
    c11_c_b[c11_i148] = c11_s_3_4_3[c11_i148];
  }

  c11_b_eml_scalar_eg(chartInstance);
  c11_b_eml_scalar_eg(chartInstance);
  c11_threshold(chartInstance);
  for (c11_i149 = 0; c11_i149 < 3; c11_i149++) {
    c11_b_y[c11_i149] = 0.0;
    c11_i150 = 0;
    for (c11_i151 = 0; c11_i151 < 3; c11_i151++) {
      c11_b_y[c11_i149] += c11_a[c11_i150 + c11_i149] * c11_c_b[c11_i151];
      c11_i150 += 3;
    }
  }

  for (c11_i152 = 0; c11_i152 < 3; c11_i152++) {
    c11_s_3[c11_i152] = c11_s_4[c11_i152] + c11_b_y[c11_i152];
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 133U);
  for (c11_i153 = 0; c11_i153 < 9; c11_i153++) {
    c11_a[c11_i153] = c11_R_2_0[c11_i153];
  }

  for (c11_i154 = 0; c11_i154 < 3; c11_i154++) {
    c11_c_b[c11_i154] = c11_s_2_3_2[c11_i154];
  }

  c11_b_eml_scalar_eg(chartInstance);
  c11_b_eml_scalar_eg(chartInstance);
  c11_threshold(chartInstance);
  for (c11_i155 = 0; c11_i155 < 3; c11_i155++) {
    c11_b_y[c11_i155] = 0.0;
    c11_i156 = 0;
    for (c11_i157 = 0; c11_i157 < 3; c11_i157++) {
      c11_b_y[c11_i155] += c11_a[c11_i156 + c11_i155] * c11_c_b[c11_i157];
      c11_i156 += 3;
    }
  }

  for (c11_i158 = 0; c11_i158 < 3; c11_i158++) {
    c11_s_2[c11_i158] = c11_s_3[c11_i158] + c11_b_y[c11_i158];
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 134U);
  for (c11_i159 = 0; c11_i159 < 9; c11_i159++) {
    c11_a[c11_i159] = c11_R_1_0[c11_i159];
  }

  for (c11_i160 = 0; c11_i160 < 3; c11_i160++) {
    c11_c_b[c11_i160] = c11_s_1_2_1[c11_i160];
  }

  c11_b_eml_scalar_eg(chartInstance);
  c11_b_eml_scalar_eg(chartInstance);
  c11_threshold(chartInstance);
  for (c11_i161 = 0; c11_i161 < 3; c11_i161++) {
    c11_b_y[c11_i161] = 0.0;
    c11_i162 = 0;
    for (c11_i163 = 0; c11_i163 < 3; c11_i163++) {
      c11_b_y[c11_i161] += c11_a[c11_i162 + c11_i161] * c11_c_b[c11_i163];
      c11_i162 += 3;
    }
  }

  for (c11_i164 = 0; c11_i164 < 3; c11_i164++) {
    c11_s_1[c11_i164] = c11_s_2[c11_i164] + c11_b_y[c11_i164];
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 135U);
  for (c11_i165 = 0; c11_i165 < 9; c11_i165++) {
    c11_a[c11_i165] = c11_R_1_0[c11_i165];
  }

  for (c11_i166 = 0; c11_i166 < 3; c11_i166++) {
    c11_c_b[c11_i166] = c11_s_1t_1_1[c11_i166];
  }

  c11_b_eml_scalar_eg(chartInstance);
  c11_b_eml_scalar_eg(chartInstance);
  c11_threshold(chartInstance);
  for (c11_i167 = 0; c11_i167 < 3; c11_i167++) {
    c11_b_y[c11_i167] = 0.0;
    c11_i168 = 0;
    for (c11_i169 = 0; c11_i169 < 3; c11_i169++) {
      c11_b_y[c11_i167] += c11_a[c11_i168 + c11_i167] * c11_c_b[c11_i169];
      c11_i168 += 3;
    }
  }

  for (c11_i170 = 0; c11_i170 < 3; c11_i170++) {
    c11_s_1t[c11_i170] = c11_s_1[c11_i170] + c11_b_y[c11_i170];
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 136U);
  for (c11_i171 = 0; c11_i171 < 9; c11_i171++) {
    c11_a[c11_i171] = c11_R_1_0[c11_i171];
  }

  for (c11_i172 = 0; c11_i172 < 3; c11_i172++) {
    c11_c_b[c11_i172] = c11_s_1h_1t_1[c11_i172];
  }

  c11_b_eml_scalar_eg(chartInstance);
  c11_b_eml_scalar_eg(chartInstance);
  c11_threshold(chartInstance);
  for (c11_i173 = 0; c11_i173 < 3; c11_i173++) {
    c11_b_y[c11_i173] = 0.0;
    c11_i174 = 0;
    for (c11_i175 = 0; c11_i175 < 3; c11_i175++) {
      c11_b_y[c11_i173] += c11_a[c11_i174 + c11_i173] * c11_c_b[c11_i175];
      c11_i174 += 3;
    }
  }

  for (c11_i176 = 0; c11_i176 < 3; c11_i176++) {
    c11_s_1h[c11_i176] = c11_s_1t[c11_i176] + c11_b_y[c11_i176];
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 138U);
  c11_i177 = 0;
  for (c11_i178 = 0; c11_i178 < 2; c11_i178++) {
    c11_xz[c11_i178] = c11_s_1h[c11_i177];
    c11_i177 += 2;
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, -138);
  _SFD_SYMBOL_SCOPE_POP();
}

static void c11_eml_scalar_eg(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance)
{
  (void)chartInstance;
}

static void c11_threshold(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance)
{
  (void)chartInstance;
}

static void c11_b_eml_scalar_eg(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance)
{
  (void)chartInstance;
}

static void c11_b_fk_KFE_jacobian(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance, real_T c11_swjointangles[3], real_T c11_Rtrunk[9], real_T
  c11_SegmentLengths[13], real_T c11_xz[2], real_T c11_J[4])
{
  uint32_T c11_debug_family_var_map[103];
  real_T c11_RHAA;
  real_T c11_RHFE;
  real_T c11_RKFE;
  real_T c11_R_trunk_0_1_1;
  real_T c11_R_trunk_0_1_2;
  real_T c11_R_trunk_0_1_3;
  real_T c11_R_trunk_0_2_1;
  real_T c11_R_trunk_0_2_2;
  real_T c11_R_trunk_0_2_3;
  real_T c11_R_trunk_0_3_1;
  real_T c11_R_trunk_0_3_2;
  real_T c11_R_trunk_0_3_3;
  real_T c11_wPelvis;
  real_T c11_dxHAA2HEE;
  real_T c11_dyHAA2HEE;
  real_T c11_dzHAA2HEE;
  real_T c11_dxHEE2HFE;
  real_T c11_dyHEE2HFE;
  real_T c11_dzHEE2HFE;
  real_T c11_lThigh;
  real_T c11_lShank;
  real_T c11_dxFoot;
  real_T c11_hFoot;
  real_T c11_lFoot;
  real_T c11_t2;
  real_T c11_t3;
  real_T c11_t4;
  real_T c11_t9;
  real_T c11_t5;
  real_T c11_t6;
  real_T c11_t7;
  real_T c11_t8;
  real_T c11_t10;
  real_T c11_t11;
  real_T c11_t12;
  real_T c11_t13;
  real_T c11_t14;
  real_T c11_t15;
  real_T c11_t16;
  real_T c11_t17;
  real_T c11_t18;
  real_T c11_t19;
  real_T c11_t20;
  real_T c11_t21;
  real_T c11_t22;
  real_T c11_t24;
  real_T c11_t23;
  real_T c11_t25;
  real_T c11_t26;
  real_T c11_t27;
  real_T c11_t28;
  real_T c11_t29;
  real_T c11_t34;
  real_T c11_t30;
  real_T c11_t31;
  real_T c11_t32;
  real_T c11_t33;
  real_T c11_t35;
  real_T c11_t36;
  real_T c11_t37;
  real_T c11_t38;
  real_T c11_t39;
  real_T c11_t40;
  real_T c11_t41;
  real_T c11_t42;
  real_T c11_t43;
  real_T c11_t45;
  real_T c11_t44;
  real_T c11_t46;
  real_T c11_t47;
  real_T c11_t48;
  real_T c11_t49;
  real_T c11_s_6[3];
  real_T c11_s_5_6_5[3];
  real_T c11_s_4_5_4[3];
  real_T c11_s_3_4_3[3];
  real_T c11_s_2_3_2[3];
  real_T c11_s_1_2_1[3];
  real_T c11_s_1t_1_1[3];
  real_T c11_s_1h_1t_1[3];
  real_T c11_R_5_0[9];
  real_T c11_R_1_2[9];
  real_T c11_R_2_3[9];
  real_T c11_R_3_4[9];
  real_T c11_R_4_5[9];
  real_T c11_R_4_0[9];
  real_T c11_R_3_0[9];
  real_T c11_R_2_0[9];
  real_T c11_R_1_0[9];
  real_T c11_s_5[3];
  real_T c11_s_4[3];
  real_T c11_s_3[3];
  real_T c11_s_2[3];
  real_T c11_s_1[3];
  real_T c11_s_1t[3];
  real_T c11_s_1h[3];
  real_T c11_nargin = 3.0;
  real_T c11_nargout = 2.0;
  real_T c11_x;
  real_T c11_b_x;
  real_T c11_c_x;
  real_T c11_d_x;
  real_T c11_e_x;
  real_T c11_f_x;
  real_T c11_g_x;
  real_T c11_h_x;
  real_T c11_i_x;
  real_T c11_j_x;
  real_T c11_k_x;
  real_T c11_l_x;
  real_T c11_m_x[4];
  int32_T c11_k;
  int32_T c11_b_k;
  int32_T c11_i179;
  real_T c11_A;
  real_T c11_n_x;
  real_T c11_o_x;
  real_T c11_p_x;
  real_T c11_y;
  int32_T c11_i180;
  real_T c11_dv17[9];
  int32_T c11_i181;
  real_T c11_dv18[9];
  int32_T c11_i182;
  int32_T c11_i183;
  static real_T c11_b[9] = { 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, -0.0, 0.0, 1.0 };

  real_T c11_dv19[9];
  int32_T c11_i184;
  int32_T c11_i185;
  real_T c11_a[9];
  int32_T c11_i186;
  real_T c11_b_b[9];
  int32_T c11_i187;
  int32_T c11_i188;
  int32_T c11_i189;
  real_T c11_C[9];
  int32_T c11_i190;
  int32_T c11_i191;
  int32_T c11_i192;
  int32_T c11_i193;
  int32_T c11_i194;
  int32_T c11_i195;
  int32_T c11_i196;
  int32_T c11_i197;
  int32_T c11_i198;
  int32_T c11_i199;
  int32_T c11_i200;
  int32_T c11_i201;
  int32_T c11_i202;
  int32_T c11_i203;
  int32_T c11_i204;
  int32_T c11_i205;
  int32_T c11_i206;
  int32_T c11_i207;
  int32_T c11_i208;
  int32_T c11_i209;
  int32_T c11_i210;
  int32_T c11_i211;
  int32_T c11_i212;
  int32_T c11_i213;
  int32_T c11_i214;
  int32_T c11_i215;
  int32_T c11_i216;
  int32_T c11_i217;
  int32_T c11_i218;
  int32_T c11_i219;
  int32_T c11_i220;
  int32_T c11_i221;
  int32_T c11_i222;
  int32_T c11_i223;
  int32_T c11_i224;
  int32_T c11_i225;
  int32_T c11_i226;
  int32_T c11_i227;
  int32_T c11_i228;
  int32_T c11_i229;
  int32_T c11_i230;
  int32_T c11_i231;
  int32_T c11_i232;
  int32_T c11_i233;
  int32_T c11_i234;
  int32_T c11_i235;
  int32_T c11_i236;
  int32_T c11_i237;
  real_T c11_c_b[3];
  int32_T c11_i238;
  real_T c11_b_y[3];
  int32_T c11_i239;
  int32_T c11_i240;
  int32_T c11_i241;
  int32_T c11_i242;
  int32_T c11_i243;
  int32_T c11_i244;
  int32_T c11_i245;
  int32_T c11_i246;
  int32_T c11_i247;
  int32_T c11_i248;
  int32_T c11_i249;
  int32_T c11_i250;
  int32_T c11_i251;
  int32_T c11_i252;
  int32_T c11_i253;
  int32_T c11_i254;
  int32_T c11_i255;
  int32_T c11_i256;
  int32_T c11_i257;
  int32_T c11_i258;
  int32_T c11_i259;
  int32_T c11_i260;
  int32_T c11_i261;
  int32_T c11_i262;
  int32_T c11_i263;
  int32_T c11_i264;
  int32_T c11_i265;
  int32_T c11_i266;
  int32_T c11_i267;
  int32_T c11_i268;
  int32_T c11_i269;
  int32_T c11_i270;
  int32_T c11_i271;
  int32_T c11_i272;
  int32_T c11_i273;
  int32_T c11_i274;
  int32_T c11_i275;
  int32_T c11_i276;
  int32_T c11_i277;
  int32_T c11_i278;
  int32_T c11_i279;
  _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 103U, 103U, c11_f_debug_family_names,
    c11_debug_family_var_map);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_RHAA, 0U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_RHFE, 1U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_RKFE, 2U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_R_trunk_0_1_1, 3U,
    c11_c_sf_marshallOut, c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_R_trunk_0_1_2, 4U,
    c11_c_sf_marshallOut, c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_R_trunk_0_1_3, 5U,
    c11_c_sf_marshallOut, c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_R_trunk_0_2_1, 6U,
    c11_c_sf_marshallOut, c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_R_trunk_0_2_2, 7U,
    c11_c_sf_marshallOut, c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_R_trunk_0_2_3, 8U,
    c11_c_sf_marshallOut, c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_R_trunk_0_3_1, 9U,
    c11_c_sf_marshallOut, c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_R_trunk_0_3_2, 10U,
    c11_c_sf_marshallOut, c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_R_trunk_0_3_3, 11U,
    c11_c_sf_marshallOut, c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_wPelvis, 12U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_dxHAA2HEE, 13U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_dyHAA2HEE, 14U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_dzHAA2HEE, 15U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_dxHEE2HFE, 16U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_dyHEE2HFE, 17U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_dzHEE2HFE, 18U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_lThigh, 19U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_lShank, 20U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_dxFoot, 21U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_hFoot, 22U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_lFoot, 23U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t2, 24U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t3, 25U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t4, 26U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t9, 27U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t5, 28U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t6, 29U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t7, 30U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t8, 31U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t10, 32U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t11, 33U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t12, 34U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t13, 35U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t14, 36U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t15, 37U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t16, 38U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t17, 39U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t18, 40U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t19, 41U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t20, 42U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t21, 43U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t22, 44U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t24, 45U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t23, 46U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t25, 47U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t26, 48U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t27, 49U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t28, 50U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t29, 51U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t34, 52U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t30, 53U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t31, 54U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t32, 55U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t33, 56U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t35, 57U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t36, 58U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t37, 59U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t38, 60U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t39, 61U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t40, 62U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t41, 63U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t42, 64U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t43, 65U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t45, 66U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t44, 67U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t46, 68U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t47, 69U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t48, 70U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_t49, 71U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_s_6, 72U, c11_d_sf_marshallOut,
    c11_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_s_5_6_5, 73U, c11_d_sf_marshallOut,
    c11_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_s_4_5_4, 74U, c11_d_sf_marshallOut,
    c11_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_s_3_4_3, 75U, c11_d_sf_marshallOut,
    c11_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_s_2_3_2, 76U, c11_d_sf_marshallOut,
    c11_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_s_1_2_1, 77U, c11_d_sf_marshallOut,
    c11_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_s_1t_1_1, 78U, c11_d_sf_marshallOut,
    c11_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_s_1h_1t_1, 79U, c11_d_sf_marshallOut,
    c11_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_R_5_0, 80U, c11_f_sf_marshallOut,
    c11_f_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_R_1_2, 81U, c11_f_sf_marshallOut,
    c11_f_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_R_2_3, 82U, c11_f_sf_marshallOut,
    c11_f_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML(c11_R_3_4, 83U, c11_f_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_R_4_5, 84U, c11_f_sf_marshallOut,
    c11_f_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_R_4_0, 85U, c11_f_sf_marshallOut,
    c11_f_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_R_3_0, 86U, c11_f_sf_marshallOut,
    c11_f_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_R_2_0, 87U, c11_f_sf_marshallOut,
    c11_f_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_R_1_0, 88U, c11_f_sf_marshallOut,
    c11_f_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_s_5, 89U, c11_d_sf_marshallOut,
    c11_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_s_4, 90U, c11_d_sf_marshallOut,
    c11_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_s_3, 91U, c11_d_sf_marshallOut,
    c11_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_s_2, 92U, c11_d_sf_marshallOut,
    c11_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_s_1, 93U, c11_d_sf_marshallOut,
    c11_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_s_1t, 94U, c11_d_sf_marshallOut,
    c11_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_s_1h, 95U, c11_d_sf_marshallOut,
    c11_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_nargin, 96U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c11_nargout, 97U, c11_c_sf_marshallOut,
    c11_c_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_swjointangles, 98U,
    c11_d_sf_marshallOut, c11_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_Rtrunk, 99U, c11_f_sf_marshallOut,
    c11_f_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_SegmentLengths, 100U,
    c11_e_sf_marshallOut, c11_g_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_xz, 101U, c11_b_sf_marshallOut,
    c11_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c11_J, 102U, c11_h_sf_marshallOut,
    c11_e_sf_marshallIn);
  CV_EML_FCN(0, 1);
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 30);
  c11_RHAA = c11_swjointangles[0];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 31);
  c11_RHFE = c11_swjointangles[1];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 32);
  c11_RKFE = c11_swjointangles[2];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 34);
  c11_R_trunk_0_1_1 = c11_Rtrunk[0];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 35);
  c11_R_trunk_0_1_2 = c11_Rtrunk[3];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 36);
  c11_R_trunk_0_1_3 = c11_Rtrunk[3];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 37);
  c11_R_trunk_0_2_1 = c11_Rtrunk[1];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 38);
  c11_R_trunk_0_2_2 = c11_Rtrunk[4];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 39);
  c11_R_trunk_0_2_3 = c11_Rtrunk[7];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 40);
  c11_R_trunk_0_3_1 = c11_Rtrunk[2];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 41);
  c11_R_trunk_0_3_2 = c11_Rtrunk[5];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 42);
  c11_R_trunk_0_3_3 = c11_Rtrunk[8];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 45);
  c11_wPelvis = c11_SegmentLengths[1];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 46);
  c11_dxHAA2HEE = c11_SegmentLengths[2];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 47);
  c11_dyHAA2HEE = c11_SegmentLengths[3];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 48);
  c11_dzHAA2HEE = c11_SegmentLengths[4];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 49);
  c11_dxHEE2HFE = c11_SegmentLengths[5];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 50);
  c11_dyHEE2HFE = c11_SegmentLengths[6];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 51);
  c11_dzHEE2HFE = c11_SegmentLengths[7];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 52);
  c11_lThigh = c11_SegmentLengths[8];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 53);
  c11_lShank = c11_SegmentLengths[9];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 54);
  c11_dxFoot = c11_SegmentLengths[10];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 55);
  c11_hFoot = c11_SegmentLengths[11];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 56);
  c11_lFoot = c11_SegmentLengths[12];
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 59);
  c11_x = c11_RHAA;
  c11_t2 = c11_x;
  c11_b_x = c11_t2;
  c11_t2 = c11_b_x;
  c11_t2 = muDoubleScalarCos(c11_t2);
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 60);
  c11_t3 = c11_R_trunk_0_1_3 * c11_t2;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 61);
  c11_c_x = c11_RHAA;
  c11_t4 = c11_c_x;
  c11_d_x = c11_t4;
  c11_t4 = c11_d_x;
  c11_t4 = muDoubleScalarSin(c11_t4);
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 62);
  c11_t9 = c11_R_trunk_0_1_2 * c11_t4;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 63);
  c11_t5 = c11_t3 - c11_t9;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 64);
  c11_t6 = c11_R_trunk_0_1_2 * c11_t2;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 65);
  c11_t7 = c11_R_trunk_0_1_3 * c11_t4;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 66);
  c11_t8 = c11_t6 + c11_t7;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 67);
  c11_e_x = c11_RHFE;
  c11_t10 = c11_e_x;
  c11_f_x = c11_t10;
  c11_t10 = c11_f_x;
  c11_t10 = muDoubleScalarCos(c11_t10);
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 68);
  c11_g_x = c11_RKFE;
  c11_t11 = c11_g_x;
  c11_h_x = c11_t11;
  c11_t11 = c11_h_x;
  c11_t11 = muDoubleScalarCos(c11_t11);
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 69);
  c11_i_x = c11_RHFE;
  c11_t12 = c11_i_x;
  c11_j_x = c11_t12;
  c11_t12 = c11_j_x;
  c11_t12 = muDoubleScalarSin(c11_t12);
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 70);
  c11_k_x = c11_RKFE;
  c11_t13 = c11_k_x;
  c11_l_x = c11_t13;
  c11_t13 = c11_l_x;
  c11_t13 = muDoubleScalarSin(c11_t13);
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 71);
  c11_t14 = c11_t5 * c11_t10 * c11_t13;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 72);
  c11_t15 = c11_t5 * c11_t11 * c11_t12;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 73);
  c11_t16 = c11_t14 + c11_t15;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 74);
  c11_t17 = c11_t5 * c11_t10 * c11_t11;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 75);
  c11_t18 = c11_t17 - c11_t5 * c11_t12 * c11_t13;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 76);
  c11_t19 = c11_t8 * c11_t12;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 77);
  c11_t20 = c11_R_trunk_0_1_1 * c11_t10;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 78);
  c11_t21 = c11_t19 + c11_t20;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 79);
  c11_t22 = c11_R_trunk_0_1_1 * c11_t12;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 80);
  c11_t24 = c11_t8 * c11_t10;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 81);
  c11_t23 = c11_t22 - c11_t24;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 82);
  c11_t25 = c11_t11 * c11_t23;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 83);
  c11_t26 = c11_t13 * c11_t21;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 84);
  c11_t27 = c11_t11 * c11_t21;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 85);
  c11_t28 = c11_t27 - c11_t13 * c11_t23;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 86);
  c11_t29 = c11_R_trunk_0_3_3 * c11_t2;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 87);
  c11_t34 = c11_R_trunk_0_3_2 * c11_t4;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 88);
  c11_t30 = c11_t29 - c11_t34;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 89);
  c11_t31 = c11_R_trunk_0_3_2 * c11_t2;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 90);
  c11_t32 = c11_R_trunk_0_3_3 * c11_t4;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 91);
  c11_t33 = c11_t31 + c11_t32;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 92);
  c11_t35 = c11_t10 * c11_t13 * c11_t30;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 93);
  c11_t36 = c11_t11 * c11_t12 * c11_t30;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 94);
  c11_t37 = c11_t35 + c11_t36;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 95);
  c11_t38 = c11_t10 * c11_t11 * c11_t30;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 96);
  c11_t39 = c11_t38 - c11_t12 * c11_t13 * c11_t30;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 97);
  c11_t40 = c11_t12 * c11_t33;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 98);
  c11_t41 = c11_R_trunk_0_3_1 * c11_t10;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 99);
  c11_t42 = c11_t40 + c11_t41;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 100);
  c11_t43 = c11_R_trunk_0_3_1 * c11_t12;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 101);
  c11_t45 = c11_t10 * c11_t33;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 102);
  c11_t44 = c11_t43 - c11_t45;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 103);
  c11_t46 = c11_t11 * c11_t44;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 104);
  c11_t47 = c11_t13 * c11_t42;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 105);
  c11_t48 = c11_t11 * c11_t42;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 106);
  c11_t49 = c11_t48 - c11_t13 * c11_t44;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 107);
  c11_m_x[0] = (((((((c11_dxFoot * c11_t16 + c11_dyHAA2HEE * c11_t5) +
                     c11_dyHEE2HFE * c11_t5) - c11_dzHAA2HEE * c11_t8) -
                   c11_dzHEE2HFE * c11_t8) - c11_hFoot * c11_t18) - c11_lFoot *
                 c11_t16) - c11_lShank * c11_t18) - c11_lThigh * c11_t5 *
    c11_t10;
  c11_m_x[1] = (((((((c11_dxFoot * c11_t37 + c11_dyHAA2HEE * c11_t30) +
                     c11_dyHEE2HFE * c11_t30) - c11_dzHAA2HEE * c11_t33) -
                   c11_dzHEE2HFE * c11_t33) - c11_hFoot * c11_t39) - c11_lFoot *
                 c11_t37) - c11_lShank * c11_t39) - c11_lThigh * c11_t10 *
    c11_t30;
  c11_m_x[2] = (((-c11_dxFoot * (c11_t25 + c11_t26) + c11_lFoot * (c11_t25 +
    c11_t26)) + c11_hFoot * c11_t28) + c11_lShank * c11_t28) + c11_lThigh *
    c11_t21;
  c11_m_x[3] = (((-c11_dxFoot * (c11_t46 + c11_t47) + c11_lFoot * (c11_t46 +
    c11_t47)) + c11_hFoot * c11_t49) + c11_lShank * c11_t49) + c11_lThigh *
    c11_t42;
  for (c11_k = 1; c11_k < 5; c11_k++) {
    c11_b_k = c11_k;
    c11_J[_SFD_EML_ARRAY_BOUNDS_CHECK("", (int32_T)_SFD_INTEGER_CHECK("",
      (real_T)c11_b_k), 1, 4, 1, 0) - 1] = c11_m_x[_SFD_EML_ARRAY_BOUNDS_CHECK(
      "", (int32_T)_SFD_INTEGER_CHECK("", (real_T)c11_b_k), 1, 4, 1, 0) - 1];
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 109);
  for (c11_i179 = 0; c11_i179 < 3; c11_i179++) {
    c11_s_6[c11_i179] = 0.0;
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 110);
  c11_A = c11_wPelvis;
  c11_n_x = c11_A;
  c11_o_x = c11_n_x;
  c11_p_x = c11_o_x;
  c11_y = c11_p_x / 2.0;
  c11_s_5_6_5[0] = 0.0;
  c11_s_5_6_5[1] = 0.0;
  c11_s_5_6_5[2] = c11_y;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 111);
  c11_s_4_5_4[0] = c11_dxHAA2HEE;
  c11_s_4_5_4[1] = c11_dyHAA2HEE;
  c11_s_4_5_4[2] = c11_dzHAA2HEE;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 112);
  c11_s_3_4_3[0] = c11_dxHEE2HFE;
  c11_s_3_4_3[1] = c11_dyHEE2HFE;
  c11_s_3_4_3[2] = c11_dzHEE2HFE;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 113);
  c11_s_2_3_2[0] = 0.0;
  c11_s_2_3_2[1] = -c11_lThigh;
  c11_s_2_3_2[2] = 0.0;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 114);
  c11_s_1_2_1[0] = 0.0;
  c11_s_1_2_1[1] = -c11_lShank;
  c11_s_1_2_1[2] = 0.0;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 115);
  c11_s_1t_1_1[0] = c11_dxFoot;
  c11_s_1t_1_1[1] = -c11_hFoot;
  c11_s_1t_1_1[2] = 0.0;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 116);
  c11_s_1h_1t_1[0] = -c11_lFoot;
  c11_s_1h_1t_1[1] = 0.0;
  c11_s_1h_1t_1[2] = 0.0;
  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 118);
  for (c11_i180 = 0; c11_i180 < 9; c11_i180++) {
    c11_R_5_0[c11_i180] = c11_Rtrunk[c11_i180];
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 120);
  c11_Rz(chartInstance, -c11_RKFE, c11_dv17);
  for (c11_i181 = 0; c11_i181 < 9; c11_i181++) {
    c11_R_1_2[c11_i181] = c11_dv17[c11_i181];
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 121);
  c11_Rz(chartInstance, -c11_RHFE, c11_dv18);
  for (c11_i182 = 0; c11_i182 < 9; c11_i182++) {
    c11_R_2_3[c11_i182] = c11_dv18[c11_i182];
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 122);
  for (c11_i183 = 0; c11_i183 < 9; c11_i183++) {
    c11_R_3_4[c11_i183] = c11_b[c11_i183];
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 123);
  c11_Rx(chartInstance, -c11_RHAA, c11_dv19);
  for (c11_i184 = 0; c11_i184 < 9; c11_i184++) {
    c11_R_4_5[c11_i184] = c11_dv19[c11_i184];
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 125);
  for (c11_i185 = 0; c11_i185 < 9; c11_i185++) {
    c11_a[c11_i185] = c11_R_5_0[c11_i185];
  }

  for (c11_i186 = 0; c11_i186 < 9; c11_i186++) {
    c11_b_b[c11_i186] = c11_R_4_5[c11_i186];
  }

  c11_eml_scalar_eg(chartInstance);
  c11_eml_scalar_eg(chartInstance);
  for (c11_i187 = 0; c11_i187 < 9; c11_i187++) {
    c11_R_4_0[c11_i187] = 0.0;
  }

  for (c11_i188 = 0; c11_i188 < 9; c11_i188++) {
    c11_R_4_0[c11_i188] = 0.0;
  }

  for (c11_i189 = 0; c11_i189 < 9; c11_i189++) {
    c11_C[c11_i189] = c11_R_4_0[c11_i189];
  }

  for (c11_i190 = 0; c11_i190 < 9; c11_i190++) {
    c11_R_4_0[c11_i190] = c11_C[c11_i190];
  }

  c11_threshold(chartInstance);
  for (c11_i191 = 0; c11_i191 < 9; c11_i191++) {
    c11_C[c11_i191] = c11_R_4_0[c11_i191];
  }

  for (c11_i192 = 0; c11_i192 < 9; c11_i192++) {
    c11_R_4_0[c11_i192] = c11_C[c11_i192];
  }

  for (c11_i193 = 0; c11_i193 < 3; c11_i193++) {
    c11_i194 = 0;
    for (c11_i195 = 0; c11_i195 < 3; c11_i195++) {
      c11_R_4_0[c11_i194 + c11_i193] = 0.0;
      c11_i196 = 0;
      for (c11_i197 = 0; c11_i197 < 3; c11_i197++) {
        c11_R_4_0[c11_i194 + c11_i193] += c11_a[c11_i196 + c11_i193] *
          c11_b_b[c11_i197 + c11_i194];
        c11_i196 += 3;
      }

      c11_i194 += 3;
    }
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 126);
  for (c11_i198 = 0; c11_i198 < 9; c11_i198++) {
    c11_a[c11_i198] = c11_R_4_0[c11_i198];
  }

  c11_eml_scalar_eg(chartInstance);
  c11_eml_scalar_eg(chartInstance);
  for (c11_i199 = 0; c11_i199 < 9; c11_i199++) {
    c11_R_3_0[c11_i199] = 0.0;
  }

  for (c11_i200 = 0; c11_i200 < 9; c11_i200++) {
    c11_R_3_0[c11_i200] = 0.0;
  }

  for (c11_i201 = 0; c11_i201 < 9; c11_i201++) {
    c11_C[c11_i201] = c11_R_3_0[c11_i201];
  }

  for (c11_i202 = 0; c11_i202 < 9; c11_i202++) {
    c11_R_3_0[c11_i202] = c11_C[c11_i202];
  }

  c11_threshold(chartInstance);
  for (c11_i203 = 0; c11_i203 < 9; c11_i203++) {
    c11_C[c11_i203] = c11_R_3_0[c11_i203];
  }

  for (c11_i204 = 0; c11_i204 < 9; c11_i204++) {
    c11_R_3_0[c11_i204] = c11_C[c11_i204];
  }

  for (c11_i205 = 0; c11_i205 < 3; c11_i205++) {
    c11_i206 = 0;
    for (c11_i207 = 0; c11_i207 < 3; c11_i207++) {
      c11_R_3_0[c11_i206 + c11_i205] = 0.0;
      c11_i208 = 0;
      for (c11_i209 = 0; c11_i209 < 3; c11_i209++) {
        c11_R_3_0[c11_i206 + c11_i205] += c11_a[c11_i208 + c11_i205] *
          c11_b[c11_i209 + c11_i206];
        c11_i208 += 3;
      }

      c11_i206 += 3;
    }
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, MAX_int8_T);
  for (c11_i210 = 0; c11_i210 < 9; c11_i210++) {
    c11_a[c11_i210] = c11_R_3_0[c11_i210];
  }

  for (c11_i211 = 0; c11_i211 < 9; c11_i211++) {
    c11_b_b[c11_i211] = c11_R_2_3[c11_i211];
  }

  c11_eml_scalar_eg(chartInstance);
  c11_eml_scalar_eg(chartInstance);
  for (c11_i212 = 0; c11_i212 < 9; c11_i212++) {
    c11_R_2_0[c11_i212] = 0.0;
  }

  for (c11_i213 = 0; c11_i213 < 9; c11_i213++) {
    c11_R_2_0[c11_i213] = 0.0;
  }

  for (c11_i214 = 0; c11_i214 < 9; c11_i214++) {
    c11_C[c11_i214] = c11_R_2_0[c11_i214];
  }

  for (c11_i215 = 0; c11_i215 < 9; c11_i215++) {
    c11_R_2_0[c11_i215] = c11_C[c11_i215];
  }

  c11_threshold(chartInstance);
  for (c11_i216 = 0; c11_i216 < 9; c11_i216++) {
    c11_C[c11_i216] = c11_R_2_0[c11_i216];
  }

  for (c11_i217 = 0; c11_i217 < 9; c11_i217++) {
    c11_R_2_0[c11_i217] = c11_C[c11_i217];
  }

  for (c11_i218 = 0; c11_i218 < 3; c11_i218++) {
    c11_i219 = 0;
    for (c11_i220 = 0; c11_i220 < 3; c11_i220++) {
      c11_R_2_0[c11_i219 + c11_i218] = 0.0;
      c11_i221 = 0;
      for (c11_i222 = 0; c11_i222 < 3; c11_i222++) {
        c11_R_2_0[c11_i219 + c11_i218] += c11_a[c11_i221 + c11_i218] *
          c11_b_b[c11_i222 + c11_i219];
        c11_i221 += 3;
      }

      c11_i219 += 3;
    }
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 128U);
  for (c11_i223 = 0; c11_i223 < 9; c11_i223++) {
    c11_a[c11_i223] = c11_R_2_0[c11_i223];
  }

  for (c11_i224 = 0; c11_i224 < 9; c11_i224++) {
    c11_b_b[c11_i224] = c11_R_1_2[c11_i224];
  }

  c11_eml_scalar_eg(chartInstance);
  c11_eml_scalar_eg(chartInstance);
  for (c11_i225 = 0; c11_i225 < 9; c11_i225++) {
    c11_R_1_0[c11_i225] = 0.0;
  }

  for (c11_i226 = 0; c11_i226 < 9; c11_i226++) {
    c11_R_1_0[c11_i226] = 0.0;
  }

  for (c11_i227 = 0; c11_i227 < 9; c11_i227++) {
    c11_C[c11_i227] = c11_R_1_0[c11_i227];
  }

  for (c11_i228 = 0; c11_i228 < 9; c11_i228++) {
    c11_R_1_0[c11_i228] = c11_C[c11_i228];
  }

  c11_threshold(chartInstance);
  for (c11_i229 = 0; c11_i229 < 9; c11_i229++) {
    c11_C[c11_i229] = c11_R_1_0[c11_i229];
  }

  for (c11_i230 = 0; c11_i230 < 9; c11_i230++) {
    c11_R_1_0[c11_i230] = c11_C[c11_i230];
  }

  for (c11_i231 = 0; c11_i231 < 3; c11_i231++) {
    c11_i232 = 0;
    for (c11_i233 = 0; c11_i233 < 3; c11_i233++) {
      c11_R_1_0[c11_i232 + c11_i231] = 0.0;
      c11_i234 = 0;
      for (c11_i235 = 0; c11_i235 < 3; c11_i235++) {
        c11_R_1_0[c11_i232 + c11_i231] += c11_a[c11_i234 + c11_i231] *
          c11_b_b[c11_i235 + c11_i232];
        c11_i234 += 3;
      }

      c11_i232 += 3;
    }
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 130U);
  for (c11_i236 = 0; c11_i236 < 9; c11_i236++) {
    c11_a[c11_i236] = c11_R_5_0[c11_i236];
  }

  for (c11_i237 = 0; c11_i237 < 3; c11_i237++) {
    c11_c_b[c11_i237] = c11_s_5_6_5[c11_i237];
  }

  c11_b_eml_scalar_eg(chartInstance);
  c11_b_eml_scalar_eg(chartInstance);
  c11_threshold(chartInstance);
  for (c11_i238 = 0; c11_i238 < 3; c11_i238++) {
    c11_b_y[c11_i238] = 0.0;
    c11_i239 = 0;
    for (c11_i240 = 0; c11_i240 < 3; c11_i240++) {
      c11_b_y[c11_i238] += c11_a[c11_i239 + c11_i238] * c11_c_b[c11_i240];
      c11_i239 += 3;
    }
  }

  for (c11_i241 = 0; c11_i241 < 3; c11_i241++) {
    c11_s_5[c11_i241] = c11_s_6[c11_i241] + c11_b_y[c11_i241];
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 131U);
  for (c11_i242 = 0; c11_i242 < 9; c11_i242++) {
    c11_a[c11_i242] = c11_R_4_0[c11_i242];
  }

  for (c11_i243 = 0; c11_i243 < 3; c11_i243++) {
    c11_c_b[c11_i243] = c11_s_4_5_4[c11_i243];
  }

  c11_b_eml_scalar_eg(chartInstance);
  c11_b_eml_scalar_eg(chartInstance);
  c11_threshold(chartInstance);
  for (c11_i244 = 0; c11_i244 < 3; c11_i244++) {
    c11_b_y[c11_i244] = 0.0;
    c11_i245 = 0;
    for (c11_i246 = 0; c11_i246 < 3; c11_i246++) {
      c11_b_y[c11_i244] += c11_a[c11_i245 + c11_i244] * c11_c_b[c11_i246];
      c11_i245 += 3;
    }
  }

  for (c11_i247 = 0; c11_i247 < 3; c11_i247++) {
    c11_s_4[c11_i247] = c11_s_5[c11_i247] + c11_b_y[c11_i247];
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 132U);
  for (c11_i248 = 0; c11_i248 < 9; c11_i248++) {
    c11_a[c11_i248] = c11_R_3_0[c11_i248];
  }

  for (c11_i249 = 0; c11_i249 < 3; c11_i249++) {
    c11_c_b[c11_i249] = c11_s_3_4_3[c11_i249];
  }

  c11_b_eml_scalar_eg(chartInstance);
  c11_b_eml_scalar_eg(chartInstance);
  c11_threshold(chartInstance);
  for (c11_i250 = 0; c11_i250 < 3; c11_i250++) {
    c11_b_y[c11_i250] = 0.0;
    c11_i251 = 0;
    for (c11_i252 = 0; c11_i252 < 3; c11_i252++) {
      c11_b_y[c11_i250] += c11_a[c11_i251 + c11_i250] * c11_c_b[c11_i252];
      c11_i251 += 3;
    }
  }

  for (c11_i253 = 0; c11_i253 < 3; c11_i253++) {
    c11_s_3[c11_i253] = c11_s_4[c11_i253] + c11_b_y[c11_i253];
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 133U);
  for (c11_i254 = 0; c11_i254 < 9; c11_i254++) {
    c11_a[c11_i254] = c11_R_2_0[c11_i254];
  }

  for (c11_i255 = 0; c11_i255 < 3; c11_i255++) {
    c11_c_b[c11_i255] = c11_s_2_3_2[c11_i255];
  }

  c11_b_eml_scalar_eg(chartInstance);
  c11_b_eml_scalar_eg(chartInstance);
  c11_threshold(chartInstance);
  for (c11_i256 = 0; c11_i256 < 3; c11_i256++) {
    c11_b_y[c11_i256] = 0.0;
    c11_i257 = 0;
    for (c11_i258 = 0; c11_i258 < 3; c11_i258++) {
      c11_b_y[c11_i256] += c11_a[c11_i257 + c11_i256] * c11_c_b[c11_i258];
      c11_i257 += 3;
    }
  }

  for (c11_i259 = 0; c11_i259 < 3; c11_i259++) {
    c11_s_2[c11_i259] = c11_s_3[c11_i259] + c11_b_y[c11_i259];
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 134U);
  for (c11_i260 = 0; c11_i260 < 9; c11_i260++) {
    c11_a[c11_i260] = c11_R_1_0[c11_i260];
  }

  for (c11_i261 = 0; c11_i261 < 3; c11_i261++) {
    c11_c_b[c11_i261] = c11_s_1_2_1[c11_i261];
  }

  c11_b_eml_scalar_eg(chartInstance);
  c11_b_eml_scalar_eg(chartInstance);
  c11_threshold(chartInstance);
  for (c11_i262 = 0; c11_i262 < 3; c11_i262++) {
    c11_b_y[c11_i262] = 0.0;
    c11_i263 = 0;
    for (c11_i264 = 0; c11_i264 < 3; c11_i264++) {
      c11_b_y[c11_i262] += c11_a[c11_i263 + c11_i262] * c11_c_b[c11_i264];
      c11_i263 += 3;
    }
  }

  for (c11_i265 = 0; c11_i265 < 3; c11_i265++) {
    c11_s_1[c11_i265] = c11_s_2[c11_i265] + c11_b_y[c11_i265];
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 135U);
  for (c11_i266 = 0; c11_i266 < 9; c11_i266++) {
    c11_a[c11_i266] = c11_R_1_0[c11_i266];
  }

  for (c11_i267 = 0; c11_i267 < 3; c11_i267++) {
    c11_c_b[c11_i267] = c11_s_1t_1_1[c11_i267];
  }

  c11_b_eml_scalar_eg(chartInstance);
  c11_b_eml_scalar_eg(chartInstance);
  c11_threshold(chartInstance);
  for (c11_i268 = 0; c11_i268 < 3; c11_i268++) {
    c11_b_y[c11_i268] = 0.0;
    c11_i269 = 0;
    for (c11_i270 = 0; c11_i270 < 3; c11_i270++) {
      c11_b_y[c11_i268] += c11_a[c11_i269 + c11_i268] * c11_c_b[c11_i270];
      c11_i269 += 3;
    }
  }

  for (c11_i271 = 0; c11_i271 < 3; c11_i271++) {
    c11_s_1t[c11_i271] = c11_s_1[c11_i271] + c11_b_y[c11_i271];
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 136U);
  for (c11_i272 = 0; c11_i272 < 9; c11_i272++) {
    c11_a[c11_i272] = c11_R_1_0[c11_i272];
  }

  for (c11_i273 = 0; c11_i273 < 3; c11_i273++) {
    c11_c_b[c11_i273] = c11_s_1h_1t_1[c11_i273];
  }

  c11_b_eml_scalar_eg(chartInstance);
  c11_b_eml_scalar_eg(chartInstance);
  c11_threshold(chartInstance);
  for (c11_i274 = 0; c11_i274 < 3; c11_i274++) {
    c11_b_y[c11_i274] = 0.0;
    c11_i275 = 0;
    for (c11_i276 = 0; c11_i276 < 3; c11_i276++) {
      c11_b_y[c11_i274] += c11_a[c11_i275 + c11_i274] * c11_c_b[c11_i276];
      c11_i275 += 3;
    }
  }

  for (c11_i277 = 0; c11_i277 < 3; c11_i277++) {
    c11_s_1h[c11_i277] = c11_s_1t[c11_i277] + c11_b_y[c11_i277];
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, 138U);
  c11_i278 = 0;
  for (c11_i279 = 0; c11_i279 < 2; c11_i279++) {
    c11_xz[c11_i279] = c11_s_1h[c11_i278];
    c11_i278 += 2;
  }

  _SFD_EML_CALL(0U, chartInstance->c11_sfEvent, -138);
  _SFD_SYMBOL_SCOPE_POP();
}

static void c11_eml_warning(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance)
{
  int32_T c11_i280;
  static char_T c11_varargin_1[27] = { 'C', 'o', 'd', 'e', 'r', ':', 'M', 'A',
    'T', 'L', 'A', 'B', ':', 's', 'i', 'n', 'g', 'u', 'l', 'a', 'r', 'M', 'a',
    't', 'r', 'i', 'x' };

  char_T c11_u[27];
  const mxArray *c11_y = NULL;
  (void)chartInstance;
  for (c11_i280 = 0; c11_i280 < 27; c11_i280++) {
    c11_u[c11_i280] = c11_varargin_1[c11_i280];
  }

  c11_y = NULL;
  sf_mex_assign(&c11_y, sf_mex_create("y", c11_u, 10, 0U, 1U, 0U, 2, 1, 27),
                false);
  sf_mex_call_debug(sfGlobalDebugInstanceStruct, "warning", 0U, 1U, 14,
                    sf_mex_call_debug(sfGlobalDebugInstanceStruct, "message", 1U,
    1U, 14, c11_y));
}

static const mxArray *c11_i_sf_marshallOut(void *chartInstanceVoid, void
  *c11_inData)
{
  const mxArray *c11_mxArrayOutData = NULL;
  int32_T c11_u;
  const mxArray *c11_y = NULL;
  SFc11_FootPlacementLibraryInstanceStruct *chartInstance;
  chartInstance = (SFc11_FootPlacementLibraryInstanceStruct *)chartInstanceVoid;
  c11_mxArrayOutData = NULL;
  c11_u = *(int32_T *)c11_inData;
  c11_y = NULL;
  sf_mex_assign(&c11_y, sf_mex_create("y", &c11_u, 6, 0U, 0U, 0U, 0), false);
  sf_mex_assign(&c11_mxArrayOutData, c11_y, false);
  return c11_mxArrayOutData;
}

static int32_T c11_l_emlrt_marshallIn(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance, const mxArray *c11_u, const emlrtMsgIdentifier *c11_parentId)
{
  int32_T c11_y;
  int32_T c11_i281;
  (void)chartInstance;
  sf_mex_import(c11_parentId, sf_mex_dup(c11_u), &c11_i281, 1, 6, 0U, 0, 0U, 0);
  c11_y = c11_i281;
  sf_mex_destroy(&c11_u);
  return c11_y;
}

static void c11_h_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c11_mxArrayInData, const char_T *c11_varName, void *c11_outData)
{
  const mxArray *c11_b_sfEvent;
  const char_T *c11_identifier;
  emlrtMsgIdentifier c11_thisId;
  int32_T c11_y;
  SFc11_FootPlacementLibraryInstanceStruct *chartInstance;
  chartInstance = (SFc11_FootPlacementLibraryInstanceStruct *)chartInstanceVoid;
  c11_b_sfEvent = sf_mex_dup(c11_mxArrayInData);
  c11_identifier = c11_varName;
  c11_thisId.fIdentifier = c11_identifier;
  c11_thisId.fParent = NULL;
  c11_y = c11_l_emlrt_marshallIn(chartInstance, sf_mex_dup(c11_b_sfEvent),
    &c11_thisId);
  sf_mex_destroy(&c11_b_sfEvent);
  *(int32_T *)c11_outData = c11_y;
  sf_mex_destroy(&c11_mxArrayInData);
}

static uint8_T c11_m_emlrt_marshallIn(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance, const mxArray *c11_b_is_active_c11_FootPlacementLibrary, const
  char_T *c11_identifier)
{
  uint8_T c11_y;
  emlrtMsgIdentifier c11_thisId;
  c11_thisId.fIdentifier = c11_identifier;
  c11_thisId.fParent = NULL;
  c11_y = c11_n_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c11_b_is_active_c11_FootPlacementLibrary), &c11_thisId);
  sf_mex_destroy(&c11_b_is_active_c11_FootPlacementLibrary);
  return c11_y;
}

static uint8_T c11_n_emlrt_marshallIn(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance, const mxArray *c11_u, const emlrtMsgIdentifier *c11_parentId)
{
  uint8_T c11_y;
  uint8_T c11_u0;
  (void)chartInstance;
  sf_mex_import(c11_parentId, sf_mex_dup(c11_u), &c11_u0, 1, 3, 0U, 0, 0U, 0);
  c11_y = c11_u0;
  sf_mex_destroy(&c11_u);
  return c11_y;
}

static void init_dsm_address_info(SFc11_FootPlacementLibraryInstanceStruct
  *chartInstance)
{
  (void)chartInstance;
}

/* SFunction Glue Code */
#ifdef utFree
#undef utFree
#endif

#ifdef utMalloc
#undef utMalloc
#endif

#ifdef __cplusplus

extern "C" void *utMalloc(size_t size);
extern "C" void utFree(void*);

#else

extern void *utMalloc(size_t size);
extern void utFree(void*);

#endif

void sf_c11_FootPlacementLibrary_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(1005663682U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(4198804723U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(2215604571U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(915532508U);
}

mxArray *sf_c11_FootPlacementLibrary_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs", "locals" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1,1,5,
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateString("kdGO2c97bFNRhy1LQp0MhF");
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,7,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(2);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(12);
      pr[1] = (double)(1);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(3);
      pr[1] = (double)(3);
      mxSetField(mxData,3,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,3,"type",mxType);
    }

    mxSetField(mxData,3,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(13);
      pr[1] = (double)(1);
      mxSetField(mxData,4,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,4,"type",mxType);
    }

    mxSetField(mxData,4,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(3);
      pr[1] = (double)(1);
      mxSetField(mxData,5,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,5,"type",mxType);
    }

    mxSetField(mxData,5,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(3);
      pr[1] = (double)(1);
      mxSetField(mxData,6,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,6,"type",mxType);
    }

    mxSetField(mxData,6,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,3,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(3);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(2);
      pr[1] = (double)(1);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"locals",mxCreateDoubleMatrix(0,0,mxREAL));
  }

  return(mxAutoinheritanceInfo);
}

mxArray *sf_c11_FootPlacementLibrary_third_party_uses_info(void)
{
  mxArray * mxcell3p = mxCreateCellMatrix(1,0);
  return(mxcell3p);
}

mxArray *sf_c11_FootPlacementLibrary_updateBuildInfo_args_info(void)
{
  mxArray *mxBIArgs = mxCreateCellMatrix(1,0);
  return mxBIArgs;
}

static const mxArray *sf_get_sim_state_info_c11_FootPlacementLibrary(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  const char *infoEncStr[] = {
    "100 S1x5'type','srcId','name','auxInfo'{{M[1],M[8],T\"Rswjointangles\",},{M[1],M[12],T\"i\",},{M[1],M[13],T\"xz\",},{M[4],M[0],T\"q\",S'l','i','p'{{M1x2[119 120],M[0],}}},{M[8],M[0],T\"is_active_c11_FootPlacementLibrary\",}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 5, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c11_FootPlacementLibrary_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization)
{
  if (!sim_mode_is_rtw_gen(S)) {
    SFc11_FootPlacementLibraryInstanceStruct *chartInstance;
    ChartRunTimeInfo * crtInfo = (ChartRunTimeInfo *)(ssGetUserData(S));
    ChartInfoStruct * chartInfo = (ChartInfoStruct *)(crtInfo->instanceInfo);
    chartInstance = (SFc11_FootPlacementLibraryInstanceStruct *)
      chartInfo->chartInstance;
    if (ssIsFirstInitCond(S) && fullDebuggerInitialization==1) {
      /* do this only if simulation is starting */
      {
        unsigned int chartAlreadyPresent;
        chartAlreadyPresent = sf_debug_initialize_chart
          (sfGlobalDebugInstanceStruct,
           _FootPlacementLibraryMachineNumber_,
           11,
           1,
           1,
           0,
           10,
           0,
           0,
           0,
           0,
           3,
           &(chartInstance->chartNumber),
           &(chartInstance->instanceNumber),
           (void *)S);

        /* Each instance must initialize ist own list of scripts */
        init_script_number_translation(_FootPlacementLibraryMachineNumber_,
          chartInstance->chartNumber,chartInstance->instanceNumber);
        if (chartAlreadyPresent==0) {
          /* this is the first instance */
          sf_debug_set_chart_disable_implicit_casting
            (sfGlobalDebugInstanceStruct,_FootPlacementLibraryMachineNumber_,
             chartInstance->chartNumber,1);
          sf_debug_set_chart_event_thresholds(sfGlobalDebugInstanceStruct,
            _FootPlacementLibraryMachineNumber_,
            chartInstance->chartNumber,
            0,
            0,
            0);
          _SFD_SET_DATA_PROPS(0,1,1,0,"xze");
          _SFD_SET_DATA_PROPS(1,1,1,0,"KFE");
          _SFD_SET_DATA_PROPS(2,1,1,0,"jointangles");
          _SFD_SET_DATA_PROPS(3,2,0,1,"Rswjointangles");
          _SFD_SET_DATA_PROPS(4,1,1,0,"Rtrunk");
          _SFD_SET_DATA_PROPS(5,1,1,0,"SegmentLengths");
          _SFD_SET_DATA_PROPS(6,2,0,1,"i");
          _SFD_SET_DATA_PROPS(7,2,0,1,"xz");
          _SFD_SET_DATA_PROPS(8,1,1,0,"LB");
          _SFD_SET_DATA_PROPS(9,1,1,0,"UB");
          _SFD_STATE_INFO(0,0,2);
          _SFD_CH_SUBSTATE_COUNT(0);
          _SFD_CH_SUBSTATE_DECOMP(0);
        }

        _SFD_CV_INIT_CHART(0,0,0,0);

        {
          _SFD_CV_INIT_STATE(0,0,0,0,0,0,NULL,NULL);
        }

        _SFD_CV_INIT_TRANS(0,0,NULL,NULL,0,NULL);

        /* Initialization of MATLAB Function Model Coverage */
        _SFD_CV_INIT_EML(0,1,2,3,0,0,0,1,1,0,0);
        _SFD_CV_INIT_EML_FCN(0,0,"eML_blk_kernel",0,-1,580);
        _SFD_CV_INIT_EML_FCN(0,1,"fk_KFE_jacobian",580,-1,3349);
        _SFD_CV_INIT_EML_IF(0,1,0,121,134,-1,185);
        _SFD_CV_INIT_EML_IF(0,1,1,471,484,509,526);
        _SFD_CV_INIT_EML_IF(0,1,2,509,526,-1,526);
        _SFD_CV_INIT_EML_FOR(0,1,0,455,467,558);
        _SFD_CV_INIT_EML_WHILE(0,1,0,254,266,454);
        _SFD_CV_INIT_SCRIPT(0,1,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_SCRIPT_FCN(0,0,"Rz",0,-1,122);
        _SFD_CV_INIT_SCRIPT(1,1,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_SCRIPT_FCN(1,0,"Ry",0,-1,120);
        _SFD_CV_INIT_SCRIPT(2,1,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_SCRIPT_FCN(2,0,"Rx",0,-1,121);

        {
          unsigned int dimVector[1];
          dimVector[0]= 2;
          _SFD_SET_DATA_COMPILED_PROPS(0,SF_DOUBLE,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)c11_b_sf_marshallOut,(MexInFcnForType)NULL);
        }

        _SFD_SET_DATA_COMPILED_PROPS(1,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c11_c_sf_marshallOut,(MexInFcnForType)NULL);

        {
          unsigned int dimVector[1];
          dimVector[0]= 12;
          _SFD_SET_DATA_COMPILED_PROPS(2,SF_DOUBLE,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)c11_g_sf_marshallOut,(MexInFcnForType)NULL);
        }

        {
          unsigned int dimVector[1];
          dimVector[0]= 3;
          _SFD_SET_DATA_COMPILED_PROPS(3,SF_DOUBLE,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)c11_d_sf_marshallOut,(MexInFcnForType)
            c11_d_sf_marshallIn);
        }

        {
          unsigned int dimVector[2];
          dimVector[0]= 3;
          dimVector[1]= 3;
          _SFD_SET_DATA_COMPILED_PROPS(4,SF_DOUBLE,2,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)c11_f_sf_marshallOut,(MexInFcnForType)NULL);
        }

        {
          unsigned int dimVector[1];
          dimVector[0]= 13;
          _SFD_SET_DATA_COMPILED_PROPS(5,SF_DOUBLE,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)c11_e_sf_marshallOut,(MexInFcnForType)NULL);
        }

        _SFD_SET_DATA_COMPILED_PROPS(6,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c11_c_sf_marshallOut,(MexInFcnForType)
          c11_c_sf_marshallIn);

        {
          unsigned int dimVector[1];
          dimVector[0]= 2;
          _SFD_SET_DATA_COMPILED_PROPS(7,SF_DOUBLE,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)c11_b_sf_marshallOut,(MexInFcnForType)
            c11_b_sf_marshallIn);
        }

        {
          unsigned int dimVector[1];
          dimVector[0]= 3;
          _SFD_SET_DATA_COMPILED_PROPS(8,SF_DOUBLE,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)c11_d_sf_marshallOut,(MexInFcnForType)NULL);
        }

        {
          unsigned int dimVector[1];
          dimVector[0]= 3;
          _SFD_SET_DATA_COMPILED_PROPS(9,SF_DOUBLE,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)c11_d_sf_marshallOut,(MexInFcnForType)NULL);
        }

        {
          real_T *c11_KFE;
          real_T *c11_i;
          real_T (*c11_xze)[2];
          real_T (*c11_jointangles)[12];
          real_T (*c11_Rswjointangles)[3];
          real_T (*c11_Rtrunk)[9];
          real_T (*c11_SegmentLengths)[13];
          real_T (*c11_xz)[2];
          real_T (*c11_LB)[3];
          real_T (*c11_UB)[3];
          c11_UB = (real_T (*)[3])ssGetInputPortSignal(chartInstance->S, 6);
          c11_LB = (real_T (*)[3])ssGetInputPortSignal(chartInstance->S, 5);
          c11_xz = (real_T (*)[2])ssGetOutputPortSignal(chartInstance->S, 3);
          c11_i = (real_T *)ssGetOutputPortSignal(chartInstance->S, 2);
          c11_SegmentLengths = (real_T (*)[13])ssGetInputPortSignal
            (chartInstance->S, 4);
          c11_Rtrunk = (real_T (*)[9])ssGetInputPortSignal(chartInstance->S, 3);
          c11_Rswjointangles = (real_T (*)[3])ssGetOutputPortSignal
            (chartInstance->S, 1);
          c11_jointangles = (real_T (*)[12])ssGetInputPortSignal
            (chartInstance->S, 2);
          c11_KFE = (real_T *)ssGetInputPortSignal(chartInstance->S, 1);
          c11_xze = (real_T (*)[2])ssGetInputPortSignal(chartInstance->S, 0);
          _SFD_SET_DATA_VALUE_PTR(0U, *c11_xze);
          _SFD_SET_DATA_VALUE_PTR(1U, c11_KFE);
          _SFD_SET_DATA_VALUE_PTR(2U, *c11_jointangles);
          _SFD_SET_DATA_VALUE_PTR(3U, *c11_Rswjointangles);
          _SFD_SET_DATA_VALUE_PTR(4U, *c11_Rtrunk);
          _SFD_SET_DATA_VALUE_PTR(5U, *c11_SegmentLengths);
          _SFD_SET_DATA_VALUE_PTR(6U, c11_i);
          _SFD_SET_DATA_VALUE_PTR(7U, *c11_xz);
          _SFD_SET_DATA_VALUE_PTR(8U, *c11_LB);
          _SFD_SET_DATA_VALUE_PTR(9U, *c11_UB);
        }
      }
    } else {
      sf_debug_reset_current_state_configuration(sfGlobalDebugInstanceStruct,
        _FootPlacementLibraryMachineNumber_,chartInstance->chartNumber,
        chartInstance->instanceNumber);
    }
  }
}

static const char* sf_get_instance_specialization(void)
{
  return "Yn2Ha4gtmdYviaWtwVLd7C";
}

static void sf_opaque_initialize_c11_FootPlacementLibrary(void *chartInstanceVar)
{
  chart_debug_initialization(((SFc11_FootPlacementLibraryInstanceStruct*)
    chartInstanceVar)->S,0);
  initialize_params_c11_FootPlacementLibrary
    ((SFc11_FootPlacementLibraryInstanceStruct*) chartInstanceVar);
  initialize_c11_FootPlacementLibrary((SFc11_FootPlacementLibraryInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_enable_c11_FootPlacementLibrary(void *chartInstanceVar)
{
  enable_c11_FootPlacementLibrary((SFc11_FootPlacementLibraryInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_disable_c11_FootPlacementLibrary(void *chartInstanceVar)
{
  disable_c11_FootPlacementLibrary((SFc11_FootPlacementLibraryInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_gateway_c11_FootPlacementLibrary(void *chartInstanceVar)
{
  sf_gateway_c11_FootPlacementLibrary((SFc11_FootPlacementLibraryInstanceStruct*)
    chartInstanceVar);
}

extern const mxArray* sf_internal_get_sim_state_c11_FootPlacementLibrary
  (SimStruct* S)
{
  ChartRunTimeInfo * crtInfo = (ChartRunTimeInfo *)(ssGetUserData(S));
  ChartInfoStruct * chartInfo = (ChartInfoStruct *)(crtInfo->instanceInfo);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_raw2high");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = (mxArray*) get_sim_state_c11_FootPlacementLibrary
    ((SFc11_FootPlacementLibraryInstanceStruct*)chartInfo->chartInstance);/* raw sim ctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c11_FootPlacementLibrary();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_raw2high'.\n");
  }

  return plhs[0];
}

extern void sf_internal_set_sim_state_c11_FootPlacementLibrary(SimStruct* S,
  const mxArray *st)
{
  ChartRunTimeInfo * crtInfo = (ChartRunTimeInfo *)(ssGetUserData(S));
  ChartInfoStruct * chartInfo = (ChartInfoStruct *)(crtInfo->instanceInfo);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[3];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_high2raw");
  prhs[1] = mxDuplicateArray(st);      /* high level simctx */
  prhs[2] = (mxArray*) sf_get_sim_state_info_c11_FootPlacementLibrary();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 3, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_high2raw'.\n");
  }

  set_sim_state_c11_FootPlacementLibrary
    ((SFc11_FootPlacementLibraryInstanceStruct*)chartInfo->chartInstance,
     mxDuplicateArray(plhs[0]));
  mxDestroyArray(plhs[0]);
}

static const mxArray* sf_opaque_get_sim_state_c11_FootPlacementLibrary(SimStruct*
  S)
{
  return sf_internal_get_sim_state_c11_FootPlacementLibrary(S);
}

static void sf_opaque_set_sim_state_c11_FootPlacementLibrary(SimStruct* S, const
  mxArray *st)
{
  sf_internal_set_sim_state_c11_FootPlacementLibrary(S, st);
}

static void sf_opaque_terminate_c11_FootPlacementLibrary(void *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc11_FootPlacementLibraryInstanceStruct*) chartInstanceVar)
      ->S;
    ChartRunTimeInfo * crtInfo = (ChartRunTimeInfo *)(ssGetUserData(S));
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
      unload_FootPlacementLibrary_optimization_info();
    }

    finalize_c11_FootPlacementLibrary((SFc11_FootPlacementLibraryInstanceStruct*)
      chartInstanceVar);
    utFree((void *)chartInstanceVar);
    if (crtInfo != NULL) {
      utFree((void *)crtInfo);
    }

    ssSetUserData(S,NULL);
  }
}

static void sf_opaque_init_subchart_simstructs(void *chartInstanceVar)
{
  initSimStructsc11_FootPlacementLibrary
    ((SFc11_FootPlacementLibraryInstanceStruct*) chartInstanceVar);
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c11_FootPlacementLibrary(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    ChartRunTimeInfo * crtInfo = (ChartRunTimeInfo *)(ssGetUserData(S));
    ChartInfoStruct * chartInfo = (ChartInfoStruct *)(crtInfo->instanceInfo);
    initialize_params_c11_FootPlacementLibrary
      ((SFc11_FootPlacementLibraryInstanceStruct*)(chartInfo->chartInstance));
  }
}

static void mdlSetWorkWidths_c11_FootPlacementLibrary(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    mxArray *infoStruct = load_FootPlacementLibrary_optimization_info();
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable(sf_get_instance_specialization(),infoStruct,
      11);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,sf_rtw_info_uint_prop(sf_get_instance_specialization(),
                infoStruct,11,"RTWCG"));
    ssSetEnableFcnIsTrivial(S,1);
    ssSetDisableFcnIsTrivial(S,1);
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop
      (sf_get_instance_specialization(),infoStruct,11,
       "gatewayCannotBeInlinedMultipleTimes"));
    sf_update_buildInfo(sf_get_instance_specialization(),infoStruct,11);
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 1, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 2, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 3, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 4, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 5, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 6, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,sf_get_instance_specialization(),
        infoStruct,11,7);
      sf_mark_chart_reusable_outputs(S,sf_get_instance_specialization(),
        infoStruct,11,3);
    }

    {
      unsigned int outPortIdx;
      for (outPortIdx=1; outPortIdx<=3; ++outPortIdx) {
        ssSetOutputPortOptimizeInIR(S, outPortIdx, 1U);
      }
    }

    {
      unsigned int inPortIdx;
      for (inPortIdx=0; inPortIdx < 7; ++inPortIdx) {
        ssSetInputPortOptimizeInIR(S, inPortIdx, 1U);
      }
    }

    sf_set_rtw_dwork_info(S,sf_get_instance_specialization(),infoStruct,11);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
  } else {
  }

  ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  ssSetChecksum0(S,(1585185843U));
  ssSetChecksum1(S,(4243231494U));
  ssSetChecksum2(S,(3234154772U));
  ssSetChecksum3(S,(4027489614U));
  ssSetmdlDerivatives(S, NULL);
  ssSetExplicitFCSSCtrl(S,1);
  ssSupportsMultipleExecInstances(S,1);
}

static void mdlRTW_c11_FootPlacementLibrary(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlStart_c11_FootPlacementLibrary(SimStruct *S)
{
  SFc11_FootPlacementLibraryInstanceStruct *chartInstance;
  ChartRunTimeInfo * crtInfo = (ChartRunTimeInfo *)utMalloc(sizeof
    (ChartRunTimeInfo));
  chartInstance = (SFc11_FootPlacementLibraryInstanceStruct *)utMalloc(sizeof
    (SFc11_FootPlacementLibraryInstanceStruct));
  memset(chartInstance, 0, sizeof(SFc11_FootPlacementLibraryInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway =
    sf_opaque_gateway_c11_FootPlacementLibrary;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c11_FootPlacementLibrary;
  chartInstance->chartInfo.terminateChart =
    sf_opaque_terminate_c11_FootPlacementLibrary;
  chartInstance->chartInfo.enableChart =
    sf_opaque_enable_c11_FootPlacementLibrary;
  chartInstance->chartInfo.disableChart =
    sf_opaque_disable_c11_FootPlacementLibrary;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c11_FootPlacementLibrary;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c11_FootPlacementLibrary;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c11_FootPlacementLibrary;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c11_FootPlacementLibrary;
  chartInstance->chartInfo.mdlStart = mdlStart_c11_FootPlacementLibrary;
  chartInstance->chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c11_FootPlacementLibrary;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->chartInfo.debugInstance = sfGlobalDebugInstanceStruct;
  chartInstance->S = S;
  crtInfo->instanceInfo = (&(chartInstance->chartInfo));
  crtInfo->isJITEnabled = false;
  ssSetUserData(S,(void *)(crtInfo));  /* register the chart instance with simstruct */
  init_dsm_address_info(chartInstance);
  if (!sim_mode_is_rtw_gen(S)) {
  }

  sf_opaque_init_subchart_simstructs(chartInstance->chartInfo.chartInstance);
  chart_debug_initialization(S,1);
}

void c11_FootPlacementLibrary_method_dispatcher(SimStruct *S, int_T method, void
  *data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c11_FootPlacementLibrary(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c11_FootPlacementLibrary(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c11_FootPlacementLibrary(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c11_FootPlacementLibrary_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
