clear all
close all
clc

%% Forward kinematic symbolic equations

syms lShank lThigh dxHAA2HFE dyHAA2HFE dzHAA2HFE real
syms wPelvis hTrunk real

syms LHAA LHFE LKFE RHAA RHFE RKFE real
LHEE = 0;
RHEE = 0;
syms dxHAA2HEE dyHAA2HEE dzHAA2HEE real
syms dxHEE2HFE dyHEE2HFE dzHEE2HFE real
syms dxFoot lFoot hFoot real
syms R_pitch L_pitch R_roll L_roll real

syms x_end_1 x_end_2 x_end_3 real
syms xe ze real

% R_trunk_0_ = sym('R_trunk_0_',3);
% R_trunk_0_ = sym(R_trunk_0_,'real');
R_trunk_0_ = eye(3);

q = [RHAA; RHFE; RKFE; LHAA; LHFE; LKFE; R_pitch; L_pitch; R_roll; L_roll];

%%% s_i_j_k is xyz-position of point i relative to point j in frame k
s_6_0_0 = [0; 0; 0];

s_5_6_5 = [0; 0; wPelvis/2];
s_4_5_4 = [dxHAA2HEE; dyHAA2HEE; dzHAA2HEE];
s_3_4_3 = [dxHEE2HFE; dyHEE2HFE; dzHEE2HFE];
s_2_3_2 = [0; -lThigh; 0];
s_1_2_1 = [0; -lShank; 0];
s_1t_1_1 = [dxFoot; -hFoot; 0];
s_1h_1t_1 = [-lFoot; 0; 0];

s_7_6_5 = [0; 0; -wPelvis/2];
s_8_7_6 = [dxHAA2HEE; dyHAA2HEE; -dzHAA2HEE];
s_9_8_7 = [dxHEE2HFE; dyHEE2HFE; dzHEE2HFE];
s_10_9_8 = [0; -lThigh; 0];
s_11_10_9 = [0; -lShank; 0];
s_11t_11_9 = [dxFoot; -hFoot; 0];
s_11h_11t_9 = [-lFoot; 0; 0];

s_12_6_5 = [0; hTrunk; 0];

R_1_2 = Rz(-RKFE);
R_2_3 = Rz(-RHFE);
R_3_4 = Ry(-RHEE);
R_4_5 = Rx(-RHAA);
R_6_5 = Rx(-LHAA);
R_7_6 = Ry(-LHEE);
R_8_7 = Rz(-LHFE);
R_9_8 = Rz(-LKFE);

R_5_0 = R_trunk_0_;
% R_5_0 = eye(3);
% syms trpitch trroll real
% R_5_0 = Rz(trroll)*Rx(trpitch);

R_4_0 = R_5_0*R_4_5;
R_3_0 = R_4_0*R_3_4;
R_2_0 = R_3_0*R_2_3;
R_1_0 = R_2_0*R_1_2;

R_6_0 = R_5_0*R_6_5;
R_7_0 = R_6_0*R_7_6;
R_8_0 = R_7_0*R_8_7;
R_9_0 = R_8_0*R_9_8;

s_6 = s_6_0_0;

s_5 = s_6 + R_5_0*s_5_6_5;
s_4 = s_5 + R_4_0*s_4_5_4;
s_3 = s_4 + R_3_0*s_3_4_3;
s_2 = s_3 + R_2_0*s_2_3_2;
s_1 = s_2 + R_1_0*s_1_2_1;
s_1t = s_1 + R_1_0*s_1t_1_1;
s_1h = s_1t + R_1_0*s_1h_1t_1;




s_7 = s_6 + R_5_0*s_7_6_5;
s_8 = s_7 + R_6_0*s_8_7_6;
s_9 = s_8 + R_7_0*s_9_8_7;
s_10 = s_9 + R_8_0*s_10_9_8;
s_11 = s_10 + R_9_0*s_11_10_9;
s_11t = s_11 + R_9_0*s_11t_11_9;
s_11h = s_11t + R_9_0*s_11h_11t_9;



s_12 = s_6 + R_5_0*s_12_6_5;

s = [s_1h; s_1t; s_1; s_2; s_3; s_4; s_5; s_6; s_7; s_8; s_9; s_10; s_11; s_11t; s_11h; s_12];

% Feedforward equations

syms mShank mThigh mFoot gx gy gz real

s_rc_shankfoot   = s_2 + 0.5*R_1_0*s_1_2_1;
s_rc_thigh       = s_3 + 0.5*R_2_0*s_2_3_2;

% f_r = mThigh * s_rc_thigh + mShank * s_rc_shankfoot;
% t_r = jacobian(f_r,[RHAA; RHFE; RKFE])*[gx; gy; gz]

g = [gx; gy; gz];

t_r = simplify(jacobian([s_rc_thigh; s_rc_shankfoot],[RHAA; RHFE; RKFE])'*[g*mThigh; g*mShank])

% subs(t_r,[RHAA RHFE RKFE],[0 0 -90/180*pi])
matlabFunction(t_r,'file','generated_functions/ff_torque')