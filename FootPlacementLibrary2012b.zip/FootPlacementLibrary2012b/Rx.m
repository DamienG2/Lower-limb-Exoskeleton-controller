function R = Rx(q)
%#codegen
s = sin(q);
c = cos(q);

R = [  1,   0,   0; ... 
        0,   c, s;... 
        0,  -s, c];